import type { EncodingHint } from './encoding.js';
export { EncodingHint } from './encoding.js';
/**
 * Options for binary file detection.
 */
export interface IsBinaryOptions {
    /**
     * Hint about expected encoding to avoid false positives.
     */
    encoding?: EncodingHint;
    /**
     * Size of the buffer (only used when file is a Buffer).
     */
    size?: number;
}
export declare function isBinaryFile(file: string | Buffer, options?: IsBinaryOptions): Promise<boolean>;
export declare function isBinaryFileSync(file: string | Buffer, options?: IsBinaryOptions): boolean;
