# Changes to PostCSS Custom Properties

### 15.0.1

_February 21, 2026_

- Fix importance of custom media in anonymous cascade layers.

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-custom-properties/CHANGELOG.md)
