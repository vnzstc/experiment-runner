'use strict';

var client = require('@aws-sdk/core/client');



exports.NODE_REGION_CONFIG_FILE_OPTIONS = client.NODE_REGION_CONFIG_FILE_OPTIONS;
exports.NODE_REGION_CONFIG_OPTIONS = client.NODE_REGION_CONFIG_OPTIONS;
exports.REGION_ENV_NAME = client.REGION_ENV_NAME;
exports.REGION_INI_NAME = client.REGION_INI_NAME;
exports.getAwsRegionExtensionConfiguration = client.getAwsRegionExtensionConfiguration;
exports.resolveAwsRegionExtensionConfiguration = client.resolveAwsRegionExtensionConfiguration;
exports.resolveRegionConfig = client.resolveRegionConfig;
exports.stsRegionDefaultResolver = client.stsRegionDefaultResolver;
exports.warning = client.stsRegionWarning;
