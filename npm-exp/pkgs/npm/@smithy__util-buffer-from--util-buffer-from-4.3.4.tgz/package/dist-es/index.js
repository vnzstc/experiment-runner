export { fromArrayBuffer, fromString } from "@smithy/core/serde";
