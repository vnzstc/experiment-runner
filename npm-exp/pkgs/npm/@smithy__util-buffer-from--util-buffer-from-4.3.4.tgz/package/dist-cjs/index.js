"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fromString = exports.fromArrayBuffer = void 0;
var serde_1 = require("@smithy/core/serde");
Object.defineProperty(exports, "fromArrayBuffer", { enumerable: true, get: function () { return serde_1.fromArrayBuffer; } });
Object.defineProperty(exports, "fromString", { enumerable: true, get: function () { return serde_1.fromString; } });
