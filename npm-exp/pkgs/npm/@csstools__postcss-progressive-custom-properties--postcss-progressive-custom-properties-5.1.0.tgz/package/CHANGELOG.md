# Changes to PostCSS Progressive Custom Properties

### 5.1.0

_May 13, 2026_

- Add support for `image(red)`

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-progressive-custom-properties/CHANGELOG.md)
