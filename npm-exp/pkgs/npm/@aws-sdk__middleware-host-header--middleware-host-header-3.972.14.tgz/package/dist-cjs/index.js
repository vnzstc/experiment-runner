'use strict';

var client = require('@aws-sdk/core/client');



exports.getHostHeaderPlugin = client.getHostHeaderPlugin;
exports.hostHeaderMiddleware = client.hostHeaderMiddleware;
exports.hostHeaderMiddlewareOptions = client.hostHeaderMiddlewareOptions;
exports.resolveHostHeaderConfig = client.resolveHostHeaderConfig;
