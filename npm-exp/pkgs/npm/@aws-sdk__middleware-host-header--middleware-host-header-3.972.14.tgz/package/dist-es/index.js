export { hostHeaderMiddleware, hostHeaderMiddlewareOptions, getHostHeaderPlugin, resolveHostHeaderConfig, } from "@aws-sdk/core/client";
