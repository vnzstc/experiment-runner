'use strict';

var client = require('@aws-sdk/core/client');



exports.NODE_APP_ID_CONFIG_OPTIONS = client.NODE_APP_ID_CONFIG_OPTIONS;
exports.UA_APP_ID_ENV_NAME = client.UA_APP_ID_ENV_NAME;
exports.UA_APP_ID_INI_NAME = client.UA_APP_ID_INI_NAME;
exports.createDefaultUserAgentProvider = client.createDefaultUserAgentProvider;
exports.crtAvailability = client.crtAvailability;
exports.defaultUserAgent = client.defaultUserAgent;
