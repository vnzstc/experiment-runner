import type * as assets from './assets';
import * as assembly from './cloud-assembly';
import type * as validation from './cloud-assembly/validation-report-schema';
import type * as integ from './integ-tests';
export declare const VERSION_MISMATCH: string;
/**
 * Options for the loadManifest operation
 */
export interface LoadManifestOptions {
    /**
     * Skip the version check
     *
     * This means you may read a newer cloud assembly than the CX API is designed
     * to support, and your application may not be aware of all features that in use
     * in the Cloud Assembly.
     *
     * @default false
     */
    readonly skipVersionCheck?: boolean;
    /**
     * Skip enum checks
     *
     * This means you may read enum values you don't know about yet. Make sure to always
     * check the values of enums you encounter in the manifest.
     *
     * @default false
     */
    readonly skipEnumCheck?: boolean;
    /**
     * Topologically sort all artifacts
     *
     * This parameter is only respected by the constructor of `CloudAssembly`. The
     * property lives here for backwards compatibility reasons.
     *
     * @default true
     */
    readonly topoSort?: boolean;
    /**
     * Validate the file according to the declared JSON Schema
     *
     * Be aware that JSON Schema validation has a significant performance cost
     * (about 10x over not validating).
     *
     * @default false, unless $TESTING_CDK is set to '1'
     */
    readonly validateSchema?: boolean;
}
/**
 * Protocol utility class.
 */
export declare abstract class Manifest {
    /**
     * Validates and saves the cloud assembly manifest to file.
     *
     * @param manifest - manifest.
     * @param filePath - output file path.
     */
    static saveAssemblyManifest(manifest: assembly.AssemblyManifest, filePath: string): void;
    /**
     * Load and validates the cloud assembly manifest from file.
     *
     * @param filePath - path to the manifest file.
     */
    static loadAssemblyManifest(filePath: string, options?: LoadManifestOptions): assembly.AssemblyManifest;
    /**
     * Validates and saves the asset manifest to file.
     *
     * @param manifest - manifest.
     * @param filePath - output file path.
     */
    static saveAssetManifest(manifest: assets.AssetManifest, filePath: string): void;
    /**
     * Load and validates the asset manifest from file.
     *
     * @param filePath - path to the manifest file.
     */
    static loadAssetManifest(filePath: string): assets.AssetManifest;
    /**
     * Validates and saves the integ manifest to file.
     *
     * @param manifest - manifest.
     * @param filePath - output file path.
     */
    static saveIntegManifest(manifest: integ.IntegManifest, filePath: string): void;
    /**
     * Load and validates the integ manifest from file.
     *
     * @param filePath - path to the manifest file.
     */
    static loadIntegManifest(filePath: string): integ.IntegManifest;
    /**
     * Load and validate the policy validation report from file.
     *
     * @param filePath - path to the validation report file.
     */
    static loadValidationReport(filePath: string): validation.PolicyValidationReportJson;
    /**
     * Fetch the current schema version number.
     */
    static version(): string;
    /**
     * Return the CLI version that supports this Cloud Assembly Schema version
     */
    static cliVersion(): string | undefined;
    /**
     * Deprecated
     * @deprecated use `saveAssemblyManifest()`
     */
    static save(manifest: assembly.AssemblyManifest, filePath: string): void;
    /**
     * Deprecated
     * @deprecated use `loadAssemblyManifest()`
     */
    static load(filePath: string): assembly.AssemblyManifest;
    private static validate;
    private static saveManifest;
    private static loadManifest;
    /**
     * Fix the casing of stack tags entries
     *
     * At the very beginning of the CDK we used to emit stack tags as an object with
     * `{ Key, Value }` keys; this had the "advantage" that we could stick those
     * tags directly into the `CreateChangeSet` call.
     *
     * Then we later on used jsii on the assembly schema and we were forced to type
     * the in-memory objects as `{ key, value }` with lowercase letters. Now the
     * objects have a different on-disk and in-memory format, and we need to convert
     * between them.
     *
     * For backwards compatibility reasons, we used to convert lowercase in-memory
     * to uppercase on-disk variant until very recently. This is now unnecessary,
     * since no officially supported CDK tools read the stack tags from the
     * metadata; the CLI and toolkit library read stack tags from the artifact
     * properties.
     *
     * So although we don't emit uppercase stack tag objects anymore, we might still read
     * manifests that have them. Because the manifest we read must pass JSON Schema
     * validation (which expects lowercase tag objects), we have to fix the casing
     * of these objects after reading from disk and before validating.
     *
     * That's what this function does.
     */
    private static patchStackTagsOnRead;
    /**
     * Validates that `assumeRoleAdditionalOptions` doesn't contain nor `ExternalId` neither `RoleArn`, as they
     * should have dedicated properties preceding this (e.g `assumeRoleArn` and `assumeRoleExternalId`).
     */
    private static validateAssumeRoleAdditionalOptions;
}
