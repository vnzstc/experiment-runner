# Changes to PostCSS Custom Selectors

### 9.0.1

_February 21, 2026_

- Fix importance of custom media in anonymous cascade layers.

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-custom-selectors/CHANGELOG.md)
