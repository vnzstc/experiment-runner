"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseQueryString = void 0;
var protocols_1 = require("@smithy/core/protocols");
Object.defineProperty(exports, "parseQueryString", { enumerable: true, get: function () { return protocols_1.parseQueryString; } });
