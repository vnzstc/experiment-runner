export { parseQueryString } from "@smithy/core/protocols";
