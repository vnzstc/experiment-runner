'use strict';

var middlewareSigning = require('@aws-sdk/middleware-signing');

const resolveStsAuthConfig = (input, { stsClientCtor }) => {
    return middlewareSigning.resolveAwsAuthConfig(Object.assign(input, {
        stsClientCtor,
    }));
};

exports.resolveStsAuthConfig = resolveStsAuthConfig;
