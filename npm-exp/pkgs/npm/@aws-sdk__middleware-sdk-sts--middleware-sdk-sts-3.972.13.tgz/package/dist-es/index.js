import { resolveAwsAuthConfig } from "@aws-sdk/middleware-signing";
export const resolveStsAuthConfig = (input, { stsClientCtor }) => {
    return resolveAwsAuthConfig(Object.assign(input, {
        stsClientCtor,
    }));
};
