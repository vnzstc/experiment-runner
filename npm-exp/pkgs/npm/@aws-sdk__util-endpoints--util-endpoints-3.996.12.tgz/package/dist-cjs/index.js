'use strict';

var client = require('@aws-sdk/core/client');
var endpoints = require('@smithy/core/endpoints');



exports.awsEndpointFunctions = client.awsEndpointFunctions;
exports.getUserAgentPrefix = client.getUserAgentPrefix;
exports.isIpAddress = client.isIpAddress;
exports.partition = client.partition;
exports.resolveDefaultAwsRegionalEndpointsConfig = client.resolveDefaultAwsRegionalEndpointsConfig;
exports.resolveEndpoint = client.resolveEndpoint;
exports.setPartitionInfo = client.setPartitionInfo;
exports.toEndpointV1 = client.toEndpointV1;
exports.useDefaultPartitionInfo = client.useDefaultPartitionInfo;
exports.EndpointError = endpoints.EndpointError;
