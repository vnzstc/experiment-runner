export { awsEndpointFunctions, resolveEndpoint, resolveDefaultAwsRegionalEndpointsConfig, toEndpointV1, isIpAddress, partition, setPartitionInfo, useDefaultPartitionInfo, getUserAgentPrefix, } from "@aws-sdk/core/client";
export { EndpointError } from "@smithy/core/endpoints";
