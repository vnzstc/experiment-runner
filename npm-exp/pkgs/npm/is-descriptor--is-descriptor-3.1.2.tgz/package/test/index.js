'use strict';

var test = require('tape');
var hasProto = require('has-proto')();

var isDescriptor = require('../');

var noop = function () {};

test('isDescriptor', function (t) {
	t.test('is false when not an object:', function (st) {
		st.notOk(isDescriptor('a'));
		st.notOk(isDescriptor(null));
		st.notOk(isDescriptor([]));

		st.end();
	});

	t.test('check for descriptor', function (st) {
		st.test('returns true if the property exists', function (s2t) {
			var obj = { foo: null };

			Object.defineProperty(obj, 'bar', {
				value: 'xyz'
			});

			Object.defineProperty(obj, 'baz', {
				get: function () {
					return 'aaa';
				}
			});

			(typeof Reflect === 'function' ? Reflect : Object).defineProperty(obj, 'qux', {
				value: 'xyz'
			});

			s2t.ok(isDescriptor(obj, 'foo'));
			s2t.ok(isDescriptor(obj, 'bar'));
			s2t.ok(isDescriptor(obj, 'baz'));
			s2t.ok(isDescriptor(obj, 'qux'));

			s2t.end();
		});

		st.end();
	});

	t.test('with a key', function (st) {
		st.equal(isDescriptor({ foo: 3 }, 'foo'), true, 'a data property is a data descriptor');
		st.equal(isDescriptor({ '': 3 }, ''), true, 'an empty string data property is a data descriptor');
		st.equal(isDescriptor({ 0: 3 }, 0), true, 'a zero data property is a data descriptor');
		st.end();
	});

	t.test('data descriptor:', function (st) {
		st.test('is false when the object has invalid properties:', function (s2t) {
			s2t.notOk(isDescriptor({ value: 'foo', get: noop }));
			s2t.notOk(isDescriptor({ get: noop, value: noop }));

			s2t.end();
		});

		st.test('is false when the object has unrecognized properties:', function (s2t) {
			s2t.notOk(isDescriptor({ value: 'foo', bar: 'baz' }));
			s2t.notOk(isDescriptor({ value: 'foo', bar: 'baz' }));

			s2t.end();
		});

		st.test('is false when not descriptors', function (s2t) {
			s2t.notOk(isDescriptor({ value: 'foo' }));
			s2t.notOk(isDescriptor({ value: noop }));

			s2t.end();
		});

		st.test('is false when a value is not the correct type:', function (s2t) {
			s2t.notOk(isDescriptor({ value: 'foo', enumerable: 'foo' }));
			s2t.notOk(isDescriptor({ value: 'foo', configurable: 'foo' }));
			s2t.notOk(isDescriptor({ value: 'foo', writable: 'foo' }));

			s2t.end();
		});

		st.end();
	});

	t.test('accessor descriptor:', function (st) {
		st.test('is false when the object has invalid properties:', function (s2t) {
			s2t.notOk(isDescriptor({ get: noop, writable: true }));
			s2t.notOk(isDescriptor({ get: noop, value: true }));

			s2t.end();
		});

		st.test('is false when the object has unrecognize properties:', function (s2t) {
			s2t.notOk(isDescriptor({ get: noop, set: noop, bar: 'baz' }));

			s2t.end();
		});

		st.test('is false when an accessor is not a function:', function (s2t) {
			s2t.notOk(isDescriptor({ get: noop, set: 'baz' }));
			s2t.notOk(isDescriptor({ get: 'foo', set: noop }));
			s2t.notOk(isDescriptor({ get: 'foo', bar: 'baz' }));
			s2t.notOk(isDescriptor({ get: 'foo', set: 'baz' }));

			s2t.end();
		});

		st.test('is false when "get" or "set" is not a function', function (s2t) {
			s2t.notOk(isDescriptor({ enumerable: true, configurable: true, set: noop }));
			s2t.notOk(isDescriptor({ enumerable: true, configurable: true, get: 'foo' }));
			s2t.notOk(isDescriptor({ enumerable: true, configurable: true, set: 'foo' }));

			s2t.end();
		});

		st.test('is true when the object has all necessary properties', function (s2t) {
			s2t.ok(isDescriptor({ get: noop, set: noop, configurable: true, enumerable: true }));

			s2t.end();
		});

		st.test('is false when the object does not have all necessary properties', function (s2t) {
			s2t.notOk(isDescriptor({ get: noop, set: noop }));
			s2t.notOk(isDescriptor({ get: noop }));

			s2t.end();
		});

		st.test('is false when a value is not the correct type:', function (s2t) {
			s2t.notOk(isDescriptor({ get: noop, set: noop, enumerable: 'foo' }));
			s2t.notOk(isDescriptor({ set: noop, configurable: 'foo' }));
			s2t.notOk(isDescriptor({ get: noop, configurable: 'foo' }));

			s2t.end();
		});

		st.end();
	});

	t.test('prototype fallback (checkProto)', function (st) {
		function Foo() {}
		Object.defineProperty(Foo.prototype, 'x', {
			value: 1,
			writable: false,
			configurable: false,
			enumerable: false
		});
		var obj = new Foo();
		st.equal(isDescriptor(obj, 'x'), true, 'a property on the constructor.prototype is a descriptor');
		st.equal(typeof isDescriptor(obj, 'x'), 'boolean', 'returns a strict boolean (not undefined)');
		st.equal(isDescriptor(obj, 'x', false), false, 'checkProto:false skips the prototype lookup');
		st.equal(isDescriptor(obj, 'missing'), false, 'a missing prototype property returns false');

		st.end();
	});

	t.test('null-prototype objects', { skip: !hasProto }, function (st) {
		var obj = { __proto__: null, foo: 1 };
		st.equal(isDescriptor(obj, 'foo'), true, 'own data property on a null-prototype object is a descriptor');
		st.equal(
			isDescriptor(obj, 'missing'),
			false,
			'missing key on a null-prototype object returns false (not undefined or throw)'
		);
		st.equal(typeof isDescriptor(obj, 'missing'), 'boolean', 'returns a strict boolean');

		st.end();
	});

	t.test('hostile descriptor input: throwing accessors do not propagate', function (st) {
		var configThrow = Object.defineProperty(
			{ enumerable: true, value: 1, writable: false },
			'configurable',
			{ get: function () { throw new Error('configurable'); } }
		);
		st.equal(isDescriptor(configThrow), false, 'throwing .configurable getter returns false');

		var enumThrow = Object.defineProperty(
			{ configurable: true, value: 1, writable: false },
			'enumerable',
			{ get: function () { throw new Error('enumerable'); } }
		);
		st.equal(isDescriptor(enumThrow), false, 'throwing .enumerable getter returns false');

		st.end();
	});
});
