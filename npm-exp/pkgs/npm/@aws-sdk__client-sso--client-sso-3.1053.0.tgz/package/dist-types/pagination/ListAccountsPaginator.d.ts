import type { Paginator } from "@smithy/types";
import { ListAccountsCommandInput, ListAccountsCommandOutput } from "../commands/ListAccountsCommand";
import type { SSOPaginationConfiguration } from "./Interfaces";
/**
 * @public
 */
export declare const paginateListAccounts: (config: SSOPaginationConfiguration, input: ListAccountsCommandInput, ...rest: any[]) => Paginator<ListAccountsCommandOutput>;
