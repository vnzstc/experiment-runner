This is a stub types definition for @types/parse-json (https://github.com/sindresorhus/parse-json#readme).

parse-json provides its own type definitions, so you don't need @types/parse-json installed!