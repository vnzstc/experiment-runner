This is a stub types definition for @types/cacheable-request (https://github.com/jaredwray/cacheable#readme).

cacheable-request provides its own type definitions, so you don't need @types/cacheable-request installed!