export declare const emitWarningIfUnsupportedVersion: symbol;
export declare const state: symbol;
export { getLongPollPlugin } from "./longPollMiddleware";
export { setCredentialFeature } from "./setCredentialFeature";
export { setFeature } from "./setFeature";
export { setTokenFeature } from "./setTokenFeature";
export {
  hostHeaderMiddleware,
  hostHeaderMiddlewareOptions,
  getHostHeaderPlugin,
  resolveHostHeaderConfig,
} from "./middleware-host-header/hostHeaderMiddleware";
export {
  HostHeaderInputConfig,
  HostHeaderResolvedConfig,
} from "./middleware-host-header/hostHeaderMiddleware";
export {
  loggerMiddleware,
  loggerMiddlewareOptions,
  getLoggerPlugin,
} from "./middleware-logger/loggerMiddleware";
export { recursionDetectionMiddlewareOptions } from "./middleware-recursion-detection/configuration";
export { getRecursionDetectionPlugin } from "./middleware-recursion-detection/getRecursionDetectionPlugin.browser";
export { recursionDetectionMiddleware } from "./middleware-recursion-detection/recursionDetectionMiddleware.browser";
export {
  DEFAULT_UA_APP_ID,
  resolveUserAgentConfig,
} from "./middleware-user-agent/configurations";
export {
  UserAgentInputConfig,
  UserAgentResolvedConfig,
} from "./middleware-user-agent/configurations";
export {
  userAgentMiddleware,
  getUserAgentMiddlewareOptions,
  getUserAgentPlugin,
} from "./middleware-user-agent/user-agent-middleware";
export {
  createDefaultUserAgentProvider,
  defaultUserAgent,
  fallback,
} from "./util-user-agent-browser/defaultUserAgent";
export declare const crtAvailability: symbol;
export {
  DefaultUserAgentOptions,
  PreviouslyResolved,
} from "./util-user-agent-node/defaultUserAgent";
export declare const NODE_APP_ID_CONFIG_OPTIONS: symbol;
export declare const UA_APP_ID_ENV_NAME: symbol;
export declare const UA_APP_ID_INI_NAME: symbol;
export { createUserAgentStringParsingProvider } from "./util-user-agent-browser/createUserAgentStringParsingProvider";
export { awsEndpointFunctions } from "./util-endpoints/aws";
export { resolveEndpoint } from "./util-endpoints/resolveEndpoint";
export {
  resolveDefaultAwsRegionalEndpointsConfig,
  toEndpointV1,
} from "./util-endpoints/resolveDefaultAwsRegionalEndpointsConfig";
export {
  DefaultAwsRegionalEndpointsInputConfig,
  DefaultAwsRegionalEndpointsResolvedConfig,
} from "./util-endpoints/resolveDefaultAwsRegionalEndpointsConfig";
export { isIpAddress } from "./util-endpoints/lib/isIpAddress";
export { isVirtualHostableS3Bucket } from "./util-endpoints/lib/aws/isVirtualHostableS3Bucket";
export { parseArn } from "./util-endpoints/lib/aws/parseArn";
export {
  partition,
  setPartitionInfo,
  useDefaultPartitionInfo,
  getUserAgentPrefix,
} from "./util-endpoints/lib/aws/partition";
export { PartitionsInfo } from "./util-endpoints/lib/aws/partition";
export { EndpointError } from "./util-endpoints/types/EndpointError";
export {
  EndpointObjectProperties,
  EndpointObjectHeaders,
  EndpointObject,
  EndpointRuleObject,
} from "./util-endpoints/types/EndpointRuleObject";
export { ErrorRuleObject } from "./util-endpoints/types/ErrorRuleObject";
export {
  RuleSetRules,
  TreeRuleObject,
} from "./util-endpoints/types/TreeRuleObject";
export {
  DeprecatedObject,
  ParameterObject,
  RuleSetObject,
} from "./util-endpoints/types/RuleSetObject";
export {
  ReferenceObject,
  FunctionObject,
  FunctionArgv,
  FunctionReturn,
  ConditionObject,
  Expression,
  EndpointParams,
  EndpointResolverOptions,
  ReferenceRecord,
  EvaluateOptions,
} from "./util-endpoints/types/shared";
export declare const REGION_ENV_NAME: symbol;
export declare const REGION_INI_NAME: symbol;
export declare const NODE_REGION_CONFIG_OPTIONS: symbol;
export declare const NODE_REGION_CONFIG_FILE_OPTIONS: symbol;
export { resolveRegionConfig } from "./region-config-resolver/awsRegionConfig";
export {
  RegionInputConfig,
  RegionResolvedConfig,
} from "./region-config-resolver/awsRegionConfig";
export { stsRegionDefaultResolver } from "./region-config-resolver/stsRegionDefaultResolver.browser";
export declare const stsRegionWarning: symbol;
export {
  getAwsRegionExtensionConfiguration,
  resolveAwsRegionExtensionConfiguration,
} from "./region-config-resolver/extensions";
export { RegionExtensionRuntimeConfigType } from "./region-config-resolver/extensions";
