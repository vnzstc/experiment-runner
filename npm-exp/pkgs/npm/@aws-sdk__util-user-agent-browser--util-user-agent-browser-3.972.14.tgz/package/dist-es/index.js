export { createDefaultUserAgentProvider, defaultUserAgent, fallback, createUserAgentStringParsingProvider, } from "@aws-sdk/core/client";
