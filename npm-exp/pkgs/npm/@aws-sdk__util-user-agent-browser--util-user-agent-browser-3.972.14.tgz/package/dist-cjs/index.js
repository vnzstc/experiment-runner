'use strict';

var client = require('@aws-sdk/core/client');



exports.createDefaultUserAgentProvider = client.createDefaultUserAgentProvider;
exports.createUserAgentStringParsingProvider = client.createUserAgentStringParsingProvider;
exports.defaultUserAgent = client.defaultUserAgent;
exports.fallback = client.fallback;
