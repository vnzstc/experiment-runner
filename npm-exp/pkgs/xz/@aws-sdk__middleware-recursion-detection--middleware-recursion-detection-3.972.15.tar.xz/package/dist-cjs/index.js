'use strict';

var client = require('@aws-sdk/core/client');



exports.getRecursionDetectionPlugin = client.getRecursionDetectionPlugin;
exports.recursionDetectionMiddleware = client.recursionDetectionMiddleware;
exports.recursionDetectionMiddlewareOptions = client.recursionDetectionMiddlewareOptions;
