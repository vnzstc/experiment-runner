# lodash.keys v4.2.0

The [lodash](https://lodash.com/) method `_.keys` exported as a [Node.js](https://nodejs.org/) module.

## Installation

Using npm:
```bash
$ {sudo -H} npm i -g npm
$ npm i --save lodash.keys
```

In Node.js:
```js
var keys = require('lodash.keys');
```

See the [documentation](https://lodash.com/docs#keys) or [package source](https://github.com/lodash/lodash/blob/4.2.0-npm-packages/lodash.keys) for more details.
