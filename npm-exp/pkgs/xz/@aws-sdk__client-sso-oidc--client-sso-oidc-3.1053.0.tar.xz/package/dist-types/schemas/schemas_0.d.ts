import { TypeRegistry } from "@smithy/core/schema";
import type { StaticErrorSchema, StaticOperationSchema, StaticStructureSchema } from "@smithy/types";
export declare var SSOOIDCServiceException$: StaticErrorSchema;
export declare var AccessDeniedException$: StaticErrorSchema;
export declare var AuthorizationPendingException$: StaticErrorSchema;
export declare var ExpiredTokenException$: StaticErrorSchema;
export declare var InternalServerException$: StaticErrorSchema;
export declare var InvalidClientException$: StaticErrorSchema;
export declare var InvalidClientMetadataException$: StaticErrorSchema;
export declare var InvalidGrantException$: StaticErrorSchema;
export declare var InvalidRedirectUriException$: StaticErrorSchema;
export declare var InvalidRequestException$: StaticErrorSchema;
export declare var InvalidRequestRegionException$: StaticErrorSchema;
export declare var InvalidScopeException$: StaticErrorSchema;
export declare var SlowDownException$: StaticErrorSchema;
export declare var UnauthorizedClientException$: StaticErrorSchema;
export declare var UnsupportedGrantTypeException$: StaticErrorSchema;
/**
 * TypeRegistry instances containing modeled errors.
 * @internal
 *
 */
export declare const errorTypeRegistries: TypeRegistry[];
export declare var AwsAdditionalDetails$: StaticStructureSchema;
export declare var CreateTokenRequest$: StaticStructureSchema;
export declare var CreateTokenResponse$: StaticStructureSchema;
export declare var CreateTokenWithIAMRequest$: StaticStructureSchema;
export declare var CreateTokenWithIAMResponse$: StaticStructureSchema;
export declare var RegisterClientRequest$: StaticStructureSchema;
export declare var RegisterClientResponse$: StaticStructureSchema;
export declare var StartDeviceAuthorizationRequest$: StaticStructureSchema;
export declare var StartDeviceAuthorizationResponse$: StaticStructureSchema;
export declare var CreateToken$: StaticOperationSchema;
export declare var CreateTokenWithIAM$: StaticOperationSchema;
export declare var RegisterClient$: StaticOperationSchema;
export declare var StartDeviceAuthorization$: StaticOperationSchema;
