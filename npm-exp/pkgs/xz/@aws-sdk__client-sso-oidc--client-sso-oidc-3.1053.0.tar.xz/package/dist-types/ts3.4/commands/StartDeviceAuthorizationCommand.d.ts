import { Command as $Command } from "@smithy/core/client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  StartDeviceAuthorizationRequest,
  StartDeviceAuthorizationResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SSOOIDCClientResolvedConfig,
} from "../SSOOIDCClient";
export { __MetadataBearer };
export { $Command };
export interface StartDeviceAuthorizationCommandInput
  extends StartDeviceAuthorizationRequest {}
export interface StartDeviceAuthorizationCommandOutput
  extends StartDeviceAuthorizationResponse,
    __MetadataBearer {}
declare const StartDeviceAuthorizationCommand_base: {
  new (
    input: StartDeviceAuthorizationCommandInput
  ): import("@smithy/core/client").CommandImpl<
    StartDeviceAuthorizationCommandInput,
    StartDeviceAuthorizationCommandOutput,
    SSOOIDCClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: StartDeviceAuthorizationCommandInput
  ): import("@smithy/core/client").CommandImpl<
    StartDeviceAuthorizationCommandInput,
    StartDeviceAuthorizationCommandOutput,
    SSOOIDCClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): {
    [x: string]: unknown;
  };
};
export declare class StartDeviceAuthorizationCommand extends StartDeviceAuthorizationCommand_base {
  protected static __types: {
    api: {
      input: StartDeviceAuthorizationRequest;
      output: StartDeviceAuthorizationResponse;
    };
    sdk: {
      input: StartDeviceAuthorizationCommandInput;
      output: StartDeviceAuthorizationCommandOutput;
    };
  };
}
