import { Command as $Command } from "@smithy/core/client";
import { MetadataBearer as __MetadataBearer } from "@smithy/types";
import {
  CreateTokenWithIAMRequest,
  CreateTokenWithIAMResponse,
} from "../models/models_0";
import {
  ServiceInputTypes,
  ServiceOutputTypes,
  SSOOIDCClientResolvedConfig,
} from "../SSOOIDCClient";
export { __MetadataBearer };
export { $Command };
export interface CreateTokenWithIAMCommandInput
  extends CreateTokenWithIAMRequest {}
export interface CreateTokenWithIAMCommandOutput
  extends CreateTokenWithIAMResponse,
    __MetadataBearer {}
declare const CreateTokenWithIAMCommand_base: {
  new (
    input: CreateTokenWithIAMCommandInput
  ): import("@smithy/core/client").CommandImpl<
    CreateTokenWithIAMCommandInput,
    CreateTokenWithIAMCommandOutput,
    SSOOIDCClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  new (
    input: CreateTokenWithIAMCommandInput
  ): import("@smithy/core/client").CommandImpl<
    CreateTokenWithIAMCommandInput,
    CreateTokenWithIAMCommandOutput,
    SSOOIDCClientResolvedConfig,
    ServiceInputTypes,
    ServiceOutputTypes
  >;
  getEndpointParameterInstructions(): {
    [x: string]: unknown;
  };
};
export declare class CreateTokenWithIAMCommand extends CreateTokenWithIAMCommand_base {
  protected static __types: {
    api: {
      input: CreateTokenWithIAMRequest;
      output: CreateTokenWithIAMResponse;
    };
    sdk: {
      input: CreateTokenWithIAMCommandInput;
      output: CreateTokenWithIAMCommandOutput;
    };
  };
}
