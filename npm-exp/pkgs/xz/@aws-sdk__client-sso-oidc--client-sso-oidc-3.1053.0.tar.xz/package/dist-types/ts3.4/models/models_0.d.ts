export interface AwsAdditionalDetails {
  identityContext?: string | undefined;
}
export interface CreateTokenRequest {
  clientId: string | undefined;
  clientSecret: string | undefined;
  grantType: string | undefined;
  deviceCode?: string | undefined;
  code?: string | undefined;
  refreshToken?: string | undefined;
  scope?: string[] | undefined;
  redirectUri?: string | undefined;
  codeVerifier?: string | undefined;
}
export interface CreateTokenResponse {
  accessToken?: string | undefined;
  tokenType?: string | undefined;
  expiresIn?: number | undefined;
  refreshToken?: string | undefined;
  idToken?: string | undefined;
}
export interface CreateTokenWithIAMRequest {
  clientId: string | undefined;
  grantType: string | undefined;
  code?: string | undefined;
  refreshToken?: string | undefined;
  assertion?: string | undefined;
  scope?: string[] | undefined;
  redirectUri?: string | undefined;
  subjectToken?: string | undefined;
  subjectTokenType?: string | undefined;
  requestedTokenType?: string | undefined;
  codeVerifier?: string | undefined;
}
export interface CreateTokenWithIAMResponse {
  accessToken?: string | undefined;
  tokenType?: string | undefined;
  expiresIn?: number | undefined;
  refreshToken?: string | undefined;
  idToken?: string | undefined;
  issuedTokenType?: string | undefined;
  scope?: string[] | undefined;
  awsAdditionalDetails?: AwsAdditionalDetails | undefined;
}
export interface RegisterClientRequest {
  clientName: string | undefined;
  clientType: string | undefined;
  scopes?: string[] | undefined;
  redirectUris?: string[] | undefined;
  grantTypes?: string[] | undefined;
  issuerUrl?: string | undefined;
  entitledApplicationArn?: string | undefined;
}
export interface RegisterClientResponse {
  clientId?: string | undefined;
  clientSecret?: string | undefined;
  clientIdIssuedAt?: number | undefined;
  clientSecretExpiresAt?: number | undefined;
  authorizationEndpoint?: string | undefined;
  tokenEndpoint?: string | undefined;
}
export interface StartDeviceAuthorizationRequest {
  clientId: string | undefined;
  clientSecret: string | undefined;
  startUrl: string | undefined;
}
export interface StartDeviceAuthorizationResponse {
  deviceCode?: string | undefined;
  userCode?: string | undefined;
  verificationUri?: string | undefined;
  verificationUriComplete?: string | undefined;
  expiresIn?: number | undefined;
  interval?: number | undefined;
}
