const _A = "Assertion";
const _AAD = "AwsAdditionalDetails";
const _ADE = "AccessDeniedException";
const _APE = "AuthorizationPendingException";
const _AT = "AccessToken";
const _CS = "ClientSecret";
const _CT = "CreateToken";
const _CTR = "CreateTokenRequest";
const _CTRr = "CreateTokenResponse";
const _CTWIAM = "CreateTokenWithIAM";
const _CTWIAMR = "CreateTokenWithIAMRequest";
const _CTWIAMRr = "CreateTokenWithIAMResponse";
const _CV = "CodeVerifier";
const _ETE = "ExpiredTokenException";
const _ICE = "InvalidClientException";
const _ICME = "InvalidClientMetadataException";
const _IGE = "InvalidGrantException";
const _IRE = "InvalidRequestException";
const _IRRE = "InvalidRequestRegionException";
const _IRUE = "InvalidRedirectUriException";
const _ISE = "InternalServerException";
const _ISEn = "InvalidScopeException";
const _IT = "IdToken";
const _RC = "RegisterClient";
const _RCR = "RegisterClientRequest";
const _RCRe = "RegisterClientResponse";
const _RT = "RefreshToken";
const _SDA = "StartDeviceAuthorization";
const _SDAR = "StartDeviceAuthorizationRequest";
const _SDARt = "StartDeviceAuthorizationResponse";
const _SDE = "SlowDownException";
const _ST = "SubjectToken";
const _UCE = "UnauthorizedClientException";
const _UGTE = "UnsupportedGrantTypeException";
const _a = "assertion";
const _aAD = "awsAdditionalDetails";
const _aE = "authorizationEndpoint";
const _aT = "accessToken";
const _c = "client";
const _cI = "clientId";
const _cIIA = "clientIdIssuedAt";
const _cN = "clientName";
const _cS = "clientSecret";
const _cSEA = "clientSecretExpiresAt";
const _cT = "clientType";
const _cV = "codeVerifier";
const _co = "code";
const _dC = "deviceCode";
const _e = "error";
const _eAA = "entitledApplicationArn";
const _eI = "expiresIn";
const _ed = "error_description";
const _en = "endpoint";
const _gT = "grantType";
const _gTr = "grantTypes";
const _h = "http";
const _hE = "httpError";
const _i = "interval";
const _iC = "identityContext";
const _iT = "idToken";
const _iTT = "issuedTokenType";
const _iU = "issuerUrl";
const _r = "reason";
const _rT = "refreshToken";
const _rTT = "requestedTokenType";
const _rU = "redirectUri";
const _rUe = "redirectUris";
const _re = "region";
const _s = "smithy.ts.sdk.synthetic.com.amazonaws.ssooidc";
const _sT = "subjectToken";
const _sTT = "subjectTokenType";
const _sU = "startUrl";
const _sc = "scope";
const _sco = "scopes";
const _se = "server";
const _tE = "tokenEndpoint";
const _tT = "tokenType";
const _uC = "userCode";
const _vU = "verificationUri";
const _vUC = "verificationUriComplete";
const n0 = "com.amazonaws.ssooidc";
import { TypeRegistry } from "@smithy/core/schema";
import { AccessDeniedException, AuthorizationPendingException, ExpiredTokenException, InternalServerException, InvalidClientException, InvalidClientMetadataException, InvalidGrantException, InvalidRedirectUriException, InvalidRequestException, InvalidRequestRegionException, InvalidScopeException, SlowDownException, UnauthorizedClientException, UnsupportedGrantTypeException, } from "../models/errors";
import { SSOOIDCServiceException } from "../models/SSOOIDCServiceException";
const _s_registry = TypeRegistry.for(_s);
export var SSOOIDCServiceException$ = [-3, _s, "SSOOIDCServiceException", 0, [], []];
_s_registry.registerError(SSOOIDCServiceException$, SSOOIDCServiceException);
const n0_registry = TypeRegistry.for(n0);
export var AccessDeniedException$ = [-3, n0, _ADE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _r, _ed],
    [0, 0, 0]
];
n0_registry.registerError(AccessDeniedException$, AccessDeniedException);
export var AuthorizationPendingException$ = [-3, n0, _APE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(AuthorizationPendingException$, AuthorizationPendingException);
export var ExpiredTokenException$ = [-3, n0, _ETE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(ExpiredTokenException$, ExpiredTokenException);
export var InternalServerException$ = [-3, n0, _ISE,
    { [_e]: _se, [_hE]: 500 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InternalServerException$, InternalServerException);
export var InvalidClientException$ = [-3, n0, _ICE,
    { [_e]: _c, [_hE]: 401 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InvalidClientException$, InvalidClientException);
export var InvalidClientMetadataException$ = [-3, n0, _ICME,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InvalidClientMetadataException$, InvalidClientMetadataException);
export var InvalidGrantException$ = [-3, n0, _IGE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InvalidGrantException$, InvalidGrantException);
export var InvalidRedirectUriException$ = [-3, n0, _IRUE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InvalidRedirectUriException$, InvalidRedirectUriException);
export var InvalidRequestException$ = [-3, n0, _IRE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _r, _ed],
    [0, 0, 0]
];
n0_registry.registerError(InvalidRequestException$, InvalidRequestException);
export var InvalidRequestRegionException$ = [-3, n0, _IRRE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed, _en, _re],
    [0, 0, 0, 0]
];
n0_registry.registerError(InvalidRequestRegionException$, InvalidRequestRegionException);
export var InvalidScopeException$ = [-3, n0, _ISEn,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(InvalidScopeException$, InvalidScopeException);
export var SlowDownException$ = [-3, n0, _SDE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(SlowDownException$, SlowDownException);
export var UnauthorizedClientException$ = [-3, n0, _UCE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(UnauthorizedClientException$, UnauthorizedClientException);
export var UnsupportedGrantTypeException$ = [-3, n0, _UGTE,
    { [_e]: _c, [_hE]: 400 },
    [_e, _ed],
    [0, 0]
];
n0_registry.registerError(UnsupportedGrantTypeException$, UnsupportedGrantTypeException);
export const errorTypeRegistries = [
    _s_registry,
    n0_registry,
];
var AccessToken = [0, n0, _AT, 8, 0];
var Assertion = [0, n0, _A, 8, 0];
var ClientSecret = [0, n0, _CS, 8, 0];
var CodeVerifier = [0, n0, _CV, 8, 0];
var IdToken = [0, n0, _IT, 8, 0];
var RefreshToken = [0, n0, _RT, 8, 0];
var SubjectToken = [0, n0, _ST, 8, 0];
export var AwsAdditionalDetails$ = [3, n0, _AAD,
    0,
    [_iC],
    [0]
];
export var CreateTokenRequest$ = [3, n0, _CTR,
    0,
    [_cI, _cS, _gT, _dC, _co, _rT, _sc, _rU, _cV],
    [0, [() => ClientSecret, 0], 0, 0, 0, [() => RefreshToken, 0], 64 | 0, 0, [() => CodeVerifier, 0]], 3
];
export var CreateTokenResponse$ = [3, n0, _CTRr,
    0,
    [_aT, _tT, _eI, _rT, _iT],
    [[() => AccessToken, 0], 0, 1, [() => RefreshToken, 0], [() => IdToken, 0]]
];
export var CreateTokenWithIAMRequest$ = [3, n0, _CTWIAMR,
    0,
    [_cI, _gT, _co, _rT, _a, _sc, _rU, _sT, _sTT, _rTT, _cV],
    [0, 0, 0, [() => RefreshToken, 0], [() => Assertion, 0], 64 | 0, 0, [() => SubjectToken, 0], 0, 0, [() => CodeVerifier, 0]], 2
];
export var CreateTokenWithIAMResponse$ = [3, n0, _CTWIAMRr,
    0,
    [_aT, _tT, _eI, _rT, _iT, _iTT, _sc, _aAD],
    [[() => AccessToken, 0], 0, 1, [() => RefreshToken, 0], [() => IdToken, 0], 0, 64 | 0, () => AwsAdditionalDetails$]
];
export var RegisterClientRequest$ = [3, n0, _RCR,
    0,
    [_cN, _cT, _sco, _rUe, _gTr, _iU, _eAA],
    [0, 0, 64 | 0, 64 | 0, 64 | 0, 0, 0], 2
];
export var RegisterClientResponse$ = [3, n0, _RCRe,
    0,
    [_cI, _cS, _cIIA, _cSEA, _aE, _tE],
    [0, [() => ClientSecret, 0], 1, 1, 0, 0]
];
export var StartDeviceAuthorizationRequest$ = [3, n0, _SDAR,
    0,
    [_cI, _cS, _sU],
    [0, [() => ClientSecret, 0], 0], 3
];
export var StartDeviceAuthorizationResponse$ = [3, n0, _SDARt,
    0,
    [_dC, _uC, _vU, _vUC, _eI, _i],
    [0, 0, 0, 0, 1, 1]
];
var GrantTypes = 64 | 0;
var RedirectUris = 64 | 0;
var Scopes = 64 | 0;
export var CreateToken$ = [9, n0, _CT,
    { [_h]: ["POST", "/token", 200] }, () => CreateTokenRequest$, () => CreateTokenResponse$
];
export var CreateTokenWithIAM$ = [9, n0, _CTWIAM,
    { [_h]: ["POST", "/token?aws_iam=t", 200] }, () => CreateTokenWithIAMRequest$, () => CreateTokenWithIAMResponse$
];
export var RegisterClient$ = [9, n0, _RC,
    { [_h]: ["POST", "/client/register", 200] }, () => RegisterClientRequest$, () => RegisterClientResponse$
];
export var StartDeviceAuthorization$ = [9, n0, _SDA,
    { [_h]: ["POST", "/device_authorization", 200] }, () => StartDeviceAuthorizationRequest$, () => StartDeviceAuthorizationResponse$
];
