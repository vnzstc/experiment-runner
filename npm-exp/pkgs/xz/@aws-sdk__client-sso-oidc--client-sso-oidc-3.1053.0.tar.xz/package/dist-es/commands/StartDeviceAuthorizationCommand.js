import { Command as $Command } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "../endpoint/EndpointParameters";
import { StartDeviceAuthorization$ } from "../schemas/schemas_0";
export { $Command };
export class StartDeviceAuthorizationCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSSSOOIDCService", "StartDeviceAuthorization", {})
    .n("SSOOIDCClient", "StartDeviceAuthorizationCommand")
    .sc(StartDeviceAuthorization$)
    .build() {
}
