import { Command as $Command } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "../endpoint/EndpointParameters";
import { CreateTokenWithIAM$ } from "../schemas/schemas_0";
export { $Command };
export class CreateTokenWithIAMCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSSSOOIDCService", "CreateTokenWithIAM", {})
    .n("SSOOIDCClient", "CreateTokenWithIAMCommand")
    .sc(CreateTokenWithIAM$)
    .build() {
}
