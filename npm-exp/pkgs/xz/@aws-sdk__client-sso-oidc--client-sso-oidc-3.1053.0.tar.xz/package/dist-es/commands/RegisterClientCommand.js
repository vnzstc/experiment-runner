import { Command as $Command } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "../endpoint/EndpointParameters";
import { RegisterClient$ } from "../schemas/schemas_0";
export { $Command };
export class RegisterClientCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AWSSSOOIDCService", "RegisterClient", {})
    .n("SSOOIDCClient", "RegisterClientCommand")
    .sc(RegisterClient$)
    .build() {
}
