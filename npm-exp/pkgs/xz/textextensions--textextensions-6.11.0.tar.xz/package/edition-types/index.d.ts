/** List of text file extensions */
declare const list: string[];
export default list;
//# sourceMappingURL=index.d.ts.map