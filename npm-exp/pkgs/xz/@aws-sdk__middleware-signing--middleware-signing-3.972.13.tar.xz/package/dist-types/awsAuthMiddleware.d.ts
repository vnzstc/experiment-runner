import type { FinalizeRequestMiddleware, Pluggable, RelativeMiddlewareOptions } from "@smithy/types";
import type { AwsAuthResolvedConfig } from "./awsAuthConfiguration";
/**
 * @deprecated only used in legacy auth.
 */
export declare const awsAuthMiddleware: <Input extends object, Output extends object>(options: AwsAuthResolvedConfig) => FinalizeRequestMiddleware<Input, Output>;
/**
 * @deprecated only used in legacy auth.
 */
export declare const awsAuthMiddlewareOptions: RelativeMiddlewareOptions;
/**
 * @deprecated only used in legacy auth.
 */
export declare const getAwsAuthPlugin: (options: AwsAuthResolvedConfig) => Pluggable<any, any>;
/**
 * @deprecated only used in legacy auth.
 */
export declare const getSigV4AuthPlugin: (options: AwsAuthResolvedConfig) => Pluggable<any, any>;
