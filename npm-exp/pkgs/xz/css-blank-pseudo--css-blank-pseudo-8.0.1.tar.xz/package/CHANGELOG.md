# Changes to CSS Blank Pseudo

### 8.0.1

_January 14, 2026_

- Remove accidental direct dependency on `typescript`

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/css-blank-pseudo/CHANGELOG.md)
