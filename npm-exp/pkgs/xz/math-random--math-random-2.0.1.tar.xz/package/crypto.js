module.exports = require('crypto')
