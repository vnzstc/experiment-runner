module.exports = !!require('./crypto')
