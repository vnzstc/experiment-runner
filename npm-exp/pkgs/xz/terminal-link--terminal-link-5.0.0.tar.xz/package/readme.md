# terminal-link

> Create clickable links in the terminal

<img src="screenshot.gif" width="301" height="148">

## Install

```sh
npm install terminal-link
```

## Usage

```js
import terminalLink from 'terminal-link';

const link = terminalLink('My Website', 'https://sindresorhus.com');
console.log(link);
```

## API

### terminalLink(text, url, options?)

Create a link for use in stdout.

[Supported terminals.](https://gist.github.com/egmontkob/eb114294efbcd5adb1944c9f3cb5feda)

For unsupported terminals, by default the link will be printed as plain text with a space separator: `My website https://sindresorhus.com`.

#### text

Type: `string`

Text to linkify.

#### url

Type: `string`

URL to link to.

#### options

Type: `object`

##### fallback

Type: `function | boolean`

Override the default fallback. The function receives the `text` and `url` as parameters and is expected to return a string.

If set to `false`, the `text` will be returned as-is when a terminal is unsupported.

### terminalLink.isSupported

Type: `boolean`

Check whether the terminal's stdout supports links.

Prefer just using the default fallback or the `fallback` option whenever possible.

### terminalLink.stderr(text, url, options?)

Create a link for use in stderr.

Same arguments as `terminalLink()`.

### terminalLink.stderr.isSupported

Type: `boolean`

Check whether the terminal's stderr supports links.

Prefer just using the default fallback or the `fallback` option whenever possible.

## Related

- [terminal-link-cli](https://github.com/sindresorhus/terminal-link-cli) - CLI for this module
- [ink-link](https://github.com/sindresorhus/ink-link) - Link component for Ink
- [chalk](https://github.com/chalk/chalk) - Terminal string styling done right
