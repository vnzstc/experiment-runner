# Changes to PostCSS Custom Media

### 12.0.1

_February 21, 2026_

- Fix importance of custom media in anonymous cascade layers.

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-custom-media/CHANGELOG.md)
