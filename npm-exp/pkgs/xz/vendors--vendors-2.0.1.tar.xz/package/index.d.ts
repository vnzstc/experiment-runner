/**
 * List of vendor prefixes
 *
 * @type {string[]}
 */
export const vendors: string[]
