'use strict';

var client = require('@aws-sdk/core/client');



exports.getLoggerPlugin = client.getLoggerPlugin;
exports.loggerMiddleware = client.loggerMiddleware;
exports.loggerMiddlewareOptions = client.loggerMiddlewareOptions;
