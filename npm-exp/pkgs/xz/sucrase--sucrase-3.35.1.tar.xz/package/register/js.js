require("../dist/register").registerJS();
