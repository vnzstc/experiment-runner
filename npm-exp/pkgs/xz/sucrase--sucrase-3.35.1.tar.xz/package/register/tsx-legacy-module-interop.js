require("../dist/register").registerTSXLegacyModuleInterop();
