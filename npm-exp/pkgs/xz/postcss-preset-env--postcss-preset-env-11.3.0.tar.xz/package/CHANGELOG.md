# Changes to PostCSS Preset Env

### 11.3.0

_May 13, 2026_

- Added `@csstools/postcss-container-rule-prelude-list` [Check the plugin README](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-container-rule-prelude-list#readme) for usage details.
- Added `@csstools/postcss-image-function` [Check the plugin README](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-image-function#readme) for usage details.
- Updated [`cssdb`](https://github.com/csstools/cssdb) to [`8.9.0`](https://github.com/csstools/cssdb/blob/main/CHANGELOG.md#890-may-13-2026)

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugin-packs/postcss-preset-env/CHANGELOG.md)
