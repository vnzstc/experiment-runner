'use strict';

var client = require('@aws-sdk/core/client');



exports.DEFAULT_UA_APP_ID = client.DEFAULT_UA_APP_ID;
exports.getUserAgentMiddlewareOptions = client.getUserAgentMiddlewareOptions;
exports.getUserAgentPlugin = client.getUserAgentPlugin;
exports.resolveUserAgentConfig = client.resolveUserAgentConfig;
exports.userAgentMiddleware = client.userAgentMiddleware;
