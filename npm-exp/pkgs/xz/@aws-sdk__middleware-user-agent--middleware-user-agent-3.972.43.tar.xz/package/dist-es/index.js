export { DEFAULT_UA_APP_ID, resolveUserAgentConfig, userAgentMiddleware, getUserAgentMiddlewareOptions, getUserAgentPlugin, } from "@aws-sdk/core/client";
