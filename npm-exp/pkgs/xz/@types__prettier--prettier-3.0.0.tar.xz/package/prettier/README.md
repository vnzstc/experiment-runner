This is a stub types definition for @types/prettier (https://prettier.io).

prettier provides its own type definitions, so you don't need @types/prettier installed!