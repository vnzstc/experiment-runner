export const hasOwn = {}.hasOwnProperty
