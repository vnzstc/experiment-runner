# Changes to PostCSS Normalize Display Values

### 5.0.1

_January 25, 2026_

- Remove various combinations that are not part of the specification
- Allow keywords in various orders

[Full CHANGELOG](https://github.com/csstools/postcss-plugins/tree/main/plugins/postcss-normalize-display-values/CHANGELOG.md)
