export const name = 'removeViewBox';
export const description = 'removes viewBox attribute when possible';

const viewBoxElems = new Set(['pattern', 'svg', 'symbol']);

/**
 * Remove viewBox attr which coincides with a width/height box.
 *
 * @see https://www.w3.org/TR/SVG11/coords.html#ViewBoxAttribute
 *
 * @example
 * <svg width="100" height="50" viewBox="0 0 100 50">
 *  ⬇
 * <svg width="100" height="50">
 *
 * @author Kir Belevich
 *
 * @type {import('../lib/types.js').Plugin}
 */
export const fn = () => {
  return {
    element: {
      enter: (node, parentNode) => {
        if (
          viewBoxElems.has(node.name) &&
          node.attributes.viewBox != null &&
          node.attributes.width != null &&
          node.attributes.height != null
        ) {
          // TODO remove width/height for such case instead
          if (node.name === 'svg' && parentNode.type !== 'root') {
            return;
          }
          const numbers = node.attributes.viewBox.split(/[ ,]+/g);
          if (
            numbers[0] === '0' &&
            numbers[1] === '0' &&
            node.attributes.width.replace(/px$/, '') === numbers[2] && // could use parseFloat too
            node.attributes.height.replace(/px$/, '') === numbers[3]
          ) {
            delete node.attributes.viewBox;
          }
        }
      },
    },
  };
};
