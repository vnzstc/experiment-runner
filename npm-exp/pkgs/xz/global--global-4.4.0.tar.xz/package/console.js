module.exports = console;
