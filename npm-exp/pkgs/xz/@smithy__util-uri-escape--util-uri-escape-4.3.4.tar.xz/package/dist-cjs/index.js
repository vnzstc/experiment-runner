"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escapeUriPath = exports.escapeUri = void 0;
var protocols_1 = require("@smithy/core/protocols");
Object.defineProperty(exports, "escapeUri", { enumerable: true, get: function () { return protocols_1.escapeUri; } });
Object.defineProperty(exports, "escapeUriPath", { enumerable: true, get: function () { return protocols_1.escapeUriPath; } });
