export { escapeUri, escapeUriPath } from "@smithy/core/protocols";
