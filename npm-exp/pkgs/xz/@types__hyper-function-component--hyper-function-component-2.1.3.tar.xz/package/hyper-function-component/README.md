# Installation
> `npm install --save @types/hyper-function-component`

# Summary
This package contains type definitions for hyper-function-component (https://hyper-function.com/ponent).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hyper-function-component.
## [index.d.ts](https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/hyper-function-component/index.d.ts)
````ts
type HyperFunctionComponent =
    & ((
        container: Element,
        props: HfcProps,
    ) => {
        changed: (props: HfcProps) => void;
        disconnected: () => void;
    })
    & {
        tag: string;
        hfc: string;
        ver: string;
        // [AttrNames, EventNames, SlotNames]
        names: [string[], string[], string[]];
    };

interface HfcProps {
    attrs: { [k: string]: any };
    events: { [k: string]: (args?: { [k: string]: any }) => any };
    slots: {
        [k: string]: (
            container: Element,
            args?: { key?: string; [k: string]: any },
        ) => void;
    };
    others: { [k: string]: any };
}

````

### Additional Details
 * Last updated: Tue, 07 Nov 2023 03:09:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [terry-fei](https://github.com/terry-fei).
