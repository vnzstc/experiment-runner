"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/** List of binary file extensions */
const list = [
    'dds',
    'eot',
    'gif',
    'ico',
    'jar',
    'jpeg',
    'jpg',
    'pdf',
    'png',
    'swf',
    'tga',
    'ttf',
    'zip',
];
exports.default = list;
