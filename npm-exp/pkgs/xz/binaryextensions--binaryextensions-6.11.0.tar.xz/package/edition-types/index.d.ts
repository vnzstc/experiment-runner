/** List of binary file extensions */
declare const list: string[];
export default list;
//# sourceMappingURL=index.d.ts.map