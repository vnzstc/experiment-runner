"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isArrayBuffer = void 0;
var serde_1 = require("@smithy/core/serde");
Object.defineProperty(exports, "isArrayBuffer", { enumerable: true, get: function () { return serde_1.isArrayBuffer; } });
