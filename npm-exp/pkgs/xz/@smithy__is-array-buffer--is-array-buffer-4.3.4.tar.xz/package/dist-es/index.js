export { isArrayBuffer } from "@smithy/core/serde";
