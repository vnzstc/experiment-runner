This is a stub types definition for @types/mime (https://github.com/broofa/mime#readme).

mime provides its own type definitions, so you don't need @types/mime installed!