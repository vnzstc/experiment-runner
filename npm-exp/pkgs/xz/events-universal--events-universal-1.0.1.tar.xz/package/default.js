module.exports = require('events')
