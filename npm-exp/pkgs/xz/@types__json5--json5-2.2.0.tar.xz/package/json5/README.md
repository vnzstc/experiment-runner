This is a stub types definition for @types/json5 (http://json5.org/).

json5 provides its own type definitions, so you don't need @types/json5 installed!