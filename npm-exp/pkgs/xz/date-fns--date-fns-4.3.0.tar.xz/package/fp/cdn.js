(() => {
function _createForOfIteratorHelper(r, e) {var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];if (!t) {if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) {t && (r = t);var _n = 0,F = function F() {};return { s: F, n: function n() {return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] };}, e: function e(r) {throw r;}, f: F };}throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");}var o,a = !0,u = !1;return { s: function s() {t = t.call(r);}, n: function n() {var r = t.next();return a = r.done, r;}, e: function e(r) {u = !0, o = r;}, f: function f() {try {a || null == t.return || t.return();} finally {if (u) throw o;}} };}function _callSuper(t, o, e) {return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));}function _possibleConstructorReturn(t, e) {if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");return _assertThisInitialized(t);}function _assertThisInitialized(e) {if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return e;}function _isNativeReflectConstruct() {try {var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));} catch (t) {}return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {return !!t;})();}function _getPrototypeOf(t) {return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {return t.__proto__ || Object.getPrototypeOf(t);}, _getPrototypeOf(t);}function _inherits(t, e) {if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");t.prototype = Object.create(e && e.prototype, { constructor: { value: t, writable: !0, configurable: !0 } }), Object.defineProperty(t, "prototype", { writable: !1 }), e && _setPrototypeOf(t, e);}function _setPrototypeOf(t, e) {return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {return t.__proto__ = e, t;}, _setPrototypeOf(t, e);}function _classCallCheck(a, n) {if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");}function _defineProperties(e, r) {for (var t = 0; t < r.length; t++) {var o = r[t];o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);}}function _createClass(e, r, t) {return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;}function _toArray(r) {return _arrayWithHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableRest();}function _slicedToArray(r, e) {return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();}function _nonIterableRest() {throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");}function _iterableToArrayLimit(r, l) {var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];if (null != t) {var e,n,i,u,a = [],f = !0,o = !1;try {if (i = (t = t.call(r)).next, 0 === l) {if (Object(t) !== t) return;f = !1;} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);} catch (r) {o = !0, n = r;} finally {try {if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;} finally {if (o) throw n;}}return a;}}function _arrayWithHoles(r) {if (Array.isArray(r)) return r;}function ownKeys(e, r) {var t = Object.keys(e);if (Object.getOwnPropertySymbols) {var o = Object.getOwnPropertySymbols(e);r && (o = o.filter(function (r) {return Object.getOwnPropertyDescriptor(e, r).enumerable;})), t.push.apply(t, o);}return t;}function _objectSpread(e) {for (var r = 1; r < arguments.length; r++) {var t = null != arguments[r] ? arguments[r] : {};r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {_defineProperty(e, r, t[r]);}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));});}return e;}function _defineProperty(e, r, t) {return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e;}function _toPropertyKey(t) {var i = _toPrimitive(t, "string");return "symbol" == _typeof(i) ? i : i + "";}function _toPrimitive(t, r) {if ("object" != _typeof(t) || !t) return t;var e = t[Symbol.toPrimitive];if (void 0 !== e) {var i = e.call(t, r || "default");if ("object" != _typeof(i)) return i;throw new TypeError("@@toPrimitive must return a primitive value.");}return ("string" === r ? String : Number)(t);}function _toConsumableArray(r) {return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();}function _nonIterableSpread() {throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");}function _unsupportedIterableToArray(r, a) {if (r) {if ("string" == typeof r) return _arrayLikeToArray(r, a);var t = {}.toString.call(r).slice(8, -1);return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;}}function _iterableToArray(r) {if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);}function _arrayWithoutHoles(r) {if (Array.isArray(r)) return _arrayLikeToArray(r);}function _arrayLikeToArray(r, a) {(null == a || a > r.length) && (a = r.length);for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];return n;}function _typeof(o) {"@babel/helpers - typeof";return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {return typeof o;} : function (o) {return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;}, _typeof(o);}var __defProp = Object.defineProperty;
var __returnValue = function __returnValue(v) {return v;};
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = function __export(target, all) {
  for (var name in all)
  __defProp(target, name, {
    get: all[name],
    enumerable: true,
    configurable: true,
    set: __exportSetter.bind(all, name)
  });
};

// dist/fp.js
var exports_fp = {};
__export(exports_fp, {
  yearsToQuarters: function yearsToQuarters() {return yearsToQuarters2;},
  yearsToMonths: function yearsToMonths() {return yearsToMonths2;},
  yearsToDays: function yearsToDays() {return yearsToDays2;},
  weeksToDays: function weeksToDays() {return weeksToDays2;},
  transpose: function transpose() {return transpose2;},
  toDate: function toDate() {return toDate2;},
  subYearsWithOptions: function subYearsWithOptions() {return _subYearsWithOptions;},
  subYears: function subYears() {return subYears2;},
  subWithOptions: function subWithOptions() {return _subWithOptions;},
  subWeeksWithOptions: function subWeeksWithOptions() {return _subWeeksWithOptions;},
  subWeeks: function subWeeks() {return subWeeks2;},
  subSecondsWithOptions: function subSecondsWithOptions() {return _subSecondsWithOptions;},
  subSeconds: function subSeconds() {return subSeconds2;},
  subQuartersWithOptions: function subQuartersWithOptions() {return _subQuartersWithOptions;},
  subQuarters: function subQuarters() {return subQuarters2;},
  subMonthsWithOptions: function subMonthsWithOptions() {return _subMonthsWithOptions;},
  subMonths: function subMonths() {return subMonths2;},
  subMinutesWithOptions: function subMinutesWithOptions() {return _subMinutesWithOptions;},
  subMinutes: function subMinutes() {return subMinutes2;},
  subMillisecondsWithOptions: function subMillisecondsWithOptions() {return _subMillisecondsWithOptions;},
  subMilliseconds: function subMilliseconds() {return subMilliseconds2;},
  subISOWeekYearsWithOptions: function subISOWeekYearsWithOptions() {return _subISOWeekYearsWithOptions;},
  subISOWeekYears: function subISOWeekYears() {return subISOWeekYears2;},
  subHoursWithOptions: function subHoursWithOptions() {return _subHoursWithOptions;},
  subHours: function subHours() {return subHours2;},
  subDaysWithOptions: function subDaysWithOptions() {return _subDaysWithOptions;},
  subDays: function subDays() {return subDays2;},
  subBusinessDaysWithOptions: function subBusinessDaysWithOptions() {return _subBusinessDaysWithOptions;},
  subBusinessDays: function subBusinessDays() {return subBusinessDays2;},
  sub: function sub() {return sub2;},
  startOfYearWithOptions: function startOfYearWithOptions() {return _startOfYearWithOptions;},
  startOfYear: function startOfYear() {return startOfYear2;},
  startOfWeekYearWithOptions: function startOfWeekYearWithOptions() {return _startOfWeekYearWithOptions;},
  startOfWeekYear: function startOfWeekYear() {return startOfWeekYear2;},
  startOfWeekWithOptions: function startOfWeekWithOptions() {return _startOfWeekWithOptions;},
  startOfWeek: function startOfWeek() {return startOfWeek2;},
  startOfSecondWithOptions: function startOfSecondWithOptions() {return _startOfSecondWithOptions;},
  startOfSecond: function startOfSecond() {return startOfSecond2;},
  startOfQuarterWithOptions: function startOfQuarterWithOptions() {return _startOfQuarterWithOptions;},
  startOfQuarter: function startOfQuarter() {return startOfQuarter2;},
  startOfMonthWithOptions: function startOfMonthWithOptions() {return _startOfMonthWithOptions;},
  startOfMonth: function startOfMonth() {return startOfMonth2;},
  startOfMinuteWithOptions: function startOfMinuteWithOptions() {return _startOfMinuteWithOptions;},
  startOfMinute: function startOfMinute() {return startOfMinute2;},
  startOfISOWeekYearWithOptions: function startOfISOWeekYearWithOptions() {return _startOfISOWeekYearWithOptions;},
  startOfISOWeekYear: function startOfISOWeekYear() {return startOfISOWeekYear2;},
  startOfISOWeekWithOptions: function startOfISOWeekWithOptions() {return _startOfISOWeekWithOptions;},
  startOfISOWeek: function startOfISOWeek() {return startOfISOWeek2;},
  startOfHourWithOptions: function startOfHourWithOptions() {return _startOfHourWithOptions;},
  startOfHour: function startOfHour() {return startOfHour2;},
  startOfDecadeWithOptions: function startOfDecadeWithOptions() {return _startOfDecadeWithOptions;},
  startOfDecade: function startOfDecade() {return startOfDecade2;},
  startOfDayWithOptions: function startOfDayWithOptions() {return _startOfDayWithOptions;},
  startOfDay: function startOfDay() {return startOfDay2;},
  setYearWithOptions: function setYearWithOptions() {return _setYearWithOptions;},
  setYear: function setYear() {return setYear2;},
  setWithOptions: function setWithOptions() {return _setWithOptions;},
  setWeekYearWithOptions: function setWeekYearWithOptions() {return _setWeekYearWithOptions;},
  setWeekYear: function setWeekYear() {return setWeekYear2;},
  setWeekWithOptions: function setWeekWithOptions() {return _setWeekWithOptions;},
  setWeek: function setWeek() {return setWeek2;},
  setSecondsWithOptions: function setSecondsWithOptions() {return _setSecondsWithOptions;},
  setSeconds: function setSeconds() {return setSeconds2;},
  setQuarterWithOptions: function setQuarterWithOptions() {return _setQuarterWithOptions;},
  setQuarter: function setQuarter() {return setQuarter2;},
  setMonthWithOptions: function setMonthWithOptions() {return _setMonthWithOptions;},
  setMonth: function setMonth() {return setMonth2;},
  setMinutesWithOptions: function setMinutesWithOptions() {return _setMinutesWithOptions;},
  setMinutes: function setMinutes() {return setMinutes2;},
  setMillisecondsWithOptions: function setMillisecondsWithOptions() {return _setMillisecondsWithOptions;},
  setMilliseconds: function setMilliseconds() {return setMilliseconds2;},
  setISOWeekYearWithOptions: function setISOWeekYearWithOptions() {return _setISOWeekYearWithOptions;},
  setISOWeekYear: function setISOWeekYear() {return setISOWeekYear2;},
  setISOWeekWithOptions: function setISOWeekWithOptions() {return _setISOWeekWithOptions;},
  setISOWeek: function setISOWeek() {return setISOWeek2;},
  setISODayWithOptions: function setISODayWithOptions() {return _setISODayWithOptions;},
  setISODay: function setISODay() {return setISODay2;},
  setHoursWithOptions: function setHoursWithOptions() {return _setHoursWithOptions;},
  setHours: function setHours() {return setHours2;},
  setDayWithOptions: function setDayWithOptions() {return _setDayWithOptions;},
  setDayOfYearWithOptions: function setDayOfYearWithOptions() {return _setDayOfYearWithOptions;},
  setDayOfYear: function setDayOfYear() {return setDayOfYear2;},
  setDay: function setDay() {return setDay2;},
  setDateWithOptions: function setDateWithOptions() {return _setDateWithOptions;},
  setDate: function setDate() {return setDate2;},
  set: function set() {return set2;},
  secondsToMinutes: function secondsToMinutes() {return secondsToMinutes2;},
  secondsToMilliseconds: function secondsToMilliseconds() {return secondsToMilliseconds2;},
  secondsToHours: function secondsToHours() {return secondsToHours2;},
  roundToNearestMinutesWithOptions: function roundToNearestMinutesWithOptions() {return _roundToNearestMinutesWithOptions;},
  roundToNearestMinutes: function roundToNearestMinutes() {return roundToNearestMinutes2;},
  roundToNearestHoursWithOptions: function roundToNearestHoursWithOptions() {return _roundToNearestHoursWithOptions;},
  roundToNearestHours: function roundToNearestHours() {return roundToNearestHours2;},
  quartersToYears: function quartersToYears() {return quartersToYears2;},
  quartersToMonths: function quartersToMonths() {return quartersToMonths2;},
  previousWednesdayWithOptions: function previousWednesdayWithOptions() {return _previousWednesdayWithOptions;},
  previousWednesday: function previousWednesday() {return previousWednesday2;},
  previousTuesdayWithOptions: function previousTuesdayWithOptions() {return _previousTuesdayWithOptions;},
  previousTuesday: function previousTuesday() {return previousTuesday2;},
  previousThursdayWithOptions: function previousThursdayWithOptions() {return _previousThursdayWithOptions;},
  previousThursday: function previousThursday() {return previousThursday2;},
  previousSundayWithOptions: function previousSundayWithOptions() {return _previousSundayWithOptions;},
  previousSunday: function previousSunday() {return previousSunday2;},
  previousSaturdayWithOptions: function previousSaturdayWithOptions() {return _previousSaturdayWithOptions;},
  previousSaturday: function previousSaturday() {return previousSaturday2;},
  previousMondayWithOptions: function previousMondayWithOptions() {return _previousMondayWithOptions;},
  previousMonday: function previousMonday() {return previousMonday2;},
  previousFridayWithOptions: function previousFridayWithOptions() {return _previousFridayWithOptions;},
  previousFriday: function previousFriday() {return previousFriday2;},
  previousDayWithOptions: function previousDayWithOptions() {return _previousDayWithOptions;},
  previousDay: function previousDay() {return previousDay2;},
  parseWithOptions: function parseWithOptions() {return _parseWithOptions;},
  parseJSONWithOptions: function parseJSONWithOptions() {return _parseJSONWithOptions;},
  parseJSON: function parseJSON() {return parseJSON2;},
  parseISOWithOptions: function parseISOWithOptions() {return _parseISOWithOptions;},
  parseISO: function parseISO() {return parseISO2;},
  parse: function parse() {return parse2;},
  nextWednesdayWithOptions: function nextWednesdayWithOptions() {return _nextWednesdayWithOptions;},
  nextWednesday: function nextWednesday() {return nextWednesday2;},
  nextTuesdayWithOptions: function nextTuesdayWithOptions() {return _nextTuesdayWithOptions;},
  nextTuesday: function nextTuesday() {return nextTuesday2;},
  nextThursdayWithOptions: function nextThursdayWithOptions() {return _nextThursdayWithOptions;},
  nextThursday: function nextThursday() {return nextThursday2;},
  nextSundayWithOptions: function nextSundayWithOptions() {return _nextSundayWithOptions;},
  nextSunday: function nextSunday() {return nextSunday2;},
  nextSaturdayWithOptions: function nextSaturdayWithOptions() {return _nextSaturdayWithOptions;},
  nextSaturday: function nextSaturday() {return nextSaturday2;},
  nextMondayWithOptions: function nextMondayWithOptions() {return _nextMondayWithOptions;},
  nextMonday: function nextMonday() {return nextMonday2;},
  nextFridayWithOptions: function nextFridayWithOptions() {return _nextFridayWithOptions;},
  nextFriday: function nextFriday() {return nextFriday2;},
  nextDayWithOptions: function nextDayWithOptions() {return _nextDayWithOptions;},
  nextDay: function nextDay() {return nextDay2;},
  monthsToYears: function monthsToYears() {return monthsToYears2;},
  monthsToQuarters: function monthsToQuarters() {return monthsToQuarters2;},
  minutesToSeconds: function minutesToSeconds() {return minutesToSeconds2;},
  minutesToMilliseconds: function minutesToMilliseconds() {return minutesToMilliseconds2;},
  minutesToHours: function minutesToHours() {return minutesToHours2;},
  minWithOptions: function minWithOptions() {return _minWithOptions;},
  min: function min() {return min2;},
  millisecondsToSeconds: function millisecondsToSeconds() {return millisecondsToSeconds2;},
  millisecondsToMinutes: function millisecondsToMinutes() {return millisecondsToMinutes2;},
  millisecondsToHours: function millisecondsToHours() {return millisecondsToHours2;},
  milliseconds: function milliseconds() {return milliseconds2;},
  maxWithOptions: function maxWithOptions() {return _maxWithOptions;},
  max: function max() {return max2;},
  lightFormat: function lightFormat() {return lightFormat2;},
  lastDayOfYearWithOptions: function lastDayOfYearWithOptions() {return _lastDayOfYearWithOptions;},
  lastDayOfYear: function lastDayOfYear() {return lastDayOfYear2;},
  lastDayOfWeekWithOptions: function lastDayOfWeekWithOptions() {return _lastDayOfWeekWithOptions;},
  lastDayOfWeek: function lastDayOfWeek() {return lastDayOfWeek2;},
  lastDayOfQuarterWithOptions: function lastDayOfQuarterWithOptions() {return _lastDayOfQuarterWithOptions;},
  lastDayOfQuarter: function lastDayOfQuarter() {return lastDayOfQuarter2;},
  lastDayOfMonthWithOptions: function lastDayOfMonthWithOptions() {return _lastDayOfMonthWithOptions;},
  lastDayOfMonth: function lastDayOfMonth() {return lastDayOfMonth2;},
  lastDayOfISOWeekYearWithOptions: function lastDayOfISOWeekYearWithOptions() {return _lastDayOfISOWeekYearWithOptions;},
  lastDayOfISOWeekYear: function lastDayOfISOWeekYear() {return lastDayOfISOWeekYear2;},
  lastDayOfISOWeekWithOptions: function lastDayOfISOWeekWithOptions() {return _lastDayOfISOWeekWithOptions;},
  lastDayOfISOWeek: function lastDayOfISOWeek() {return lastDayOfISOWeek2;},
  lastDayOfDecadeWithOptions: function lastDayOfDecadeWithOptions() {return _lastDayOfDecadeWithOptions;},
  lastDayOfDecade: function lastDayOfDecade() {return lastDayOfDecade2;},
  isWithinIntervalWithOptions: function isWithinIntervalWithOptions() {return _isWithinIntervalWithOptions;},
  isWithinInterval: function isWithinInterval() {return isWithinInterval2;},
  isWeekendWithOptions: function isWeekendWithOptions() {return _isWeekendWithOptions;},
  isWeekend: function isWeekend() {return isWeekend2;},
  isWednesdayWithOptions: function isWednesdayWithOptions() {return _isWednesdayWithOptions;},
  isWednesday: function isWednesday() {return isWednesday2;},
  isValid: function isValid() {return isValid2;},
  isTuesdayWithOptions: function isTuesdayWithOptions() {return _isTuesdayWithOptions;},
  isTuesday: function isTuesday() {return isTuesday2;},
  isThursdayWithOptions: function isThursdayWithOptions() {return _isThursdayWithOptions;},
  isThursday: function isThursday() {return isThursday2;},
  isSundayWithOptions: function isSundayWithOptions() {return _isSundayWithOptions;},
  isSunday: function isSunday() {return isSunday2;},
  isSaturdayWithOptions: function isSaturdayWithOptions() {return _isSaturdayWithOptions;},
  isSaturday: function isSaturday() {return isSaturday2;},
  isSameYearWithOptions: function isSameYearWithOptions() {return _isSameYearWithOptions;},
  isSameYear: function isSameYear() {return isSameYear2;},
  isSameWeekWithOptions: function isSameWeekWithOptions() {return _isSameWeekWithOptions;},
  isSameWeek: function isSameWeek() {return isSameWeek2;},
  isSameSecond: function isSameSecond() {return isSameSecond2;},
  isSameQuarterWithOptions: function isSameQuarterWithOptions() {return _isSameQuarterWithOptions;},
  isSameQuarter: function isSameQuarter() {return isSameQuarter2;},
  isSameMonthWithOptions: function isSameMonthWithOptions() {return _isSameMonthWithOptions;},
  isSameMonth: function isSameMonth() {return isSameMonth2;},
  isSameMinute: function isSameMinute() {return isSameMinute2;},
  isSameISOWeekYearWithOptions: function isSameISOWeekYearWithOptions() {return _isSameISOWeekYearWithOptions;},
  isSameISOWeekYear: function isSameISOWeekYear() {return isSameISOWeekYear2;},
  isSameISOWeekWithOptions: function isSameISOWeekWithOptions() {return _isSameISOWeekWithOptions;},
  isSameISOWeek: function isSameISOWeek() {return isSameISOWeek2;},
  isSameHourWithOptions: function isSameHourWithOptions() {return _isSameHourWithOptions;},
  isSameHour: function isSameHour() {return isSameHour2;},
  isSameDayWithOptions: function isSameDayWithOptions() {return _isSameDayWithOptions;},
  isSameDay: function isSameDay() {return isSameDay2;},
  isMondayWithOptions: function isMondayWithOptions() {return _isMondayWithOptions;},
  isMonday: function isMonday() {return isMonday2;},
  isMatchWithOptions: function isMatchWithOptions() {return _isMatchWithOptions;},
  isMatch: function isMatch() {return isMatch2;},
  isLeapYearWithOptions: function isLeapYearWithOptions() {return _isLeapYearWithOptions;},
  isLeapYear: function isLeapYear() {return isLeapYear2;},
  isLastDayOfMonthWithOptions: function isLastDayOfMonthWithOptions() {return _isLastDayOfMonthWithOptions;},
  isLastDayOfMonth: function isLastDayOfMonth() {return isLastDayOfMonth2;},
  isFridayWithOptions: function isFridayWithOptions() {return _isFridayWithOptions;},
  isFriday: function isFriday() {return isFriday2;},
  isFirstDayOfMonthWithOptions: function isFirstDayOfMonthWithOptions() {return _isFirstDayOfMonthWithOptions;},
  isFirstDayOfMonth: function isFirstDayOfMonth() {return isFirstDayOfMonth2;},
  isExists: function isExists() {return isExists2;},
  isEqual: function isEqual() {return isEqual2;},
  isDate: function isDate() {return isDate2;},
  isBefore: function isBefore() {return isBefore2;},
  isAfter: function isAfter() {return isAfter2;},
  intlFormatDistanceWithOptions: function intlFormatDistanceWithOptions() {return _intlFormatDistanceWithOptions;},
  intlFormatDistance: function intlFormatDistance() {return intlFormatDistance2;},
  intlFormat: function intlFormat() {return intlFormat2;},
  intervalWithOptions: function intervalWithOptions() {return _intervalWithOptions;},
  intervalToDurationWithOptions: function intervalToDurationWithOptions() {return _intervalToDurationWithOptions;},
  intervalToDuration: function intervalToDuration() {return intervalToDuration2;},
  interval: function interval() {return interval2;},
  hoursToSeconds: function hoursToSeconds() {return hoursToSeconds2;},
  hoursToMinutes: function hoursToMinutes() {return hoursToMinutes2;},
  hoursToMilliseconds: function hoursToMilliseconds() {return hoursToMilliseconds2;},
  getYearWithOptions: function getYearWithOptions() {return _getYearWithOptions;},
  getYear: function getYear() {return getYear2;},
  getWeeksInMonthWithOptions: function getWeeksInMonthWithOptions() {return _getWeeksInMonthWithOptions;},
  getWeeksInMonth: function getWeeksInMonth() {return getWeeksInMonth2;},
  getWeekYearWithOptions: function getWeekYearWithOptions() {return _getWeekYearWithOptions;},
  getWeekYear: function getWeekYear() {return getWeekYear2;},
  getWeekWithOptions: function getWeekWithOptions() {return _getWeekWithOptions;},
  getWeekOfMonthWithOptions: function getWeekOfMonthWithOptions() {return _getWeekOfMonthWithOptions;},
  getWeekOfMonth: function getWeekOfMonth() {return getWeekOfMonth2;},
  getWeek: function getWeek() {return getWeek2;},
  getUnixTime: function getUnixTime() {return getUnixTime2;},
  getTime: function getTime() {return getTime2;},
  getSeconds: function getSeconds() {return getSeconds2;},
  getQuarterWithOptions: function getQuarterWithOptions() {return _getQuarterWithOptions;},
  getQuarter: function getQuarter() {return getQuarter2;},
  getOverlappingDaysInIntervals: function getOverlappingDaysInIntervals() {return getOverlappingDaysInIntervals2;},
  getMonthWithOptions: function getMonthWithOptions() {return _getMonthWithOptions;},
  getMonth: function getMonth() {return getMonth2;},
  getMinutesWithOptions: function getMinutesWithOptions() {return _getMinutesWithOptions;},
  getMinutes: function getMinutes() {return getMinutes2;},
  getMilliseconds: function getMilliseconds() {return getMilliseconds2;},
  getISOWeeksInYearWithOptions: function getISOWeeksInYearWithOptions() {return _getISOWeeksInYearWithOptions;},
  getISOWeeksInYear: function getISOWeeksInYear() {return getISOWeeksInYear2;},
  getISOWeekYearWithOptions: function getISOWeekYearWithOptions() {return _getISOWeekYearWithOptions;},
  getISOWeekYear: function getISOWeekYear() {return getISOWeekYear2;},
  getISOWeekWithOptions: function getISOWeekWithOptions() {return _getISOWeekWithOptions;},
  getISOWeek: function getISOWeek() {return getISOWeek2;},
  getISODayWithOptions: function getISODayWithOptions() {return _getISODayWithOptions;},
  getISODay: function getISODay() {return getISODay2;},
  getHoursWithOptions: function getHoursWithOptions() {return _getHoursWithOptions;},
  getHours: function getHours() {return getHours2;},
  getDecadeWithOptions: function getDecadeWithOptions() {return _getDecadeWithOptions;},
  getDecade: function getDecade() {return getDecade2;},
  getDaysInYearWithOptions: function getDaysInYearWithOptions() {return _getDaysInYearWithOptions;},
  getDaysInYear: function getDaysInYear() {return getDaysInYear2;},
  getDaysInMonthWithOptions: function getDaysInMonthWithOptions() {return _getDaysInMonthWithOptions;},
  getDaysInMonth: function getDaysInMonth() {return getDaysInMonth2;},
  getDayWithOptions: function getDayWithOptions() {return _getDayWithOptions;},
  getDayOfYearWithOptions: function getDayOfYearWithOptions() {return _getDayOfYearWithOptions;},
  getDayOfYear: function getDayOfYear() {return getDayOfYear2;},
  getDay: function getDay() {return getDay2;},
  getDateWithOptions: function getDateWithOptions() {return _getDateWithOptions;},
  getDate: function getDate() {return getDate2;},
  fromUnixTimeWithOptions: function fromUnixTimeWithOptions() {return _fromUnixTimeWithOptions;},
  fromUnixTime: function fromUnixTime() {return fromUnixTime2;},
  formatWithOptions: function formatWithOptions() {return _formatWithOptions;},
  formatRelativeWithOptions: function formatRelativeWithOptions() {return _formatRelativeWithOptions;},
  formatRelative: function formatRelative() {return formatRelative3;},
  formatRFC7231: function formatRFC7231() {return formatRFC72312;},
  formatRFC3339WithOptions: function formatRFC3339WithOptions() {return _formatRFC3339WithOptions;},
  formatRFC3339: function formatRFC3339() {return formatRFC33392;},
  formatISOWithOptions: function formatISOWithOptions() {return _formatISOWithOptions;},
  formatISODuration: function formatISODuration() {return formatISODuration2;},
  formatISO9075WithOptions: function formatISO9075WithOptions() {return _formatISO9075WithOptions;},
  formatISO9075: function formatISO9075() {return formatISO90752;},
  formatISO: function formatISO() {return formatISO2;},
  formatDurationWithOptions: function formatDurationWithOptions() {return _formatDurationWithOptions;},
  formatDuration: function formatDuration() {return formatDuration2;},
  formatDistanceWithOptions: function formatDistanceWithOptions() {return _formatDistanceWithOptions;},
  formatDistanceStrictWithOptions: function formatDistanceStrictWithOptions() {return _formatDistanceStrictWithOptions;},
  formatDistanceStrict: function formatDistanceStrict() {return formatDistanceStrict2;},
  formatDistance: function formatDistance() {return formatDistance3;},
  format: function format() {return format2;},
  endOfYearWithOptions: function endOfYearWithOptions() {return _endOfYearWithOptions;},
  endOfYear: function endOfYear() {return endOfYear2;},
  endOfWeekWithOptions: function endOfWeekWithOptions() {return _endOfWeekWithOptions;},
  endOfWeek: function endOfWeek() {return endOfWeek2;},
  endOfSecondWithOptions: function endOfSecondWithOptions() {return _endOfSecondWithOptions;},
  endOfSecond: function endOfSecond() {return endOfSecond2;},
  endOfQuarterWithOptions: function endOfQuarterWithOptions() {return _endOfQuarterWithOptions;},
  endOfQuarter: function endOfQuarter() {return endOfQuarter2;},
  endOfMonthWithOptions: function endOfMonthWithOptions() {return _endOfMonthWithOptions;},
  endOfMonth: function endOfMonth() {return endOfMonth2;},
  endOfMinuteWithOptions: function endOfMinuteWithOptions() {return _endOfMinuteWithOptions;},
  endOfMinute: function endOfMinute() {return endOfMinute2;},
  endOfISOWeekYearWithOptions: function endOfISOWeekYearWithOptions() {return _endOfISOWeekYearWithOptions;},
  endOfISOWeekYear: function endOfISOWeekYear() {return endOfISOWeekYear2;},
  endOfISOWeekWithOptions: function endOfISOWeekWithOptions() {return _endOfISOWeekWithOptions;},
  endOfISOWeek: function endOfISOWeek() {return endOfISOWeek2;},
  endOfHourWithOptions: function endOfHourWithOptions() {return _endOfHourWithOptions;},
  endOfHour: function endOfHour() {return endOfHour2;},
  endOfDecadeWithOptions: function endOfDecadeWithOptions() {return _endOfDecadeWithOptions;},
  endOfDecade: function endOfDecade() {return endOfDecade2;},
  endOfDayWithOptions: function endOfDayWithOptions() {return _endOfDayWithOptions;},
  endOfDay: function endOfDay() {return endOfDay2;},
  eachYearOfIntervalWithOptions: function eachYearOfIntervalWithOptions() {return _eachYearOfIntervalWithOptions;},
  eachYearOfInterval: function eachYearOfInterval() {return eachYearOfInterval2;},
  eachWeekendOfYearWithOptions: function eachWeekendOfYearWithOptions() {return _eachWeekendOfYearWithOptions;},
  eachWeekendOfYear: function eachWeekendOfYear() {return eachWeekendOfYear2;},
  eachWeekendOfMonthWithOptions: function eachWeekendOfMonthWithOptions() {return _eachWeekendOfMonthWithOptions;},
  eachWeekendOfMonth: function eachWeekendOfMonth() {return eachWeekendOfMonth2;},
  eachWeekendOfIntervalWithOptions: function eachWeekendOfIntervalWithOptions() {return _eachWeekendOfIntervalWithOptions;},
  eachWeekendOfInterval: function eachWeekendOfInterval() {return eachWeekendOfInterval2;},
  eachWeekOfIntervalWithOptions: function eachWeekOfIntervalWithOptions() {return _eachWeekOfIntervalWithOptions;},
  eachWeekOfInterval: function eachWeekOfInterval() {return eachWeekOfInterval2;},
  eachQuarterOfIntervalWithOptions: function eachQuarterOfIntervalWithOptions() {return _eachQuarterOfIntervalWithOptions;},
  eachQuarterOfInterval: function eachQuarterOfInterval() {return eachQuarterOfInterval2;},
  eachMonthOfIntervalWithOptions: function eachMonthOfIntervalWithOptions() {return _eachMonthOfIntervalWithOptions;},
  eachMonthOfInterval: function eachMonthOfInterval() {return eachMonthOfInterval2;},
  eachMinuteOfIntervalWithOptions: function eachMinuteOfIntervalWithOptions() {return _eachMinuteOfIntervalWithOptions;},
  eachMinuteOfInterval: function eachMinuteOfInterval() {return eachMinuteOfInterval2;},
  eachHourOfIntervalWithOptions: function eachHourOfIntervalWithOptions() {return _eachHourOfIntervalWithOptions;},
  eachHourOfInterval: function eachHourOfInterval() {return eachHourOfInterval2;},
  eachDayOfIntervalWithOptions: function eachDayOfIntervalWithOptions() {return _eachDayOfIntervalWithOptions;},
  eachDayOfInterval: function eachDayOfInterval() {return eachDayOfInterval2;},
  differenceInYearsWithOptions: function differenceInYearsWithOptions() {return _differenceInYearsWithOptions;},
  differenceInYears: function differenceInYears() {return differenceInYears2;},
  differenceInWeeksWithOptions: function differenceInWeeksWithOptions() {return _differenceInWeeksWithOptions;},
  differenceInWeeks: function differenceInWeeks() {return differenceInWeeks2;},
  differenceInSecondsWithOptions: function differenceInSecondsWithOptions() {return _differenceInSecondsWithOptions;},
  differenceInSeconds: function differenceInSeconds() {return differenceInSeconds2;},
  differenceInQuartersWithOptions: function differenceInQuartersWithOptions() {return _differenceInQuartersWithOptions;},
  differenceInQuarters: function differenceInQuarters() {return differenceInQuarters2;},
  differenceInMonthsWithOptions: function differenceInMonthsWithOptions() {return _differenceInMonthsWithOptions;},
  differenceInMonths: function differenceInMonths() {return differenceInMonths2;},
  differenceInMinutesWithOptions: function differenceInMinutesWithOptions() {return _differenceInMinutesWithOptions;},
  differenceInMinutes: function differenceInMinutes() {return differenceInMinutes2;},
  differenceInMilliseconds: function differenceInMilliseconds() {return differenceInMilliseconds2;},
  differenceInISOWeekYearsWithOptions: function differenceInISOWeekYearsWithOptions() {return _differenceInISOWeekYearsWithOptions;},
  differenceInISOWeekYears: function differenceInISOWeekYears() {return differenceInISOWeekYears2;},
  differenceInHoursWithOptions: function differenceInHoursWithOptions() {return _differenceInHoursWithOptions;},
  differenceInHours: function differenceInHours() {return differenceInHours2;},
  differenceInDaysWithOptions: function differenceInDaysWithOptions() {return _differenceInDaysWithOptions;},
  differenceInDays: function differenceInDays() {return differenceInDays2;},
  differenceInCalendarYearsWithOptions: function differenceInCalendarYearsWithOptions() {return _differenceInCalendarYearsWithOptions;},
  differenceInCalendarYears: function differenceInCalendarYears() {return differenceInCalendarYears2;},
  differenceInCalendarWeeksWithOptions: function differenceInCalendarWeeksWithOptions() {return _differenceInCalendarWeeksWithOptions;},
  differenceInCalendarWeeks: function differenceInCalendarWeeks() {return differenceInCalendarWeeks2;},
  differenceInCalendarQuartersWithOptions: function differenceInCalendarQuartersWithOptions() {return _differenceInCalendarQuartersWithOptions;},
  differenceInCalendarQuarters: function differenceInCalendarQuarters() {return differenceInCalendarQuarters2;},
  differenceInCalendarMonthsWithOptions: function differenceInCalendarMonthsWithOptions() {return _differenceInCalendarMonthsWithOptions;},
  differenceInCalendarMonths: function differenceInCalendarMonths() {return differenceInCalendarMonths2;},
  differenceInCalendarISOWeeksWithOptions: function differenceInCalendarISOWeeksWithOptions() {return _differenceInCalendarISOWeeksWithOptions;},
  differenceInCalendarISOWeeks: function differenceInCalendarISOWeeks() {return differenceInCalendarISOWeeks2;},
  differenceInCalendarISOWeekYearsWithOptions: function differenceInCalendarISOWeekYearsWithOptions() {return _differenceInCalendarISOWeekYearsWithOptions;},
  differenceInCalendarISOWeekYears: function differenceInCalendarISOWeekYears() {return differenceInCalendarISOWeekYears2;},
  differenceInCalendarDaysWithOptions: function differenceInCalendarDaysWithOptions() {return _differenceInCalendarDaysWithOptions;},
  differenceInCalendarDays: function differenceInCalendarDays() {return differenceInCalendarDays2;},
  differenceInBusinessDaysWithOptions: function differenceInBusinessDaysWithOptions() {return _differenceInBusinessDaysWithOptions;},
  differenceInBusinessDays: function differenceInBusinessDays() {return differenceInBusinessDays2;},
  daysToWeeks: function daysToWeeks() {return daysToWeeks2;},
  constructFrom: function constructFrom() {return constructFrom2;},
  compareDesc: function compareDesc() {return compareDesc2;},
  compareAsc: function compareAsc() {return compareAsc2;},
  closestToWithOptions: function closestToWithOptions() {return _closestToWithOptions;},
  closestTo: function closestTo() {return closestTo2;},
  closestIndexTo: function closestIndexTo() {return closestIndexTo2;},
  clampWithOptions: function clampWithOptions() {return _clampWithOptions;},
  clamp: function clamp() {return clamp2;},
  areIntervalsOverlappingWithOptions: function areIntervalsOverlappingWithOptions() {return _areIntervalsOverlappingWithOptions;},
  areIntervalsOverlapping: function areIntervalsOverlapping() {return areIntervalsOverlapping2;},
  addYearsWithOptions: function addYearsWithOptions() {return _addYearsWithOptions;},
  addYears: function addYears() {return addYears2;},
  addWithOptions: function addWithOptions() {return _addWithOptions;},
  addWeeksWithOptions: function addWeeksWithOptions() {return _addWeeksWithOptions;},
  addWeeks: function addWeeks() {return addWeeks2;},
  addSecondsWithOptions: function addSecondsWithOptions() {return _addSecondsWithOptions;},
  addSeconds: function addSeconds() {return addSeconds2;},
  addQuartersWithOptions: function addQuartersWithOptions() {return _addQuartersWithOptions;},
  addQuarters: function addQuarters() {return addQuarters2;},
  addMonthsWithOptions: function addMonthsWithOptions() {return _addMonthsWithOptions;},
  addMonths: function addMonths() {return addMonths2;},
  addMinutesWithOptions: function addMinutesWithOptions() {return _addMinutesWithOptions;},
  addMinutes: function addMinutes() {return addMinutes2;},
  addMillisecondsWithOptions: function addMillisecondsWithOptions() {return _addMillisecondsWithOptions;},
  addMilliseconds: function addMilliseconds() {return addMilliseconds2;},
  addISOWeekYearsWithOptions: function addISOWeekYearsWithOptions() {return _addISOWeekYearsWithOptions;},
  addISOWeekYears: function addISOWeekYears() {return addISOWeekYears2;},
  addHoursWithOptions: function addHoursWithOptions() {return _addHoursWithOptions;},
  addHours: function addHours() {return addHours2;},
  addDaysWithOptions: function addDaysWithOptions() {return _addDaysWithOptions;},
  addDays: function addDays() {return addDays2;},
  addBusinessDaysWithOptions: function addBusinessDaysWithOptions() {return _addBusinessDaysWithOptions;},
  addBusinessDays: function addBusinessDays() {return addBusinessDays2;},
  add: function add() {return add2;}
});

// dist/constants.js
var daysInWeek = 7;
var daysInYear = 365.2425;
var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1000;
var minTime = -maxTime;
var millisecondsInWeek = 604800000;
var millisecondsInDay = 86400000;
var millisecondsInMinute = 60000;
var millisecondsInHour = 3600000;
var millisecondsInSecond = 1000;
var minutesInYear = 525600;
var minutesInMonth = 43200;
var minutesInDay = 1440;
var minutesInHour = 60;
var monthsInQuarter = 3;
var monthsInYear = 12;
var quartersInYear = 4;
var secondsInHour = 3600;
var secondsInMinute = 60;
var secondsInDay = secondsInHour * 24;
var secondsInWeek = secondsInDay * 7;
var secondsInYear = secondsInDay * daysInYear;
var secondsInMonth = secondsInYear / 12;
var secondsInQuarter = secondsInMonth * 3;
var constructFromSymbol = Symbol.for("constructDateFrom");

// dist/constructFrom.js
function constructFrom(date, value) {
  if (typeof date === "function")
  return date(value);
  if (date && _typeof(date) === "object" && constructFromSymbol in date)
  return date[constructFromSymbol](value);
  if (date instanceof Date)
  return new date.constructor(value);
  return new Date(value);
}

// dist/toDate.js
function toDate(argument, context) {
  return constructFrom(context || argument, argument);
}

// dist/addDays.js
function addDays(date, amount, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(amount))
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
  if (!amount)
  return _date;
  _date.setDate(_date.getDate() + amount);
  return _date;
}

// dist/addMonths.js
function addMonths(date, amount, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(amount))
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
  if (!amount) {
    return _date;
  }
  var dayOfMonth = _date.getDate();
  var endOfDesiredMonth = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, _date.getTime());
  endOfDesiredMonth.setMonth(_date.getMonth() + amount + 1, 0);
  var daysInMonth = endOfDesiredMonth.getDate();
  if (dayOfMonth >= daysInMonth) {
    return endOfDesiredMonth;
  } else {
    _date.setFullYear(endOfDesiredMonth.getFullYear(), endOfDesiredMonth.getMonth(), dayOfMonth);
    return _date;
  }
}

// dist/add.js
function add(date, duration, options) {
  var _duration$years =







    duration.years,years = _duration$years === void 0 ? 0 : _duration$years,_duration$months = duration.months,months = _duration$months === void 0 ? 0 : _duration$months,_duration$weeks = duration.weeks,weeks = _duration$weeks === void 0 ? 0 : _duration$weeks,_duration$days = duration.days,days = _duration$days === void 0 ? 0 : _duration$days,_duration$hours = duration.hours,hours = _duration$hours === void 0 ? 0 : _duration$hours,_duration$minutes = duration.minutes,minutes = _duration$minutes === void 0 ? 0 : _duration$minutes,_duration$seconds = duration.seconds,seconds = _duration$seconds === void 0 ? 0 : _duration$seconds;
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var dateWithMonths = months || years ? addMonths(_date, months + years * 12) : _date;
  var dateWithDays = days || weeks ? addDays(dateWithMonths, days + weeks * 7) : dateWithMonths;
  var minutesToAdd = minutes + hours * 60;
  var secondsToAdd = seconds + minutesToAdd * 60;
  var msToAdd = secondsToAdd * 1000;
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, +dateWithDays + msToAdd);
}

// dist/fp/_lib/convertToFP.js
function convertToFP(fn, arity) {var curriedArgs = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : [];
  return curriedArgs.length >= arity ? fn.apply(void 0, _toConsumableArray(curriedArgs.slice(0, arity).reverse())) : function () {for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {args[_key] = arguments[_key];}return convertToFP(fn, arity, curriedArgs.concat(args));};
}

// dist/fp/add.js
var add2 = convertToFP(add, 2);
// dist/isSaturday.js
function isSaturday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 6;
}

// dist/isSunday.js
function isSunday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 0;
}

// dist/isWeekend.js
function isWeekend(date, options) {
  var day = toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay();
  return day === 0 || day === 6;
}

// dist/addBusinessDays.js
function addBusinessDays(date, amount, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var startedOnWeekend = isWeekend(_date, options);
  if (isNaN(amount))
  return constructFrom(options === null || options === void 0 ? void 0 : options.in, NaN);
  var hours = _date.getHours();
  var sign = amount < 0 ? -1 : 1;
  var fullWeeks = Math.trunc(amount / 5);
  _date.setDate(_date.getDate() + fullWeeks * 7);
  var restDays = Math.abs(amount % 5);
  while (restDays > 0) {
    _date.setDate(_date.getDate() + sign);
    if (!isWeekend(_date, options))
    restDays -= 1;
  }
  if (startedOnWeekend && isWeekend(_date, options) && amount !== 0) {
    if (isSaturday(_date, options))
    _date.setDate(_date.getDate() + (sign < 0 ? 2 : -1));
    if (isSunday(_date, options))
    _date.setDate(_date.getDate() + (sign < 0 ? 1 : -2));
  }
  _date.setHours(hours);
  return _date;
}

// dist/fp/addBusinessDays.js
var addBusinessDays2 = convertToFP(addBusinessDays, 2);
// dist/fp/addBusinessDaysWithOptions.js
var _addBusinessDaysWithOptions = convertToFP(addBusinessDays, 3);
// dist/fp/addDays.js
var addDays2 = convertToFP(addDays, 2);
// dist/fp/addDaysWithOptions.js
var _addDaysWithOptions = convertToFP(addDays, 3);
// dist/addMilliseconds.js
function addMilliseconds(date, amount, options) {
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, +toDate(date) + amount);
}

// dist/addHours.js
function addHours(date, amount, options) {
  return addMilliseconds(date, amount * millisecondsInHour, options);
}

// dist/fp/addHours.js
var addHours2 = convertToFP(addHours, 2);
// dist/fp/addHoursWithOptions.js
var _addHoursWithOptions = convertToFP(addHours, 3);
// dist/_lib/defaultOptions.js
var defaultOptions = {};
function getDefaultOptions() {
  return defaultOptions;
}
function setDefaultOptions(newOptions) {
  defaultOptions = newOptions;
}

// dist/startOfWeek.js
function startOfWeek(date, options) {var _ref, _ref2, _ref3, _options$weekStartsOn, _options$locale, _defaultOptions2$loca;
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = (_ref = (_ref2 = (_ref3 = (_options$weekStartsOn = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn !== void 0 ? _options$weekStartsOn : options === null || options === void 0 || (_options$locale = options.locale) === null || _options$locale === void 0 || (_options$locale = _options$locale.options) === null || _options$locale === void 0 ? void 0 : _options$locale.weekStartsOn) !== null && _ref3 !== void 0 ? _ref3 : defaultOptions2.weekStartsOn) !== null && _ref2 !== void 0 ? _ref2 : (_defaultOptions2$loca = defaultOptions2.locale) === null || _defaultOptions2$loca === void 0 || (_defaultOptions2$loca = _defaultOptions2$loca.options) === null || _defaultOptions2$loca === void 0 ? void 0 : _defaultOptions2$loca.weekStartsOn) !== null && _ref !== void 0 ? _ref : 0;
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var day = _date.getDay();
  var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
  _date.setDate(_date.getDate() - diff);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

// dist/startOfISOWeek.js
function startOfISOWeek(date, options) {
  return startOfWeek(date, _objectSpread(_objectSpread({}, options), {}, { weekStartsOn: 1 }));
}

// dist/getISOWeekYear.js
function getISOWeekYear(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var fourthOfJanuaryOfNextYear = constructFrom(_date, 0);
  fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
  var startOfNextYear = startOfISOWeek(fourthOfJanuaryOfNextYear);
  var fourthOfJanuaryOfThisYear = constructFrom(_date, 0);
  fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
  fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
  var startOfThisYear = startOfISOWeek(fourthOfJanuaryOfThisYear);
  if (_date.getTime() >= startOfNextYear.getTime()) {
    return year + 1;
  } else if (_date.getTime() >= startOfThisYear.getTime()) {
    return year;
  } else {
    return year - 1;
  }
}

// dist/_lib/getTimezoneOffsetInMilliseconds.js
function getTimezoneOffsetInMilliseconds(date) {
  var _date = toDate(date);
  var utcDate = new Date(Date.UTC(_date.getFullYear(), _date.getMonth(), _date.getDate(), _date.getHours(), _date.getMinutes(), _date.getSeconds(), _date.getMilliseconds()));
  utcDate.setUTCFullYear(_date.getFullYear());
  return +date - +utcDate;
}

// dist/_lib/normalizeDates.js
function normalizeDates(context) {for (var _len2 = arguments.length, dates = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {dates[_key2 - 1] = arguments[_key2];}
  var normalize = constructFrom.bind(null, context || dates.find(function (date) {return _typeof(date) === "object";}));
  return dates.map(normalize);
}

// dist/startOfDay.js
function startOfDay(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

// dist/differenceInCalendarDays.js
function differenceInCalendarDays(laterDate, earlierDate, options) {
  var _normalizeDates = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates2 = _slicedToArray(_normalizeDates, 2),laterDate_ = _normalizeDates2[0],earlierDate_ = _normalizeDates2[1];
  var laterStartOfDay = startOfDay(laterDate_);
  var earlierStartOfDay = startOfDay(earlierDate_);
  var laterTimestamp = +laterStartOfDay - getTimezoneOffsetInMilliseconds(laterStartOfDay);
  var earlierTimestamp = +earlierStartOfDay - getTimezoneOffsetInMilliseconds(earlierStartOfDay);
  return Math.round((laterTimestamp - earlierTimestamp) / millisecondsInDay);
}

// dist/startOfISOWeekYear.js
function startOfISOWeekYear(date, options) {
  var year = getISOWeekYear(date, options);
  var fourthOfJanuary = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  fourthOfJanuary.setFullYear(year, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  return startOfISOWeek(fourthOfJanuary);
}

// dist/setISOWeekYear.js
function setISOWeekYear(date, weekYear, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = differenceInCalendarDays(_date, startOfISOWeekYear(_date, options));
  var fourthOfJanuary = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  fourthOfJanuary.setFullYear(weekYear, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  _date = startOfISOWeekYear(fourthOfJanuary);
  _date.setDate(_date.getDate() + diff);
  return _date;
}

// dist/addISOWeekYears.js
function addISOWeekYears(date, amount, options) {
  return setISOWeekYear(date, getISOWeekYear(date, options) + amount, options);
}

// dist/fp/addISOWeekYears.js
var addISOWeekYears2 = convertToFP(addISOWeekYears, 2);
// dist/fp/addISOWeekYearsWithOptions.js
var _addISOWeekYearsWithOptions = convertToFP(addISOWeekYears, 3);
// dist/fp/addMilliseconds.js
var addMilliseconds2 = convertToFP(addMilliseconds, 2);
// dist/fp/addMillisecondsWithOptions.js
var _addMillisecondsWithOptions = convertToFP(addMilliseconds, 3);
// dist/addMinutes.js
function addMinutes(date, amount, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setTime(_date.getTime() + amount * millisecondsInMinute);
  return _date;
}

// dist/fp/addMinutes.js
var addMinutes2 = convertToFP(addMinutes, 2);
// dist/fp/addMinutesWithOptions.js
var _addMinutesWithOptions = convertToFP(addMinutes, 3);
// dist/fp/addMonths.js
var addMonths2 = convertToFP(addMonths, 2);
// dist/fp/addMonthsWithOptions.js
var _addMonthsWithOptions = convertToFP(addMonths, 3);
// dist/addQuarters.js
function addQuarters(date, amount, options) {
  return addMonths(date, amount * 3, options);
}

// dist/fp/addQuarters.js
var addQuarters2 = convertToFP(addQuarters, 2);
// dist/fp/addQuartersWithOptions.js
var _addQuartersWithOptions = convertToFP(addQuarters, 3);
// dist/addSeconds.js
function addSeconds(date, amount, options) {
  return addMilliseconds(date, amount * 1000, options);
}

// dist/fp/addSeconds.js
var addSeconds2 = convertToFP(addSeconds, 2);
// dist/fp/addSecondsWithOptions.js
var _addSecondsWithOptions = convertToFP(addSeconds, 3);
// dist/addWeeks.js
function addWeeks(date, amount, options) {
  return addDays(date, amount * 7, options);
}

// dist/fp/addWeeks.js
var addWeeks2 = convertToFP(addWeeks, 2);
// dist/fp/addWeeksWithOptions.js
var _addWeeksWithOptions = convertToFP(addWeeks, 3);
// dist/fp/addWithOptions.js
var _addWithOptions = convertToFP(add, 3);
// dist/addYears.js
function addYears(date, amount, options) {
  return addMonths(date, amount * 12, options);
}

// dist/fp/addYears.js
var addYears2 = convertToFP(addYears, 2);
// dist/fp/addYearsWithOptions.js
var _addYearsWithOptions = convertToFP(addYears, 3);
// dist/areIntervalsOverlapping.js
function areIntervalsOverlapping(intervalLeft, intervalRight, options) {
  var _sort = [
    +toDate(intervalLeft.start, options === null || options === void 0 ? void 0 : options.in),
    +toDate(intervalLeft.end, options === null || options === void 0 ? void 0 : options.in)].
    sort(function (a, b) {return a - b;}),_sort2 = _slicedToArray(_sort, 2),leftStartTime = _sort2[0],leftEndTime = _sort2[1];
  var _sort3 = [
    +toDate(intervalRight.start, options === null || options === void 0 ? void 0 : options.in),
    +toDate(intervalRight.end, options === null || options === void 0 ? void 0 : options.in)].
    sort(function (a, b) {return a - b;}),_sort4 = _slicedToArray(_sort3, 2),rightStartTime = _sort4[0],rightEndTime = _sort4[1];
  if (options !== null && options !== void 0 && options.inclusive)
  return leftStartTime <= rightEndTime && rightStartTime <= leftEndTime;
  return leftStartTime < rightEndTime && rightStartTime < leftEndTime;
}

// dist/fp/areIntervalsOverlapping.js
var areIntervalsOverlapping2 = convertToFP(areIntervalsOverlapping, 2);
// dist/fp/areIntervalsOverlappingWithOptions.js
var _areIntervalsOverlappingWithOptions = convertToFP(areIntervalsOverlapping, 3);
// dist/max.js
function max(dates, options) {
  var result;
  var context = options === null || options === void 0 ? void 0 : options.in;
  dates.forEach(function (date) {
    if (!context && _typeof(date) === "object")
    context = constructFrom.bind(null, date);
    var date_ = toDate(date, context);
    if (!result || result < date_ || isNaN(+date_))
    result = date_;
  });
  return constructFrom(context, result || NaN);
}

// dist/min.js
function min(dates, options) {
  var result;
  var context = options === null || options === void 0 ? void 0 : options.in;
  dates.forEach(function (date) {
    if (!context && _typeof(date) === "object")
    context = constructFrom.bind(null, date);
    var date_ = toDate(date, context);
    if (!result || result > date_ || isNaN(+date_))
    result = date_;
  });
  return constructFrom(context, result || NaN);
}

// dist/clamp.js
function clamp(date, interval, options) {
  var _normalizeDates3 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, date, interval.start, interval.end),_normalizeDates4 = _slicedToArray(_normalizeDates3, 3),date_ = _normalizeDates4[0],start = _normalizeDates4[1],end = _normalizeDates4[2];
  return min([max([date_, start], options), end], options);
}

// dist/fp/clamp.js
var clamp2 = convertToFP(clamp, 2);
// dist/fp/clampWithOptions.js
var _clampWithOptions = convertToFP(clamp, 3);
// dist/closestIndexTo.js
function closestIndexTo(dateToCompare, dates) {
  var timeToCompare = +toDate(dateToCompare);
  if (isNaN(timeToCompare))
  return NaN;
  var result;
  var minDistance;
  dates.forEach(function (date, index) {
    var date_ = toDate(date);
    if (isNaN(+date_)) {
      result = NaN;
      minDistance = NaN;
      return;
    }
    var distance = Math.abs(timeToCompare - +date_);
    if (result == null || distance < minDistance) {
      result = index;
      minDistance = distance;
    }
  });
  return result;
}

// dist/fp/closestIndexTo.js
var closestIndexTo2 = convertToFP(closestIndexTo, 2);
// dist/closestTo.js
function closestTo(dateToCompare, dates, options) {
  var _normalizeDates5 = normalizeDates.apply(void 0, [options === null || options === void 0 ? void 0 : options.in, dateToCompare].concat(_toConsumableArray(dates))),_normalizeDates6 = _toArray(_normalizeDates5),dateToCompare_ = _normalizeDates6[0],dates_ = _normalizeDates6.slice(1);
  var index = closestIndexTo(dateToCompare_, dates_);
  if (typeof index === "number" && isNaN(index))
  return constructFrom(dateToCompare_, NaN);
  if (index !== undefined)
  return dates_[index];
}

// dist/fp/closestTo.js
var closestTo2 = convertToFP(closestTo, 2);
// dist/fp/closestToWithOptions.js
var _closestToWithOptions = convertToFP(closestTo, 3);
// dist/compareAsc.js
function compareAsc(dateLeft, dateRight) {
  var diff = +toDate(dateLeft) - +toDate(dateRight);
  if (diff < 0)
  return -1;else
  if (diff > 0)
  return 1;
  return diff;
}

// dist/fp/compareAsc.js
var compareAsc2 = convertToFP(compareAsc, 2);
// dist/compareDesc.js
function compareDesc(dateLeft, dateRight) {
  var diff = +toDate(dateLeft) - +toDate(dateRight);
  if (diff > 0)
  return -1;else
  if (diff < 0)
  return 1;
  return diff;
}

// dist/fp/compareDesc.js
var compareDesc2 = convertToFP(compareDesc, 2);
// dist/fp/constructFrom.js
var constructFrom2 = convertToFP(constructFrom, 2);
// dist/daysToWeeks.js
function daysToWeeks(days) {
  var result = Math.trunc(days / daysInWeek);
  return result === 0 ? 0 : result;
}

// dist/fp/daysToWeeks.js
var daysToWeeks2 = convertToFP(daysToWeeks, 1);
// dist/isSameDay.js
function isSameDay(laterDate, earlierDate, options) {
  var _normalizeDates7 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates8 = _slicedToArray(_normalizeDates7, 2),dateLeft_ = _normalizeDates8[0],dateRight_ = _normalizeDates8[1];
  return +startOfDay(dateLeft_) === +startOfDay(dateRight_);
}

// dist/isDate.js
function isDate(value) {
  return value instanceof Date || _typeof(value) === "object" && Object.prototype.toString.call(value) === "[object Date]";
}

// dist/isValid.js
function isValid(date) {
  return !(!isDate(date) && typeof date !== "number" || isNaN(+toDate(date)));
}

// dist/differenceInBusinessDays.js
function differenceInBusinessDays(laterDate, earlierDate, options) {
  var _normalizeDates9 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates0 = _slicedToArray(_normalizeDates9, 2),laterDate_ = _normalizeDates0[0],earlierDate_ = _normalizeDates0[1];
  if (!isValid(laterDate_) || !isValid(earlierDate_))
  return NaN;
  var diff = differenceInCalendarDays(laterDate_, earlierDate_);
  var sign = diff < 0 ? -1 : 1;
  var weeks = Math.trunc(diff / 7);
  var result = weeks * 5;
  var movingDate = addDays(earlierDate_, weeks * 7);
  while (!isSameDay(laterDate_, movingDate)) {
    result += isWeekend(movingDate, options) ? 0 : sign;
    movingDate = addDays(movingDate, sign);
  }
  return result === 0 ? 0 : result;
}

// dist/fp/differenceInBusinessDays.js
var differenceInBusinessDays2 = convertToFP(differenceInBusinessDays, 2);
// dist/fp/differenceInBusinessDaysWithOptions.js
var _differenceInBusinessDaysWithOptions = convertToFP(differenceInBusinessDays, 3);
// dist/fp/differenceInCalendarDays.js
var differenceInCalendarDays2 = convertToFP(differenceInCalendarDays, 2);
// dist/fp/differenceInCalendarDaysWithOptions.js
var _differenceInCalendarDaysWithOptions = convertToFP(differenceInCalendarDays, 3);
// dist/differenceInCalendarISOWeekYears.js
function differenceInCalendarISOWeekYears(laterDate, earlierDate, options) {
  var _normalizeDates1 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates10 = _slicedToArray(_normalizeDates1, 2),laterDate_ = _normalizeDates10[0],earlierDate_ = _normalizeDates10[1];
  return getISOWeekYear(laterDate_, options) - getISOWeekYear(earlierDate_, options);
}

// dist/fp/differenceInCalendarISOWeekYears.js
var differenceInCalendarISOWeekYears2 = convertToFP(differenceInCalendarISOWeekYears, 2);
// dist/fp/differenceInCalendarISOWeekYearsWithOptions.js
var _differenceInCalendarISOWeekYearsWithOptions = convertToFP(differenceInCalendarISOWeekYears, 3);
// dist/differenceInCalendarISOWeeks.js
function differenceInCalendarISOWeeks(laterDate, earlierDate, options) {
  var _normalizeDates11 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates12 = _slicedToArray(_normalizeDates11, 2),laterDate_ = _normalizeDates12[0],earlierDate_ = _normalizeDates12[1];
  var startOfISOWeekLeft = startOfISOWeek(laterDate_);
  var startOfISOWeekRight = startOfISOWeek(earlierDate_);
  var timestampLeft = +startOfISOWeekLeft - getTimezoneOffsetInMilliseconds(startOfISOWeekLeft);
  var timestampRight = +startOfISOWeekRight - getTimezoneOffsetInMilliseconds(startOfISOWeekRight);
  return Math.round((timestampLeft - timestampRight) / millisecondsInWeek);
}

// dist/fp/differenceInCalendarISOWeeks.js
var differenceInCalendarISOWeeks2 = convertToFP(differenceInCalendarISOWeeks, 2);
// dist/fp/differenceInCalendarISOWeeksWithOptions.js
var _differenceInCalendarISOWeeksWithOptions = convertToFP(differenceInCalendarISOWeeks, 3);
// dist/differenceInCalendarMonths.js
function differenceInCalendarMonths(laterDate, earlierDate, options) {
  var _normalizeDates13 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates14 = _slicedToArray(_normalizeDates13, 2),laterDate_ = _normalizeDates14[0],earlierDate_ = _normalizeDates14[1];
  var yearsDiff = laterDate_.getFullYear() - earlierDate_.getFullYear();
  var monthsDiff = laterDate_.getMonth() - earlierDate_.getMonth();
  return yearsDiff * 12 + monthsDiff;
}

// dist/fp/differenceInCalendarMonths.js
var differenceInCalendarMonths2 = convertToFP(differenceInCalendarMonths, 2);
// dist/fp/differenceInCalendarMonthsWithOptions.js
var _differenceInCalendarMonthsWithOptions = convertToFP(differenceInCalendarMonths, 3);
// dist/getQuarter.js
function getQuarter(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var quarter = Math.trunc(_date.getMonth() / 3) + 1;
  return quarter;
}

// dist/differenceInCalendarQuarters.js
function differenceInCalendarQuarters(laterDate, earlierDate, options) {
  var _normalizeDates15 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates16 = _slicedToArray(_normalizeDates15, 2),laterDate_ = _normalizeDates16[0],earlierDate_ = _normalizeDates16[1];
  var yearsDiff = laterDate_.getFullYear() - earlierDate_.getFullYear();
  var quartersDiff = getQuarter(laterDate_) - getQuarter(earlierDate_);
  return yearsDiff * 4 + quartersDiff;
}

// dist/fp/differenceInCalendarQuarters.js
var differenceInCalendarQuarters2 = convertToFP(differenceInCalendarQuarters, 2);
// dist/fp/differenceInCalendarQuartersWithOptions.js
var _differenceInCalendarQuartersWithOptions = convertToFP(differenceInCalendarQuarters, 3);
// dist/differenceInCalendarWeeks.js
function differenceInCalendarWeeks(laterDate, earlierDate, options) {
  var _normalizeDates17 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates18 = _slicedToArray(_normalizeDates17, 2),laterDate_ = _normalizeDates18[0],earlierDate_ = _normalizeDates18[1];
  var laterStartOfWeek = startOfWeek(laterDate_, options);
  var earlierStartOfWeek = startOfWeek(earlierDate_, options);
  var laterTimestamp = +laterStartOfWeek - getTimezoneOffsetInMilliseconds(laterStartOfWeek);
  var earlierTimestamp = +earlierStartOfWeek - getTimezoneOffsetInMilliseconds(earlierStartOfWeek);
  return Math.round((laterTimestamp - earlierTimestamp) / millisecondsInWeek);
}

// dist/fp/differenceInCalendarWeeks.js
var differenceInCalendarWeeks2 = convertToFP(differenceInCalendarWeeks, 2);
// dist/fp/differenceInCalendarWeeksWithOptions.js
var _differenceInCalendarWeeksWithOptions = convertToFP(differenceInCalendarWeeks, 3);
// dist/differenceInCalendarYears.js
function differenceInCalendarYears(laterDate, earlierDate, options) {
  var _normalizeDates19 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates20 = _slicedToArray(_normalizeDates19, 2),laterDate_ = _normalizeDates20[0],earlierDate_ = _normalizeDates20[1];
  return laterDate_.getFullYear() - earlierDate_.getFullYear();
}

// dist/fp/differenceInCalendarYears.js
var differenceInCalendarYears2 = convertToFP(differenceInCalendarYears, 2);
// dist/fp/differenceInCalendarYearsWithOptions.js
var _differenceInCalendarYearsWithOptions = convertToFP(differenceInCalendarYears, 3);
// dist/differenceInDays.js
function differenceInDays(laterDate, earlierDate, options) {
  var _normalizeDates21 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates22 = _slicedToArray(_normalizeDates21, 2),laterDate_ = _normalizeDates22[0],earlierDate_ = _normalizeDates22[1];
  var sign = compareLocalAsc(laterDate_, earlierDate_);
  var difference = Math.abs(differenceInCalendarDays(laterDate_, earlierDate_));
  laterDate_.setDate(laterDate_.getDate() - sign * difference);
  var isLastDayNotFull = Number(compareLocalAsc(laterDate_, earlierDate_) === -sign);
  var result = sign * (difference - isLastDayNotFull);
  return result === 0 ? 0 : result;
}
function compareLocalAsc(laterDate, earlierDate) {
  var diff = laterDate.getFullYear() - earlierDate.getFullYear() || laterDate.getMonth() - earlierDate.getMonth() || laterDate.getDate() - earlierDate.getDate() || laterDate.getHours() - earlierDate.getHours() || laterDate.getMinutes() - earlierDate.getMinutes() || laterDate.getSeconds() - earlierDate.getSeconds() || laterDate.getMilliseconds() - earlierDate.getMilliseconds();
  if (diff < 0)
  return -1;
  if (diff > 0)
  return 1;
  return diff;
}

// dist/fp/differenceInDays.js
var differenceInDays2 = convertToFP(differenceInDays, 2);
// dist/fp/differenceInDaysWithOptions.js
var _differenceInDaysWithOptions = convertToFP(differenceInDays, 3);
// dist/_lib/getRoundingMethod.js
function getRoundingMethod(method) {
  return function (number) {
    var round = method ? Math[method] : Math.trunc;
    var result = round(number);
    return result === 0 ? 0 : result;
  };
}

// dist/differenceInHours.js
function differenceInHours(laterDate, earlierDate, options) {
  var _normalizeDates23 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates24 = _slicedToArray(_normalizeDates23, 2),laterDate_ = _normalizeDates24[0],earlierDate_ = _normalizeDates24[1];
  var diff = (+laterDate_ - +earlierDate_) / millisecondsInHour;
  return getRoundingMethod(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

// dist/fp/differenceInHours.js
var differenceInHours2 = convertToFP(differenceInHours, 2);
// dist/fp/differenceInHoursWithOptions.js
var _differenceInHoursWithOptions = convertToFP(differenceInHours, 3);
// dist/subISOWeekYears.js
function subISOWeekYears(date, amount, options) {
  return addISOWeekYears(date, -amount, options);
}

// dist/differenceInISOWeekYears.js
function differenceInISOWeekYears(laterDate, earlierDate, options) {
  var _normalizeDates25 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates26 = _slicedToArray(_normalizeDates25, 2),laterDate_ = _normalizeDates26[0],earlierDate_ = _normalizeDates26[1];
  var sign = compareAsc(laterDate_, earlierDate_);
  var diff = Math.abs(differenceInCalendarISOWeekYears(laterDate_, earlierDate_, options));
  var adjustedDate = subISOWeekYears(laterDate_, sign * diff, options);
  var isLastISOWeekYearNotFull = Number(compareAsc(adjustedDate, earlierDate_) === -sign);
  var result = sign * (diff - isLastISOWeekYearNotFull);
  return result === 0 ? 0 : result;
}

// dist/fp/differenceInISOWeekYears.js
var differenceInISOWeekYears2 = convertToFP(differenceInISOWeekYears, 2);
// dist/fp/differenceInISOWeekYearsWithOptions.js
var _differenceInISOWeekYearsWithOptions = convertToFP(differenceInISOWeekYears, 3);
// dist/differenceInMilliseconds.js
function differenceInMilliseconds(laterDate, earlierDate) {
  return +toDate(laterDate) - +toDate(earlierDate);
}

// dist/fp/differenceInMilliseconds.js
var differenceInMilliseconds2 = convertToFP(differenceInMilliseconds, 2);
// dist/differenceInMinutes.js
function differenceInMinutes(dateLeft, dateRight, options) {
  var diff = differenceInMilliseconds(dateLeft, dateRight) / millisecondsInMinute;
  return getRoundingMethod(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

// dist/fp/differenceInMinutes.js
var differenceInMinutes2 = convertToFP(differenceInMinutes, 2);
// dist/fp/differenceInMinutesWithOptions.js
var _differenceInMinutesWithOptions = convertToFP(differenceInMinutes, 3);
// dist/endOfDay.js
function endOfDay(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/endOfMonth.js
function endOfMonth(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var month = _date.getMonth();
  _date.setFullYear(_date.getFullYear(), month + 1, 0);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/isLastDayOfMonth.js
function isLastDayOfMonth(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  return +endOfDay(_date, options) === +endOfMonth(_date, options);
}

// dist/differenceInMonths.js
function differenceInMonths(laterDate, earlierDate, options) {
  var _normalizeDates27 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, laterDate, earlierDate),_normalizeDates28 = _slicedToArray(_normalizeDates27, 3),laterDate_ = _normalizeDates28[0],workingLaterDate = _normalizeDates28[1],earlierDate_ = _normalizeDates28[2];
  var sign = compareAsc(workingLaterDate, earlierDate_);
  var difference = Math.abs(differenceInCalendarMonths(workingLaterDate, earlierDate_));
  if (difference < 1)
  return 0;
  if (workingLaterDate.getMonth() === 1 && workingLaterDate.getDate() > 27)
  workingLaterDate.setDate(30);
  workingLaterDate.setMonth(workingLaterDate.getMonth() - sign * difference);
  var isLastMonthNotFull = compareAsc(workingLaterDate, earlierDate_) === -sign;
  if (isLastDayOfMonth(laterDate_) && difference === 1 && compareAsc(laterDate_, earlierDate_) === 1) {
    isLastMonthNotFull = false;
  }
  var result = sign * (difference - +isLastMonthNotFull);
  return result === 0 ? 0 : result;
}

// dist/fp/differenceInMonths.js
var differenceInMonths2 = convertToFP(differenceInMonths, 2);
// dist/fp/differenceInMonthsWithOptions.js
var _differenceInMonthsWithOptions = convertToFP(differenceInMonths, 3);
// dist/differenceInQuarters.js
function differenceInQuarters(laterDate, earlierDate, options) {
  var diff = differenceInMonths(laterDate, earlierDate, options) / 3;
  return getRoundingMethod(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

// dist/fp/differenceInQuarters.js
var differenceInQuarters2 = convertToFP(differenceInQuarters, 2);
// dist/fp/differenceInQuartersWithOptions.js
var _differenceInQuartersWithOptions = convertToFP(differenceInQuarters, 3);
// dist/differenceInSeconds.js
function differenceInSeconds(laterDate, earlierDate, options) {
  var diff = differenceInMilliseconds(laterDate, earlierDate) / 1000;
  return getRoundingMethod(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

// dist/fp/differenceInSeconds.js
var differenceInSeconds2 = convertToFP(differenceInSeconds, 2);
// dist/fp/differenceInSecondsWithOptions.js
var _differenceInSecondsWithOptions = convertToFP(differenceInSeconds, 3);
// dist/differenceInWeeks.js
function differenceInWeeks(laterDate, earlierDate, options) {
  var diff = differenceInDays(laterDate, earlierDate, options) / 7;
  return getRoundingMethod(options === null || options === void 0 ? void 0 : options.roundingMethod)(diff);
}

// dist/fp/differenceInWeeks.js
var differenceInWeeks2 = convertToFP(differenceInWeeks, 2);
// dist/fp/differenceInWeeksWithOptions.js
var _differenceInWeeksWithOptions = convertToFP(differenceInWeeks, 3);
// dist/differenceInYears.js
function differenceInYears(laterDate, earlierDate, options) {
  var _normalizeDates29 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates30 = _slicedToArray(_normalizeDates29, 2),laterDate_ = _normalizeDates30[0],earlierDate_ = _normalizeDates30[1];
  var sign = compareAsc(laterDate_, earlierDate_);
  var diff = Math.abs(differenceInCalendarYears(laterDate_, earlierDate_));
  laterDate_.setFullYear(1584);
  earlierDate_.setFullYear(1584);
  var partial = compareAsc(laterDate_, earlierDate_) === -sign;
  var result = sign * (diff - +partial);
  return result === 0 ? 0 : result;
}

// dist/fp/differenceInYears.js
var differenceInYears2 = convertToFP(differenceInYears, 2);
// dist/fp/differenceInYearsWithOptions.js
var _differenceInYearsWithOptions = convertToFP(differenceInYears, 3);
// dist/_lib/normalizeInterval.js
function normalizeInterval(context, interval) {
  var _normalizeDates31 = normalizeDates(context, interval.start, interval.end),_normalizeDates32 = _slicedToArray(_normalizeDates31, 2),start = _normalizeDates32[0],end = _normalizeDates32[1];
  return { start: start, end: end };
}

// dist/eachDayOfInterval.js
function eachDayOfInterval(interval, options) {var _options$step;
  var _normalizeInterval = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval.start,end = _normalizeInterval.end;
  var reversed = +start > +end;
  var endTime = reversed ? +start : +end;
  var date = reversed ? end : start;
  date.setHours(0, 0, 0, 0);
  var step = (_options$step = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step !== void 0 ? _options$step : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date.setDate(date.getDate() + step);
    date.setHours(0, 0, 0, 0);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachDayOfInterval.js
var eachDayOfInterval2 = convertToFP(eachDayOfInterval, 1);
// dist/fp/eachDayOfIntervalWithOptions.js
var _eachDayOfIntervalWithOptions = convertToFP(eachDayOfInterval, 2);
// dist/eachHourOfInterval.js
function eachHourOfInterval(interval, options) {var _options$step2;
  var _normalizeInterval2 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval2.start,end = _normalizeInterval2.end;
  var reversed = +start > +end;
  var endTime = reversed ? +start : +end;
  var date = reversed ? end : start;
  date.setMinutes(0, 0, 0);
  var step = (_options$step2 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step2 !== void 0 ? _options$step2 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date.setHours(date.getHours() + step);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachHourOfInterval.js
var eachHourOfInterval2 = convertToFP(eachHourOfInterval, 1);
// dist/fp/eachHourOfIntervalWithOptions.js
var _eachHourOfIntervalWithOptions = convertToFP(eachHourOfInterval, 2);
// dist/eachMinuteOfInterval.js
function eachMinuteOfInterval(interval, options) {var _options$step3;
  var _normalizeInterval3 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval3.start,end = _normalizeInterval3.end;
  start.setSeconds(0, 0);
  var reversed = +start > +end;
  var endTime = reversed ? +start : +end;
  var date = reversed ? end : start;
  var step = (_options$step3 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step3 !== void 0 ? _options$step3 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date = addMinutes(date, step);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachMinuteOfInterval.js
var eachMinuteOfInterval2 = convertToFP(eachMinuteOfInterval, 1);
// dist/fp/eachMinuteOfIntervalWithOptions.js
var _eachMinuteOfIntervalWithOptions = convertToFP(eachMinuteOfInterval, 2);
// dist/eachMonthOfInterval.js
function eachMonthOfInterval(interval, options) {var _options$step4;
  var _normalizeInterval4 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval4.start,end = _normalizeInterval4.end;
  var reversed = +start > +end;
  var endTime = reversed ? +start : +end;
  var date = reversed ? end : start;
  date.setHours(0, 0, 0, 0);
  date.setDate(1);
  var step = (_options$step4 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step4 !== void 0 ? _options$step4 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date.setMonth(date.getMonth() + step);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachMonthOfInterval.js
var eachMonthOfInterval2 = convertToFP(eachMonthOfInterval, 1);
// dist/fp/eachMonthOfIntervalWithOptions.js
var _eachMonthOfIntervalWithOptions = convertToFP(eachMonthOfInterval, 2);
// dist/startOfQuarter.js
function startOfQuarter(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var currentMonth = _date.getMonth();
  var month = currentMonth - currentMonth % 3;
  _date.setMonth(month, 1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

// dist/eachQuarterOfInterval.js
function eachQuarterOfInterval(interval, options) {var _options$step5;
  var _normalizeInterval5 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval5.start,end = _normalizeInterval5.end;
  var reversed = +start > +end;
  var endTime = reversed ? +startOfQuarter(start) : +startOfQuarter(end);
  var date = reversed ? startOfQuarter(end) : startOfQuarter(start);
  var step = (_options$step5 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step5 !== void 0 ? _options$step5 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date = addQuarters(date, step);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachQuarterOfInterval.js
var eachQuarterOfInterval2 = convertToFP(eachQuarterOfInterval, 1);
// dist/fp/eachQuarterOfIntervalWithOptions.js
var _eachQuarterOfIntervalWithOptions = convertToFP(eachQuarterOfInterval, 2);
// dist/eachWeekOfInterval.js
function eachWeekOfInterval(interval, options) {var _options$step6;
  var _normalizeInterval6 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval6.start,end = _normalizeInterval6.end;
  var reversed = +start > +end;
  var startDateWeek = reversed ? startOfWeek(end, options) : startOfWeek(start, options);
  var endDateWeek = reversed ? startOfWeek(start, options) : startOfWeek(end, options);
  startDateWeek.setHours(15);
  endDateWeek.setHours(15);
  var endTime = +endDateWeek.getTime();
  var currentDate = startDateWeek;
  var step = (_options$step6 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step6 !== void 0 ? _options$step6 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+currentDate <= endTime) {
    currentDate.setHours(0);
    dates.push(constructFrom(start, currentDate));
    currentDate = addWeeks(currentDate, step);
    currentDate.setHours(15);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachWeekOfInterval.js
var eachWeekOfInterval2 = convertToFP(eachWeekOfInterval, 1);
// dist/fp/eachWeekOfIntervalWithOptions.js
var _eachWeekOfIntervalWithOptions = convertToFP(eachWeekOfInterval, 2);
// dist/eachWeekendOfInterval.js
function eachWeekendOfInterval(interval, options) {
  var _normalizeInterval7 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval7.start,end = _normalizeInterval7.end;
  var dateInterval = eachDayOfInterval({ start: start, end: end }, options);
  var weekends = [];
  var index = 0;
  while (index < dateInterval.length) {
    var date = dateInterval[index++];
    if (isWeekend(date))
    weekends.push(constructFrom(start, date));
  }
  return weekends;
}

// dist/fp/eachWeekendOfInterval.js
var eachWeekendOfInterval2 = convertToFP(eachWeekendOfInterval, 1);
// dist/fp/eachWeekendOfIntervalWithOptions.js
var _eachWeekendOfIntervalWithOptions = convertToFP(eachWeekendOfInterval, 2);
// dist/startOfMonth.js
function startOfMonth(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setDate(1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

// dist/eachWeekendOfMonth.js
function eachWeekendOfMonth(date, options) {
  var start = startOfMonth(date, options);
  var end = endOfMonth(date, options);
  return eachWeekendOfInterval({ start: start, end: end }, options);
}

// dist/fp/eachWeekendOfMonth.js
var eachWeekendOfMonth2 = convertToFP(eachWeekendOfMonth, 1);
// dist/fp/eachWeekendOfMonthWithOptions.js
var _eachWeekendOfMonthWithOptions = convertToFP(eachWeekendOfMonth, 2);
// dist/endOfYear.js
function endOfYear(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  _date.setFullYear(year + 1, 0, 0);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/startOfYear.js
function startOfYear(date, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  date_.setFullYear(date_.getFullYear(), 0, 1);
  date_.setHours(0, 0, 0, 0);
  return date_;
}

// dist/eachWeekendOfYear.js
function eachWeekendOfYear(date, options) {
  var start = startOfYear(date, options);
  var end = endOfYear(date, options);
  return eachWeekendOfInterval({ start: start, end: end }, options);
}

// dist/fp/eachWeekendOfYear.js
var eachWeekendOfYear2 = convertToFP(eachWeekendOfYear, 1);
// dist/fp/eachWeekendOfYearWithOptions.js
var _eachWeekendOfYearWithOptions = convertToFP(eachWeekendOfYear, 2);
// dist/eachYearOfInterval.js
function eachYearOfInterval(interval, options) {var _options$step7;
  var _normalizeInterval8 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval),start = _normalizeInterval8.start,end = _normalizeInterval8.end;
  var reversed = +start > +end;
  var endTime = reversed ? +start : +end;
  var date = reversed ? end : start;
  date.setHours(0, 0, 0, 0);
  date.setMonth(0, 1);
  var step = (_options$step7 = options === null || options === void 0 ? void 0 : options.step) !== null && _options$step7 !== void 0 ? _options$step7 : 1;
  if (!step)
  return [];
  if (step < 0) {
    step = -step;
    reversed = !reversed;
  }
  var dates = [];
  while (+date <= endTime) {
    dates.push(constructFrom(start, date));
    date.setFullYear(date.getFullYear() + step);
  }
  return reversed ? dates.reverse() : dates;
}

// dist/fp/eachYearOfInterval.js
var eachYearOfInterval2 = convertToFP(eachYearOfInterval, 1);
// dist/fp/eachYearOfIntervalWithOptions.js
var _eachYearOfIntervalWithOptions = convertToFP(eachYearOfInterval, 2);
// dist/fp/endOfDay.js
var endOfDay2 = convertToFP(endOfDay, 1);
// dist/fp/endOfDayWithOptions.js
var _endOfDayWithOptions = convertToFP(endOfDay, 2);
// dist/endOfDecade.js
function endOfDecade(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var decade = 9 + Math.floor(year / 10) * 10;
  _date.setFullYear(decade, 11, 31);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/fp/endOfDecade.js
var endOfDecade2 = convertToFP(endOfDecade, 1);
// dist/fp/endOfDecadeWithOptions.js
var _endOfDecadeWithOptions = convertToFP(endOfDecade, 2);
// dist/endOfHour.js
function endOfHour(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setMinutes(59, 59, 999);
  return _date;
}

// dist/fp/endOfHour.js
var endOfHour2 = convertToFP(endOfHour, 1);
// dist/fp/endOfHourWithOptions.js
var _endOfHourWithOptions = convertToFP(endOfHour, 2);
// dist/endOfWeek.js
function endOfWeek(date, options) {var _ref4, _ref5, _ref6, _options$weekStartsOn2, _options$locale2, _defaultOptions2$loca2;
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = (_ref4 = (_ref5 = (_ref6 = (_options$weekStartsOn2 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn2 !== void 0 ? _options$weekStartsOn2 : options === null || options === void 0 || (_options$locale2 = options.locale) === null || _options$locale2 === void 0 || (_options$locale2 = _options$locale2.options) === null || _options$locale2 === void 0 ? void 0 : _options$locale2.weekStartsOn) !== null && _ref6 !== void 0 ? _ref6 : defaultOptions2.weekStartsOn) !== null && _ref5 !== void 0 ? _ref5 : (_defaultOptions2$loca2 = defaultOptions2.locale) === null || _defaultOptions2$loca2 === void 0 || (_defaultOptions2$loca2 = _defaultOptions2$loca2.options) === null || _defaultOptions2$loca2 === void 0 ? void 0 : _defaultOptions2$loca2.weekStartsOn) !== null && _ref4 !== void 0 ? _ref4 : 0;
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var day = _date.getDay();
  var diff = (day < weekStartsOn ? -7 : 0) + 6 - (day - weekStartsOn);
  _date.setDate(_date.getDate() + diff);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/endOfISOWeek.js
function endOfISOWeek(date, options) {
  return endOfWeek(date, _objectSpread(_objectSpread({}, options), {}, { weekStartsOn: 1 }));
}

// dist/fp/endOfISOWeek.js
var endOfISOWeek2 = convertToFP(endOfISOWeek, 1);
// dist/fp/endOfISOWeekWithOptions.js
var _endOfISOWeekWithOptions = convertToFP(endOfISOWeek, 2);
// dist/endOfISOWeekYear.js
function endOfISOWeekYear(date, options) {
  var year = getISOWeekYear(date, options);
  var fourthOfJanuaryOfNextYear = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
  fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
  var _date = startOfISOWeek(fourthOfJanuaryOfNextYear, options);
  _date.setMilliseconds(_date.getMilliseconds() - 1);
  return _date;
}

// dist/fp/endOfISOWeekYear.js
var endOfISOWeekYear2 = convertToFP(endOfISOWeekYear, 1);
// dist/fp/endOfISOWeekYearWithOptions.js
var _endOfISOWeekYearWithOptions = convertToFP(endOfISOWeekYear, 2);
// dist/endOfMinute.js
function endOfMinute(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setSeconds(59, 999);
  return _date;
}

// dist/fp/endOfMinute.js
var endOfMinute2 = convertToFP(endOfMinute, 1);
// dist/fp/endOfMinuteWithOptions.js
var _endOfMinuteWithOptions = convertToFP(endOfMinute, 2);
// dist/fp/endOfMonth.js
var endOfMonth2 = convertToFP(endOfMonth, 1);
// dist/fp/endOfMonthWithOptions.js
var _endOfMonthWithOptions = convertToFP(endOfMonth, 2);
// dist/endOfQuarter.js
function endOfQuarter(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var currentMonth = _date.getMonth();
  var month = currentMonth - currentMonth % 3 + 3;
  _date.setMonth(month, 0);
  _date.setHours(23, 59, 59, 999);
  return _date;
}

// dist/fp/endOfQuarter.js
var endOfQuarter2 = convertToFP(endOfQuarter, 1);
// dist/fp/endOfQuarterWithOptions.js
var _endOfQuarterWithOptions = convertToFP(endOfQuarter, 2);
// dist/endOfSecond.js
function endOfSecond(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setMilliseconds(999);
  return _date;
}

// dist/fp/endOfSecond.js
var endOfSecond2 = convertToFP(endOfSecond, 1);
// dist/fp/endOfSecondWithOptions.js
var _endOfSecondWithOptions = convertToFP(endOfSecond, 2);
// dist/fp/endOfWeek.js
var endOfWeek2 = convertToFP(endOfWeek, 1);
// dist/fp/endOfWeekWithOptions.js
var _endOfWeekWithOptions = convertToFP(endOfWeek, 2);
// dist/fp/endOfYear.js
var endOfYear2 = convertToFP(endOfYear, 1);
// dist/fp/endOfYearWithOptions.js
var _endOfYearWithOptions = convertToFP(endOfYear, 2);
// dist/locale/en-US/_lib/formatDistance.js
var formatDistanceLocale = {
  lessThanXSeconds: {
    one: "less than a second",
    other: "less than {{count}} seconds"
  },
  xSeconds: {
    one: "1 second",
    other: "{{count}} seconds"
  },
  halfAMinute: "half a minute",
  lessThanXMinutes: {
    one: "less than a minute",
    other: "less than {{count}} minutes"
  },
  xMinutes: {
    one: "1 minute",
    other: "{{count}} minutes"
  },
  aboutXHours: {
    one: "about 1 hour",
    other: "about {{count}} hours"
  },
  xHours: {
    one: "1 hour",
    other: "{{count}} hours"
  },
  xDays: {
    one: "1 day",
    other: "{{count}} days"
  },
  aboutXWeeks: {
    one: "about 1 week",
    other: "about {{count}} weeks"
  },
  xWeeks: {
    one: "1 week",
    other: "{{count}} weeks"
  },
  aboutXMonths: {
    one: "about 1 month",
    other: "about {{count}} months"
  },
  xMonths: {
    one: "1 month",
    other: "{{count}} months"
  },
  aboutXYears: {
    one: "about 1 year",
    other: "about {{count}} years"
  },
  xYears: {
    one: "1 year",
    other: "{{count}} years"
  },
  overXYears: {
    one: "over 1 year",
    other: "over {{count}} years"
  },
  almostXYears: {
    one: "almost 1 year",
    other: "almost {{count}} years"
  }
};
var formatDistance = function formatDistance(token, count, options) {
  var result;
  var tokenValue = formatDistanceLocale[token];
  if (typeof tokenValue === "string") {
    result = tokenValue;
  } else if (count === 1) {
    result = tokenValue.one;
  } else {
    result = tokenValue.other.replace("{{count}}", count.toString());
  }
  if (options !== null && options !== void 0 && options.addSuffix) {
    if (options.comparison && options.comparison > 0) {
      return "in " + result;
    } else {
      return result + " ago";
    }
  }
  return result;
};

// dist/locale/_lib/buildFormatLongFn.js
function buildFormatLongFn(args) {
  return function () {var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var width = options.width ? String(options.width) : args.defaultWidth;
    var format = args.formats[width] || args.formats[args.defaultWidth];
    return format;
  };
}

// dist/locale/en-US/_lib/formatLong.js
var dateFormats = {
  full: "EEEE, MMMM do, y",
  long: "MMMM do, y",
  medium: "MMM d, y",
  short: "MM/dd/yyyy"
};
var timeFormats = {
  full: "h:mm:ss a zzzz",
  long: "h:mm:ss a z",
  medium: "h:mm:ss a",
  short: "h:mm a"
};
var dateTimeFormats = {
  full: "{{date}} 'at' {{time}}",
  long: "{{date}} 'at' {{time}}",
  medium: "{{date}}, {{time}}",
  short: "{{date}}, {{time}}"
};
var formatLong = {
  date: buildFormatLongFn({
    formats: dateFormats,
    defaultWidth: "full"
  }),
  time: buildFormatLongFn({
    formats: timeFormats,
    defaultWidth: "full"
  }),
  dateTime: buildFormatLongFn({
    formats: dateTimeFormats,
    defaultWidth: "full"
  })
};

// dist/locale/en-US/_lib/formatRelative.js
var formatRelativeLocale = {
  lastWeek: "'last' eeee 'at' p",
  yesterday: "'yesterday at' p",
  today: "'today at' p",
  tomorrow: "'tomorrow at' p",
  nextWeek: "eeee 'at' p",
  other: "P"
};
var formatRelative = function formatRelative(token, _date, _baseDate, _options) {return formatRelativeLocale[token];};

// dist/locale/_lib/buildLocalizeFn.js
function buildLocalizeFn(args) {
  return function (value, options) {
    var context = options !== null && options !== void 0 && options.context ? String(options.context) : "standalone";
    var valuesArray;
    if (context === "formatting" && args.formattingValues) {
      var defaultWidth = args.defaultFormattingWidth || args.defaultWidth;
      var width = options !== null && options !== void 0 && options.width ? String(options.width) : defaultWidth;
      valuesArray = args.formattingValues[width] || args.formattingValues[defaultWidth];
    } else {
      var _defaultWidth = args.defaultWidth;
      var _width = options !== null && options !== void 0 && options.width ? String(options.width) : args.defaultWidth;
      valuesArray = args.values[_width] || args.values[_defaultWidth];
    }
    var index = args.argumentCallback ? args.argumentCallback(value) : value;
    return valuesArray[index];
  };
}

// dist/locale/en-US/_lib/localize.js
var eraValues = {
  narrow: ["B", "A"],
  abbreviated: ["BC", "AD"],
  wide: ["Before Christ", "Anno Domini"]
};
var quarterValues = {
  narrow: ["1", "2", "3", "4"],
  abbreviated: ["Q1", "Q2", "Q3", "Q4"],
  wide: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"]
};
var monthValues = {
  narrow: ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"],
  abbreviated: [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"],

  wide: [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"]

};
var dayValues = {
  narrow: ["S", "M", "T", "W", "T", "F", "S"],
  short: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
  abbreviated: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  wide: [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"]

};
var dayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "morning",
    afternoon: "afternoon",
    evening: "evening",
    night: "night"
  }
};
var formattingDayPeriodValues = {
  narrow: {
    am: "a",
    pm: "p",
    midnight: "mi",
    noon: "n",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  abbreviated: {
    am: "AM",
    pm: "PM",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  },
  wide: {
    am: "a.m.",
    pm: "p.m.",
    midnight: "midnight",
    noon: "noon",
    morning: "in the morning",
    afternoon: "in the afternoon",
    evening: "in the evening",
    night: "at night"
  }
};
var ordinalNumber = function ordinalNumber(dirtyNumber, _options) {
  var number = Number(dirtyNumber);
  var rem100 = number % 100;
  if (rem100 > 20 || rem100 < 10) {
    switch (rem100 % 10) {
      case 1:
        return number + "st";
      case 2:
        return number + "nd";
      case 3:
        return number + "rd";
    }
  }
  return number + "th";
};
var localize = {
  ordinalNumber: ordinalNumber,
  era: buildLocalizeFn({
    values: eraValues,
    defaultWidth: "wide"
  }),
  quarter: buildLocalizeFn({
    values: quarterValues,
    defaultWidth: "wide",
    argumentCallback: function argumentCallback(quarter) {return quarter - 1;}
  }),
  month: buildLocalizeFn({
    values: monthValues,
    defaultWidth: "wide"
  }),
  day: buildLocalizeFn({
    values: dayValues,
    defaultWidth: "wide"
  }),
  dayPeriod: buildLocalizeFn({
    values: dayPeriodValues,
    defaultWidth: "wide",
    formattingValues: formattingDayPeriodValues,
    defaultFormattingWidth: "wide"
  })
};

// dist/locale/_lib/buildMatchFn.js
function buildMatchFn(args) {
  return function (string) {var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var width = options.width;
    var matchPattern = width && args.matchPatterns[width] || args.matchPatterns[args.defaultMatchWidth];
    var matchResult = string.match(matchPattern);
    if (!matchResult) {
      return null;
    }
    var matchedString = matchResult[0];
    var parsePatterns = width && args.parsePatterns[width] || args.parsePatterns[args.defaultParseWidth];
    var key = Array.isArray(parsePatterns) ? findIndex(parsePatterns, function (pattern) {return pattern.test(matchedString);}) : findKey(parsePatterns, function (pattern) {return pattern.test(matchedString);});
    var value;
    value = args.valueCallback ? args.valueCallback(key) : key;
    value = options.valueCallback ? options.valueCallback(value) : value;
    var rest = string.slice(matchedString.length);
    return { value: value, rest: rest };
  };
}
function findKey(object, predicate) {
  for (var key in object) {
    if (Object.prototype.hasOwnProperty.call(object, key) && predicate(object[key])) {
      return key;
    }
  }
  return;
}
function findIndex(array, predicate) {
  for (var key = 0; key < array.length; key++) {
    if (predicate(array[key])) {
      return key;
    }
  }
  return;
}

// dist/locale/_lib/buildMatchPatternFn.js
function buildMatchPatternFn(args) {
  return function (string) {var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var matchResult = string.match(args.matchPattern);
    if (!matchResult)
    return null;
    var matchedString = matchResult[0];
    var parseResult = string.match(args.parsePattern);
    if (!parseResult)
    return null;
    var value = args.valueCallback ? args.valueCallback(parseResult[0]) : parseResult[0];
    value = options.valueCallback ? options.valueCallback(value) : value;
    var rest = string.slice(matchedString.length);
    return { value: value, rest: rest };
  };
}

// dist/locale/en-US/_lib/match.js
var matchOrdinalNumberPattern = /^(\d+)(th|st|nd|rd)?/i;
var parseOrdinalNumberPattern = /\d+/i;
var matchEraPatterns = {
  narrow: /^(b|a)/i,
  abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
  wide: /^(before christ|before common era|anno domini|common era)/i
};
var parseEraPatterns = {
  any: [/^b/i, /^(a|c)/i]
};
var matchQuarterPatterns = {
  narrow: /^[1234]/i,
  abbreviated: /^q[1234]/i,
  wide: /^[1234](th|st|nd|rd)? quarter/i
};
var parseQuarterPatterns = {
  any: [/1/i, /2/i, /3/i, /4/i]
};
var matchMonthPatterns = {
  narrow: /^[jfmasond]/i,
  abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
  wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
};
var parseMonthPatterns = {
  narrow: [
  /^j/i,
  /^f/i,
  /^m/i,
  /^a/i,
  /^m/i,
  /^j/i,
  /^j/i,
  /^a/i,
  /^s/i,
  /^o/i,
  /^n/i,
  /^d/i],

  any: [
  /^ja/i,
  /^f/i,
  /^mar/i,
  /^ap/i,
  /^may/i,
  /^jun/i,
  /^jul/i,
  /^au/i,
  /^s/i,
  /^o/i,
  /^n/i,
  /^d/i]

};
var matchDayPatterns = {
  narrow: /^[smtwf]/i,
  short: /^(su|mo|tu|we|th|fr|sa)/i,
  abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
  wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
};
var parseDayPatterns = {
  narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
  any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
};
var matchDayPeriodPatterns = {
  narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
  any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
};
var parseDayPeriodPatterns = {
  any: {
    am: /^a/i,
    pm: /^p/i,
    midnight: /^mi/i,
    noon: /^no/i,
    morning: /morning/i,
    afternoon: /afternoon/i,
    evening: /evening/i,
    night: /night/i
  }
};
var match = {
  ordinalNumber: buildMatchPatternFn({
    matchPattern: matchOrdinalNumberPattern,
    parsePattern: parseOrdinalNumberPattern,
    valueCallback: function valueCallback(value) {return parseInt(value, 10);}
  }),
  era: buildMatchFn({
    matchPatterns: matchEraPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseEraPatterns,
    defaultParseWidth: "any"
  }),
  quarter: buildMatchFn({
    matchPatterns: matchQuarterPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseQuarterPatterns,
    defaultParseWidth: "any",
    valueCallback: function valueCallback(index) {return index + 1;}
  }),
  month: buildMatchFn({
    matchPatterns: matchMonthPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseMonthPatterns,
    defaultParseWidth: "any"
  }),
  day: buildMatchFn({
    matchPatterns: matchDayPatterns,
    defaultMatchWidth: "wide",
    parsePatterns: parseDayPatterns,
    defaultParseWidth: "any"
  }),
  dayPeriod: buildMatchFn({
    matchPatterns: matchDayPeriodPatterns,
    defaultMatchWidth: "any",
    parsePatterns: parseDayPeriodPatterns,
    defaultParseWidth: "any"
  })
};

// dist/locale/en-US.js
var enUS = {
  code: "en-US",
  formatDistance: formatDistance,
  formatLong: formatLong,
  formatRelative: formatRelative,
  localize: localize,
  match: match,
  options: {
    weekStartsOn: 0,
    firstWeekContainsDate: 1
  }
};
// dist/getDayOfYear.js
function getDayOfYear(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = differenceInCalendarDays(_date, startOfYear(_date));
  var dayOfYear = diff + 1;
  return dayOfYear;
}

// dist/getISOWeek.js
function getISOWeek(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = +startOfISOWeek(_date) - +startOfISOWeekYear(_date);
  return Math.round(diff / millisecondsInWeek) + 1;
}

// dist/getWeekYear.js
function getWeekYear(date, options) {var _ref7, _ref8, _ref9, _options$firstWeekCon, _options$locale3, _defaultOptions2$loca3;
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var defaultOptions2 = getDefaultOptions();
  var firstWeekContainsDate = (_ref7 = (_ref8 = (_ref9 = (_options$firstWeekCon = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon !== void 0 ? _options$firstWeekCon : options === null || options === void 0 || (_options$locale3 = options.locale) === null || _options$locale3 === void 0 || (_options$locale3 = _options$locale3.options) === null || _options$locale3 === void 0 ? void 0 : _options$locale3.firstWeekContainsDate) !== null && _ref9 !== void 0 ? _ref9 : defaultOptions2.firstWeekContainsDate) !== null && _ref8 !== void 0 ? _ref8 : (_defaultOptions2$loca3 = defaultOptions2.locale) === null || _defaultOptions2$loca3 === void 0 || (_defaultOptions2$loca3 = _defaultOptions2$loca3.options) === null || _defaultOptions2$loca3 === void 0 ? void 0 : _defaultOptions2$loca3.firstWeekContainsDate) !== null && _ref7 !== void 0 ? _ref7 : 1;
  var firstWeekOfNextYear = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  firstWeekOfNextYear.setFullYear(year + 1, 0, firstWeekContainsDate);
  firstWeekOfNextYear.setHours(0, 0, 0, 0);
  var startOfNextYear = startOfWeek(firstWeekOfNextYear, options);
  var firstWeekOfThisYear = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  firstWeekOfThisYear.setFullYear(year, 0, firstWeekContainsDate);
  firstWeekOfThisYear.setHours(0, 0, 0, 0);
  var startOfThisYear = startOfWeek(firstWeekOfThisYear, options);
  if (+_date >= +startOfNextYear) {
    return year + 1;
  } else if (+_date >= +startOfThisYear) {
    return year;
  } else {
    return year - 1;
  }
}

// dist/startOfWeekYear.js
function startOfWeekYear(date, options) {var _ref0, _ref1, _ref10, _options$firstWeekCon2, _options$locale4, _defaultOptions2$loca4;
  var defaultOptions2 = getDefaultOptions();
  var firstWeekContainsDate = (_ref0 = (_ref1 = (_ref10 = (_options$firstWeekCon2 = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon2 !== void 0 ? _options$firstWeekCon2 : options === null || options === void 0 || (_options$locale4 = options.locale) === null || _options$locale4 === void 0 || (_options$locale4 = _options$locale4.options) === null || _options$locale4 === void 0 ? void 0 : _options$locale4.firstWeekContainsDate) !== null && _ref10 !== void 0 ? _ref10 : defaultOptions2.firstWeekContainsDate) !== null && _ref1 !== void 0 ? _ref1 : (_defaultOptions2$loca4 = defaultOptions2.locale) === null || _defaultOptions2$loca4 === void 0 || (_defaultOptions2$loca4 = _defaultOptions2$loca4.options) === null || _defaultOptions2$loca4 === void 0 ? void 0 : _defaultOptions2$loca4.firstWeekContainsDate) !== null && _ref0 !== void 0 ? _ref0 : 1;
  var year = getWeekYear(date, options);
  var firstWeek = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  firstWeek.setFullYear(year, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  var _date = startOfWeek(firstWeek, options);
  return _date;
}

// dist/getWeek.js
function getWeek(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = +startOfWeek(_date, options) - +startOfWeekYear(_date, options);
  return Math.round(diff / millisecondsInWeek) + 1;
}

// dist/_lib/addLeadingZeros.js
function addLeadingZeros(number, targetLength) {
  var sign = number < 0 ? "-" : "";
  var output = Math.abs(number).toString().padStart(targetLength, "0");
  return sign + output;
}

// dist/_lib/format/lightFormatters.js
var lightFormatters = {
  y: function y(date, token) {
    var signedYear = date.getFullYear();
    var year = signedYear > 0 ? signedYear : 1 - signedYear;
    return addLeadingZeros(token === "yy" ? year % 100 : year, token.length);
  },
  M: function M(date, token) {
    var month = date.getMonth();
    return token === "M" ? String(month + 1) : addLeadingZeros(month + 1, 2);
  },
  d: function d(date, token) {
    return addLeadingZeros(date.getDate(), token.length);
  },
  a: function a(date, token) {
    var dayPeriodEnumValue = date.getHours() / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return dayPeriodEnumValue.toUpperCase();
      case "aaa":
        return dayPeriodEnumValue;
      case "aaaaa":
        return dayPeriodEnumValue[0];
      case "aaaa":
      default:
        return dayPeriodEnumValue === "am" ? "a.m." : "p.m.";
    }
  },
  h: function h(date, token) {
    return addLeadingZeros(date.getHours() % 12 || 12, token.length);
  },
  H: function H(date, token) {
    return addLeadingZeros(date.getHours(), token.length);
  },
  m: function m(date, token) {
    return addLeadingZeros(date.getMinutes(), token.length);
  },
  s: function s(date, token) {
    return addLeadingZeros(date.getSeconds(), token.length);
  },
  S: function S(date, token) {
    var numberOfDigits = token.length;
    var milliseconds = date.getMilliseconds();
    var fractionalSeconds = Math.trunc(milliseconds * Math.pow(10, numberOfDigits - 3));
    return addLeadingZeros(fractionalSeconds, token.length);
  }
};

// dist/_lib/format/formatters.js
var dayPeriodEnum = {
  am: "am",
  pm: "pm",
  midnight: "midnight",
  noon: "noon",
  morning: "morning",
  afternoon: "afternoon",
  evening: "evening",
  night: "night"
};
var formatters = {
  G: function G(date, token, localize2) {
    var era = date.getFullYear() > 0 ? 1 : 0;
    switch (token) {
      case "G":
      case "GG":
      case "GGG":
        return localize2.era(era, { width: "abbreviated" });
      case "GGGGG":
        return localize2.era(era, { width: "narrow" });
      case "GGGG":
      default:
        return localize2.era(era, { width: "wide" });
    }
  },
  y: function y(date, token, localize2) {
    if (token === "yo") {
      var signedYear = date.getFullYear();
      var year = signedYear > 0 ? signedYear : 1 - signedYear;
      return localize2.ordinalNumber(year, { unit: "year" });
    }
    return lightFormatters.y(date, token);
  },
  Y: function Y(date, token, localize2, options) {
    var signedWeekYear = getWeekYear(date, options);
    var weekYear = signedWeekYear > 0 ? signedWeekYear : 1 - signedWeekYear;
    if (token === "YY") {
      var twoDigitYear = weekYear % 100;
      return addLeadingZeros(twoDigitYear, 2);
    }
    if (token === "Yo") {
      return localize2.ordinalNumber(weekYear, { unit: "year" });
    }
    return addLeadingZeros(weekYear, token.length);
  },
  R: function R(date, token) {
    var isoWeekYear = getISOWeekYear(date);
    return addLeadingZeros(isoWeekYear, token.length);
  },
  u: function u(date, token) {
    var year = date.getFullYear();
    return addLeadingZeros(year, token.length);
  },
  Q: function Q(date, token, localize2) {
    var quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      case "Q":
        return String(quarter);
      case "QQ":
        return addLeadingZeros(quarter, 2);
      case "Qo":
        return localize2.ordinalNumber(quarter, { unit: "quarter" });
      case "QQQ":
        return localize2.quarter(quarter, {
          width: "abbreviated",
          context: "formatting"
        });
      case "QQQQQ":
        return localize2.quarter(quarter, {
          width: "narrow",
          context: "formatting"
        });
      case "QQQQ":
      default:
        return localize2.quarter(quarter, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  q: function q(date, token, localize2) {
    var quarter = Math.ceil((date.getMonth() + 1) / 3);
    switch (token) {
      case "q":
        return String(quarter);
      case "qq":
        return addLeadingZeros(quarter, 2);
      case "qo":
        return localize2.ordinalNumber(quarter, { unit: "quarter" });
      case "qqq":
        return localize2.quarter(quarter, {
          width: "abbreviated",
          context: "standalone"
        });
      case "qqqqq":
        return localize2.quarter(quarter, {
          width: "narrow",
          context: "standalone"
        });
      case "qqqq":
      default:
        return localize2.quarter(quarter, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  M: function M(date, token, localize2) {
    var month = date.getMonth();
    switch (token) {
      case "M":
      case "MM":
        return lightFormatters.M(date, token);
      case "Mo":
        return localize2.ordinalNumber(month + 1, { unit: "month" });
      case "MMM":
        return localize2.month(month, {
          width: "abbreviated",
          context: "formatting"
        });
      case "MMMMM":
        return localize2.month(month, {
          width: "narrow",
          context: "formatting"
        });
      case "MMMM":
      default:
        return localize2.month(month, { width: "wide", context: "formatting" });
    }
  },
  L: function L(date, token, localize2) {
    var month = date.getMonth();
    switch (token) {
      case "L":
        return String(month + 1);
      case "LL":
        return addLeadingZeros(month + 1, 2);
      case "Lo":
        return localize2.ordinalNumber(month + 1, { unit: "month" });
      case "LLL":
        return localize2.month(month, {
          width: "abbreviated",
          context: "standalone"
        });
      case "LLLLL":
        return localize2.month(month, {
          width: "narrow",
          context: "standalone"
        });
      case "LLLL":
      default:
        return localize2.month(month, { width: "wide", context: "standalone" });
    }
  },
  w: function w(date, token, localize2, options) {
    var week = getWeek(date, options);
    if (token === "wo") {
      return localize2.ordinalNumber(week, { unit: "week" });
    }
    return addLeadingZeros(week, token.length);
  },
  I: function I(date, token, localize2) {
    var isoWeek = getISOWeek(date);
    if (token === "Io") {
      return localize2.ordinalNumber(isoWeek, { unit: "week" });
    }
    return addLeadingZeros(isoWeek, token.length);
  },
  d: function d(date, token, localize2) {
    if (token === "do") {
      return localize2.ordinalNumber(date.getDate(), { unit: "date" });
    }
    return lightFormatters.d(date, token);
  },
  D: function D(date, token, localize2) {
    var dayOfYear = getDayOfYear(date);
    if (token === "Do") {
      return localize2.ordinalNumber(dayOfYear, { unit: "dayOfYear" });
    }
    return addLeadingZeros(dayOfYear, token.length);
  },
  E: function E(date, token, localize2) {
    var dayOfWeek = date.getDay();
    switch (token) {
      case "E":
      case "EE":
      case "EEE":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "EEEEE":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "EEEEEE":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "EEEE":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  e: function e(date, token, localize2, options) {
    var dayOfWeek = date.getDay();
    var localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "e":
        return String(localDayOfWeek);
      case "ee":
        return addLeadingZeros(localDayOfWeek, 2);
      case "eo":
        return localize2.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "eee":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "eeeee":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "eeeeee":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "eeee":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  c: function c(date, token, localize2, options) {
    var dayOfWeek = date.getDay();
    var localDayOfWeek = (dayOfWeek - options.weekStartsOn + 8) % 7 || 7;
    switch (token) {
      case "c":
        return String(localDayOfWeek);
      case "cc":
        return addLeadingZeros(localDayOfWeek, token.length);
      case "co":
        return localize2.ordinalNumber(localDayOfWeek, { unit: "day" });
      case "ccc":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "standalone"
        });
      case "ccccc":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "standalone"
        });
      case "cccccc":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "standalone"
        });
      case "cccc":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "standalone"
        });
    }
  },
  i: function i(date, token, localize2) {
    var dayOfWeek = date.getDay();
    var isoDayOfWeek = dayOfWeek === 0 ? 7 : dayOfWeek;
    switch (token) {
      case "i":
        return String(isoDayOfWeek);
      case "ii":
        return addLeadingZeros(isoDayOfWeek, token.length);
      case "io":
        return localize2.ordinalNumber(isoDayOfWeek, { unit: "day" });
      case "iii":
        return localize2.day(dayOfWeek, {
          width: "abbreviated",
          context: "formatting"
        });
      case "iiiii":
        return localize2.day(dayOfWeek, {
          width: "narrow",
          context: "formatting"
        });
      case "iiiiii":
        return localize2.day(dayOfWeek, {
          width: "short",
          context: "formatting"
        });
      case "iiii":
      default:
        return localize2.day(dayOfWeek, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  a: function a(date, token, localize2) {
    var hours = date.getHours();
    var dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    switch (token) {
      case "a":
      case "aa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "aaa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "aaaaa":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "aaaa":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  b: function b(date, token, localize2) {
    var hours = date.getHours();
    var dayPeriodEnumValue;
    if (hours === 12) {
      dayPeriodEnumValue = dayPeriodEnum.noon;
    } else if (hours === 0) {
      dayPeriodEnumValue = dayPeriodEnum.midnight;
    } else {
      dayPeriodEnumValue = hours / 12 >= 1 ? "pm" : "am";
    }
    switch (token) {
      case "b":
      case "bb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "bbb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        }).toLowerCase();
      case "bbbbb":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "bbbb":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  B: function B(date, token, localize2) {
    var hours = date.getHours();
    var dayPeriodEnumValue;
    if (hours >= 17) {
      dayPeriodEnumValue = dayPeriodEnum.evening;
    } else if (hours >= 12) {
      dayPeriodEnumValue = dayPeriodEnum.afternoon;
    } else if (hours >= 4) {
      dayPeriodEnumValue = dayPeriodEnum.morning;
    } else {
      dayPeriodEnumValue = dayPeriodEnum.night;
    }
    switch (token) {
      case "B":
      case "BB":
      case "BBB":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "abbreviated",
          context: "formatting"
        });
      case "BBBBB":
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "narrow",
          context: "formatting"
        });
      case "BBBB":
      default:
        return localize2.dayPeriod(dayPeriodEnumValue, {
          width: "wide",
          context: "formatting"
        });
    }
  },
  h: function h(date, token, localize2) {
    if (token === "ho") {
      var hours = date.getHours() % 12;
      if (hours === 0)
      hours = 12;
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return lightFormatters.h(date, token);
  },
  H: function H(date, token, localize2) {
    if (token === "Ho") {
      return localize2.ordinalNumber(date.getHours(), { unit: "hour" });
    }
    return lightFormatters.H(date, token);
  },
  K: function K(date, token, localize2) {
    var hours = date.getHours() % 12;
    if (token === "Ko") {
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return addLeadingZeros(hours, token.length);
  },
  k: function k(date, token, localize2) {
    var hours = date.getHours();
    if (hours === 0)
    hours = 24;
    if (token === "ko") {
      return localize2.ordinalNumber(hours, { unit: "hour" });
    }
    return addLeadingZeros(hours, token.length);
  },
  m: function m(date, token, localize2) {
    if (token === "mo") {
      return localize2.ordinalNumber(date.getMinutes(), { unit: "minute" });
    }
    return lightFormatters.m(date, token);
  },
  s: function s(date, token, localize2) {
    if (token === "so") {
      return localize2.ordinalNumber(date.getSeconds(), { unit: "second" });
    }
    return lightFormatters.s(date, token);
  },
  S: function S(date, token) {
    return lightFormatters.S(date, token);
  },
  X: function X(date, token, _localize) {
    var timezoneOffset = date.getTimezoneOffset();
    if (timezoneOffset === 0) {
      return "Z";
    }
    switch (token) {
      case "X":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "XXXX":
      case "XX":
        return formatTimezone(timezoneOffset);
      case "XXXXX":
      case "XXX":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  x: function x(date, token, _localize) {
    var timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "x":
        return formatTimezoneWithOptionalMinutes(timezoneOffset);
      case "xxxx":
      case "xx":
        return formatTimezone(timezoneOffset);
      case "xxxxx":
      case "xxx":
      default:
        return formatTimezone(timezoneOffset, ":");
    }
  },
  O: function O(date, token, _localize) {
    var timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "O":
      case "OO":
      case "OOO":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "OOOO":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  z: function z(date, token, _localize) {
    var timezoneOffset = date.getTimezoneOffset();
    switch (token) {
      case "z":
      case "zz":
      case "zzz":
        return "GMT" + formatTimezoneShort(timezoneOffset, ":");
      case "zzzz":
      default:
        return "GMT" + formatTimezone(timezoneOffset, ":");
    }
  },
  t: function t(date, token, _localize) {
    var timestamp = Math.trunc(+date / 1000);
    return addLeadingZeros(timestamp, token.length);
  },
  T: function T(date, token, _localize) {
    return addLeadingZeros(+date, token.length);
  }
};
function formatTimezoneShort(offset) {var delimiter = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
  var sign = offset > 0 ? "-" : "+";
  var absOffset = Math.abs(offset);
  var hours = Math.trunc(absOffset / 60);
  var minutes = absOffset % 60;
  if (minutes === 0) {
    return sign + String(hours);
  }
  return sign + String(hours) + delimiter + addLeadingZeros(minutes, 2);
}
function formatTimezoneWithOptionalMinutes(offset, delimiter) {
  if (offset % 60 === 0) {
    var sign = offset > 0 ? "-" : "+";
    return sign + addLeadingZeros(Math.abs(offset) / 60, 2);
  }
  return formatTimezone(offset, delimiter);
}
function formatTimezone(offset) {var delimiter = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "";
  var sign = offset > 0 ? "-" : "+";
  var absOffset = Math.abs(offset);
  var hours = addLeadingZeros(Math.trunc(absOffset / 60), 2);
  var minutes = addLeadingZeros(absOffset % 60, 2);
  return sign + hours + delimiter + minutes;
}

// dist/_lib/format/longFormatters.js
var dateLongFormatter = function dateLongFormatter(pattern, formatLong2) {
  switch (pattern) {
    case "P":
      return formatLong2.date({ width: "short" });
    case "PP":
      return formatLong2.date({ width: "medium" });
    case "PPP":
      return formatLong2.date({ width: "long" });
    case "PPPP":
    default:
      return formatLong2.date({ width: "full" });
  }
};
var timeLongFormatter = function timeLongFormatter(pattern, formatLong2) {
  switch (pattern) {
    case "p":
      return formatLong2.time({ width: "short" });
    case "pp":
      return formatLong2.time({ width: "medium" });
    case "ppp":
      return formatLong2.time({ width: "long" });
    case "pppp":
    default:
      return formatLong2.time({ width: "full" });
  }
};
var dateTimeLongFormatter = function dateTimeLongFormatter(pattern, formatLong2) {
  var matchResult = pattern.match(/(P+)(p+)?/) || [];
  var datePattern = matchResult[1];
  var timePattern = matchResult[2];
  if (!timePattern) {
    return dateLongFormatter(pattern, formatLong2);
  }
  var dateTimeFormat;
  switch (datePattern) {
    case "P":
      dateTimeFormat = formatLong2.dateTime({ width: "short" });
      break;
    case "PP":
      dateTimeFormat = formatLong2.dateTime({ width: "medium" });
      break;
    case "PPP":
      dateTimeFormat = formatLong2.dateTime({ width: "long" });
      break;
    case "PPPP":
    default:
      dateTimeFormat = formatLong2.dateTime({ width: "full" });
      break;
  }
  return dateTimeFormat.replace("{{date}}", dateLongFormatter(datePattern, formatLong2)).replace("{{time}}", timeLongFormatter(timePattern, formatLong2));
};
var longFormatters = {
  p: timeLongFormatter,
  P: dateTimeLongFormatter
};

// dist/_lib/protectedTokens.js
var dayOfYearTokenRE = /^D+$/;
var weekYearTokenRE = /^Y+$/;
var throwTokens = ["D", "DD", "YY", "YYYY"];
function isProtectedDayOfYearToken(token) {
  return dayOfYearTokenRE.test(token);
}
function isProtectedWeekYearToken(token) {
  return weekYearTokenRE.test(token);
}
function warnOrThrowProtectedError(token, format, input) {
  var _message = message(token, format, input);
  console.warn(_message);
  if (throwTokens.includes(token))
  throw new RangeError(_message);
}
function message(token, format, input) {
  var subject = token[0] === "Y" ? "years" : "days of the month";
  return "Use `".concat(token.toLowerCase(), "` instead of `").concat(token, "` (in `").concat(format, "`) for formatting ").concat(subject, " to the input `").concat(input, "`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md");
}

// dist/format.js
var formattingTokensRegExp = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
var longFormattingTokensRegExp = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
var escapedStringRegExp = /^'([^]*?)'?$/;
var doubleQuoteRegExp = /''/g;
var unescapedLatinCharacterRegExp = /[a-zA-Z]/;
function format(date, formatStr, options) {var _ref11, _options$locale5, _ref12, _ref13, _ref14, _options$firstWeekCon3, _options$locale6, _defaultOptions2$loca5, _ref15, _ref16, _ref17, _options$weekStartsOn3, _options$locale7, _defaultOptions2$loca6;
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref11 = (_options$locale5 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale5 !== void 0 ? _options$locale5 : defaultOptions2.locale) !== null && _ref11 !== void 0 ? _ref11 : enUS;
  var firstWeekContainsDate = (_ref12 = (_ref13 = (_ref14 = (_options$firstWeekCon3 = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon3 !== void 0 ? _options$firstWeekCon3 : options === null || options === void 0 || (_options$locale6 = options.locale) === null || _options$locale6 === void 0 || (_options$locale6 = _options$locale6.options) === null || _options$locale6 === void 0 ? void 0 : _options$locale6.firstWeekContainsDate) !== null && _ref14 !== void 0 ? _ref14 : defaultOptions2.firstWeekContainsDate) !== null && _ref13 !== void 0 ? _ref13 : (_defaultOptions2$loca5 = defaultOptions2.locale) === null || _defaultOptions2$loca5 === void 0 || (_defaultOptions2$loca5 = _defaultOptions2$loca5.options) === null || _defaultOptions2$loca5 === void 0 ? void 0 : _defaultOptions2$loca5.firstWeekContainsDate) !== null && _ref12 !== void 0 ? _ref12 : 1;
  var weekStartsOn = (_ref15 = (_ref16 = (_ref17 = (_options$weekStartsOn3 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn3 !== void 0 ? _options$weekStartsOn3 : options === null || options === void 0 || (_options$locale7 = options.locale) === null || _options$locale7 === void 0 || (_options$locale7 = _options$locale7.options) === null || _options$locale7 === void 0 ? void 0 : _options$locale7.weekStartsOn) !== null && _ref17 !== void 0 ? _ref17 : defaultOptions2.weekStartsOn) !== null && _ref16 !== void 0 ? _ref16 : (_defaultOptions2$loca6 = defaultOptions2.locale) === null || _defaultOptions2$loca6 === void 0 || (_defaultOptions2$loca6 = _defaultOptions2$loca6.options) === null || _defaultOptions2$loca6 === void 0 ? void 0 : _defaultOptions2$loca6.weekStartsOn) !== null && _ref15 !== void 0 ? _ref15 : 0;
  var originalDate = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (!isValid(originalDate)) {
    throw new RangeError("Invalid time value");
  }
  var parts = formatStr.match(longFormattingTokensRegExp).map(function (substring) {
    var firstCharacter = substring[0];
    if (firstCharacter === "p" || firstCharacter === "P") {
      var longFormatter = longFormatters[firstCharacter];
      return longFormatter(substring, locale.formatLong);
    }
    return substring;
  }).join("").match(formattingTokensRegExp).map(function (substring) {
    if (substring === "''") {
      return { isToken: false, value: "'" };
    }
    var firstCharacter = substring[0];
    if (firstCharacter === "'") {
      return { isToken: false, value: cleanEscapedString(substring) };
    }
    if (formatters[firstCharacter]) {
      return { isToken: true, value: substring };
    }
    if (firstCharacter.match(unescapedLatinCharacterRegExp)) {
      throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
    }
    return { isToken: false, value: substring };
  });
  if (locale.localize.preprocessor) {
    parts = locale.localize.preprocessor(originalDate, parts);
  }
  var formatterOptions = {
    firstWeekContainsDate: firstWeekContainsDate,
    weekStartsOn: weekStartsOn,
    locale: locale
  };
  return parts.map(function (part) {
    if (!part.isToken)
    return part.value;
    var token = part.value;
    if (!(options !== null && options !== void 0 && options.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(token) || !(options !== null && options !== void 0 && options.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(token)) {
      warnOrThrowProtectedError(token, formatStr, String(date));
    }
    var formatter = formatters[token[0]];
    return formatter(originalDate, token, locale.localize, formatterOptions);
  }).join("");
}
function cleanEscapedString(input) {
  var matched = input.match(escapedStringRegExp);
  if (!matched) {
    return input;
  }
  return matched[1].replace(doubleQuoteRegExp, "'");
}

// dist/fp/format.js
var format2 = convertToFP(format, 2);
// dist/formatDistance.js
function formatDistance2(laterDate, earlierDate, options) {var _ref18, _options$locale8;
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref18 = (_options$locale8 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale8 !== void 0 ? _options$locale8 : defaultOptions2.locale) !== null && _ref18 !== void 0 ? _ref18 : enUS;
  var minutesInAlmostTwoDays = 2520;
  var comparison = compareAsc(laterDate, earlierDate);
  if (isNaN(comparison))
  throw new RangeError("Invalid time value");
  var localizeOptions = Object.assign({}, options, {
    addSuffix: options === null || options === void 0 ? void 0 : options.addSuffix,
    comparison: comparison
  });
  var _normalizeDates33 = normalizeDates.apply(void 0, [options === null || options === void 0 ? void 0 : options.in].concat(_toConsumableArray(comparison > 0 ? [earlierDate, laterDate] : [laterDate, earlierDate]))),_normalizeDates34 = _slicedToArray(_normalizeDates33, 2),laterDate_ = _normalizeDates34[0],earlierDate_ = _normalizeDates34[1];
  var seconds = differenceInSeconds(earlierDate_, laterDate_);
  var offsetInSeconds = (getTimezoneOffsetInMilliseconds(earlierDate_) - getTimezoneOffsetInMilliseconds(laterDate_)) / 1000;
  var minutes = Math.round((seconds - offsetInSeconds) / 60);
  var months;
  if (minutes < 2) {
    if (options !== null && options !== void 0 && options.includeSeconds) {
      if (seconds < 5) {
        return locale.formatDistance("lessThanXSeconds", 5, localizeOptions);
      } else if (seconds < 10) {
        return locale.formatDistance("lessThanXSeconds", 10, localizeOptions);
      } else if (seconds < 20) {
        return locale.formatDistance("lessThanXSeconds", 20, localizeOptions);
      } else if (seconds < 40) {
        return locale.formatDistance("halfAMinute", 0, localizeOptions);
      } else if (seconds < 60) {
        return locale.formatDistance("lessThanXMinutes", 1, localizeOptions);
      } else {
        return locale.formatDistance("xMinutes", 1, localizeOptions);
      }
    } else {
      if (minutes === 0) {
        return locale.formatDistance("lessThanXMinutes", 1, localizeOptions);
      } else {
        return locale.formatDistance("xMinutes", minutes, localizeOptions);
      }
    }
  } else if (minutes < 45) {
    return locale.formatDistance("xMinutes", minutes, localizeOptions);
  } else if (minutes < 90) {
    return locale.formatDistance("aboutXHours", 1, localizeOptions);
  } else if (minutes < minutesInDay) {
    var hours = Math.round(minutes / 60);
    return locale.formatDistance("aboutXHours", hours, localizeOptions);
  } else if (minutes < minutesInAlmostTwoDays) {
    return locale.formatDistance("xDays", 1, localizeOptions);
  } else if (minutes < minutesInMonth) {
    var _days = Math.round(minutes / minutesInDay);
    return locale.formatDistance("xDays", _days, localizeOptions);
  } else if (minutes < minutesInMonth * 2) {
    months = Math.round(minutes / minutesInMonth);
    return locale.formatDistance("aboutXMonths", months, localizeOptions);
  }
  months = differenceInMonths(earlierDate_, laterDate_);
  if (months < 12) {
    var nearestMonth = Math.round(minutes / minutesInMonth);
    return locale.formatDistance("xMonths", nearestMonth, localizeOptions);
  } else {
    var monthsSinceStartOfYear = months % 12;
    var years = Math.trunc(months / 12);
    if (monthsSinceStartOfYear < 3) {
      return locale.formatDistance("aboutXYears", years, localizeOptions);
    } else if (monthsSinceStartOfYear < 9) {
      return locale.formatDistance("overXYears", years, localizeOptions);
    } else {
      return locale.formatDistance("almostXYears", years + 1, localizeOptions);
    }
  }
}

// dist/fp/formatDistance.js
var formatDistance3 = convertToFP(formatDistance2, 2);
// dist/formatDistanceStrict.js
function formatDistanceStrict(laterDate, earlierDate, options) {var _ref19, _options$locale9, _options$roundingMeth;
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref19 = (_options$locale9 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale9 !== void 0 ? _options$locale9 : defaultOptions2.locale) !== null && _ref19 !== void 0 ? _ref19 : enUS;
  var comparison = compareAsc(laterDate, earlierDate);
  if (isNaN(comparison)) {
    throw new RangeError("Invalid time value");
  }
  var localizeOptions = Object.assign({}, options, {
    addSuffix: options === null || options === void 0 ? void 0 : options.addSuffix,
    comparison: comparison
  });
  var _normalizeDates35 = normalizeDates.apply(void 0, [options === null || options === void 0 ? void 0 : options.in].concat(_toConsumableArray(comparison > 0 ? [earlierDate, laterDate] : [laterDate, earlierDate]))),_normalizeDates36 = _slicedToArray(_normalizeDates35, 2),laterDate_ = _normalizeDates36[0],earlierDate_ = _normalizeDates36[1];
  var roundingMethod = getRoundingMethod((_options$roundingMeth = options === null || options === void 0 ? void 0 : options.roundingMethod) !== null && _options$roundingMeth !== void 0 ? _options$roundingMeth : "round");
  var milliseconds = earlierDate_.getTime() - laterDate_.getTime();
  var minutes = milliseconds / millisecondsInMinute;
  var timezoneOffset = getTimezoneOffsetInMilliseconds(earlierDate_) - getTimezoneOffsetInMilliseconds(laterDate_);
  var dstNormalizedMinutes = (milliseconds - timezoneOffset) / millisecondsInMinute;
  var defaultUnit = options === null || options === void 0 ? void 0 : options.unit;
  var unit;
  if (!defaultUnit) {
    if (minutes < 1) {
      unit = "second";
    } else if (minutes < 60) {
      unit = "minute";
    } else if (minutes < minutesInDay) {
      unit = "hour";
    } else if (dstNormalizedMinutes < minutesInMonth) {
      unit = "day";
    } else if (dstNormalizedMinutes < minutesInYear) {
      unit = "month";
    } else {
      unit = "year";
    }
  } else {
    unit = defaultUnit;
  }
  if (unit === "second") {
    var seconds = roundingMethod(milliseconds / 1000);
    return locale.formatDistance("xSeconds", seconds, localizeOptions);
  } else if (unit === "minute") {
    var roundedMinutes = roundingMethod(minutes);
    return locale.formatDistance("xMinutes", roundedMinutes, localizeOptions);
  } else if (unit === "hour") {
    var hours = roundingMethod(minutes / 60);
    return locale.formatDistance("xHours", hours, localizeOptions);
  } else if (unit === "day") {
    var _days2 = roundingMethod(dstNormalizedMinutes / minutesInDay);
    return locale.formatDistance("xDays", _days2, localizeOptions);
  } else if (unit === "month") {
    var _months = roundingMethod(dstNormalizedMinutes / minutesInMonth);
    return _months === 12 && defaultUnit !== "month" ? locale.formatDistance("xYears", 1, localizeOptions) : locale.formatDistance("xMonths", _months, localizeOptions);
  } else {
    var years = roundingMethod(dstNormalizedMinutes / minutesInYear);
    return locale.formatDistance("xYears", years, localizeOptions);
  }
}

// dist/fp/formatDistanceStrict.js
var formatDistanceStrict2 = convertToFP(formatDistanceStrict, 2);
// dist/fp/formatDistanceStrictWithOptions.js
var _formatDistanceStrictWithOptions = convertToFP(formatDistanceStrict, 3);
// dist/fp/formatDistanceWithOptions.js
var _formatDistanceWithOptions = convertToFP(formatDistance2, 3);
// dist/formatDuration.js
var defaultFormat = [
"years",
"months",
"weeks",
"days",
"hours",
"minutes",
"seconds"];

function formatDuration(duration, options) {var _ref20, _options$locale0, _options$format, _options$zero, _options$delimiter;
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref20 = (_options$locale0 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale0 !== void 0 ? _options$locale0 : defaultOptions2.locale) !== null && _ref20 !== void 0 ? _ref20 : enUS;
  var format3 = (_options$format = options === null || options === void 0 ? void 0 : options.format) !== null && _options$format !== void 0 ? _options$format : defaultFormat;
  var zero = (_options$zero = options === null || options === void 0 ? void 0 : options.zero) !== null && _options$zero !== void 0 ? _options$zero : false;
  var delimiter = (_options$delimiter = options === null || options === void 0 ? void 0 : options.delimiter) !== null && _options$delimiter !== void 0 ? _options$delimiter : " ";
  if (!locale.formatDistance) {
    return "";
  }
  var result = format3.reduce(function (acc, unit) {
    var token = "x".concat(unit.replace(/(^.)/, function (m) {return m.toUpperCase();}));
    var value = duration[unit];
    if (value !== undefined && (zero || duration[unit])) {
      return acc.concat(locale.formatDistance(token, value));
    }
    return acc;
  }, []).join(delimiter);
  return result;
}

// dist/fp/formatDuration.js
var formatDuration2 = convertToFP(formatDuration, 1);
// dist/fp/formatDurationWithOptions.js
var _formatDurationWithOptions = convertToFP(formatDuration, 2);
// dist/formatISO.js
function formatISO(date, options) {var _options$format2, _options$representati;
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(+date_)) {
    throw new RangeError("Invalid time value");
  }
  var format3 = (_options$format2 = options === null || options === void 0 ? void 0 : options.format) !== null && _options$format2 !== void 0 ? _options$format2 : "extended";
  var representation = (_options$representati = options === null || options === void 0 ? void 0 : options.representation) !== null && _options$representati !== void 0 ? _options$representati : "complete";
  var result = "";
  var tzOffset = "";
  var dateDelimiter = format3 === "extended" ? "-" : "";
  var timeDelimiter = format3 === "extended" ? ":" : "";
  if (representation !== "time") {
    var day = addLeadingZeros(date_.getDate(), 2);
    var month = addLeadingZeros(date_.getMonth() + 1, 2);
    var year = addLeadingZeros(date_.getFullYear(), 4);
    result = "".concat(year).concat(dateDelimiter).concat(month).concat(dateDelimiter).concat(day);
  }
  if (representation !== "date") {
    var offset = date_.getTimezoneOffset();
    if (offset !== 0) {
      var absoluteOffset = Math.abs(offset);
      var hourOffset = addLeadingZeros(Math.trunc(absoluteOffset / 60), 2);
      var minuteOffset = addLeadingZeros(absoluteOffset % 60, 2);
      var sign = offset < 0 ? "+" : "-";
      tzOffset = "".concat(sign).concat(hourOffset, ":").concat(minuteOffset);
    } else {
      tzOffset = "Z";
    }
    var hour = addLeadingZeros(date_.getHours(), 2);
    var minute = addLeadingZeros(date_.getMinutes(), 2);
    var second = addLeadingZeros(date_.getSeconds(), 2);
    var separator = result === "" ? "" : "T";
    var time = [hour, minute, second].join(timeDelimiter);
    result = "".concat(result).concat(separator).concat(time).concat(tzOffset);
  }
  return result;
}

// dist/fp/formatISO.js
var formatISO2 = convertToFP(formatISO, 1);
// dist/formatISO9075.js
function formatISO9075(date, options) {var _options$format3, _options$representati2;
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (!isValid(date_)) {
    throw new RangeError("Invalid time value");
  }
  var format3 = (_options$format3 = options === null || options === void 0 ? void 0 : options.format) !== null && _options$format3 !== void 0 ? _options$format3 : "extended";
  var representation = (_options$representati2 = options === null || options === void 0 ? void 0 : options.representation) !== null && _options$representati2 !== void 0 ? _options$representati2 : "complete";
  var result = "";
  var dateDelimiter = format3 === "extended" ? "-" : "";
  var timeDelimiter = format3 === "extended" ? ":" : "";
  if (representation !== "time") {
    var day = addLeadingZeros(date_.getDate(), 2);
    var month = addLeadingZeros(date_.getMonth() + 1, 2);
    var year = addLeadingZeros(date_.getFullYear(), 4);
    result = "".concat(year).concat(dateDelimiter).concat(month).concat(dateDelimiter).concat(day);
  }
  if (representation !== "date") {
    var hour = addLeadingZeros(date_.getHours(), 2);
    var minute = addLeadingZeros(date_.getMinutes(), 2);
    var second = addLeadingZeros(date_.getSeconds(), 2);
    var separator = result === "" ? "" : " ";
    result = "".concat(result).concat(separator).concat(hour).concat(timeDelimiter).concat(minute).concat(timeDelimiter).concat(second);
  }
  return result;
}

// dist/fp/formatISO9075.js
var formatISO90752 = convertToFP(formatISO9075, 1);
// dist/fp/formatISO9075WithOptions.js
var _formatISO9075WithOptions = convertToFP(formatISO9075, 2);
// dist/formatISODuration.js
function formatISODuration(duration) {
  var _duration$years2 =






    duration.years,years = _duration$years2 === void 0 ? 0 : _duration$years2,_duration$months2 = duration.months,months = _duration$months2 === void 0 ? 0 : _duration$months2,_duration$days2 = duration.days,days = _duration$days2 === void 0 ? 0 : _duration$days2,_duration$hours2 = duration.hours,hours = _duration$hours2 === void 0 ? 0 : _duration$hours2,_duration$minutes2 = duration.minutes,minutes = _duration$minutes2 === void 0 ? 0 : _duration$minutes2,_duration$seconds2 = duration.seconds,seconds = _duration$seconds2 === void 0 ? 0 : _duration$seconds2;
  return "P".concat(years, "Y").concat(months, "M").concat(days, "DT").concat(hours, "H").concat(minutes, "M").concat(seconds, "S");
}

// dist/fp/formatISODuration.js
var formatISODuration2 = convertToFP(formatISODuration, 1);
// dist/fp/formatISOWithOptions.js
var _formatISOWithOptions = convertToFP(formatISO, 2);
// dist/formatRFC3339.js
function formatRFC3339(date, options) {var _options$fractionDigi;
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (!isValid(date_)) {
    throw new RangeError("Invalid time value");
  }
  var fractionDigits = (_options$fractionDigi = options === null || options === void 0 ? void 0 : options.fractionDigits) !== null && _options$fractionDigi !== void 0 ? _options$fractionDigi : 0;
  var day = addLeadingZeros(date_.getDate(), 2);
  var month = addLeadingZeros(date_.getMonth() + 1, 2);
  var year = date_.getFullYear();
  var hour = addLeadingZeros(date_.getHours(), 2);
  var minute = addLeadingZeros(date_.getMinutes(), 2);
  var second = addLeadingZeros(date_.getSeconds(), 2);
  var fractionalSecond = "";
  if (fractionDigits > 0) {
    var _milliseconds = date_.getMilliseconds();
    var fractionalSeconds = Math.trunc(_milliseconds * Math.pow(10, fractionDigits - 3));
    fractionalSecond = "." + addLeadingZeros(fractionalSeconds, fractionDigits);
  }
  var offset = "";
  var tzOffset = date_.getTimezoneOffset();
  if (tzOffset !== 0) {
    var absoluteOffset = Math.abs(tzOffset);
    var hourOffset = addLeadingZeros(Math.trunc(absoluteOffset / 60), 2);
    var minuteOffset = addLeadingZeros(absoluteOffset % 60, 2);
    var sign = tzOffset < 0 ? "+" : "-";
    offset = "".concat(sign).concat(hourOffset, ":").concat(minuteOffset);
  } else {
    offset = "Z";
  }
  return "".concat(year, "-").concat(month, "-").concat(day, "T").concat(hour, ":").concat(minute, ":").concat(second).concat(fractionalSecond).concat(offset);
}

// dist/fp/formatRFC3339.js
var formatRFC33392 = convertToFP(formatRFC3339, 1);
// dist/fp/formatRFC3339WithOptions.js
var _formatRFC3339WithOptions = convertToFP(formatRFC3339, 2);
// dist/formatRFC7231.js
var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
var months = [
"Jan",
"Feb",
"Mar",
"Apr",
"May",
"Jun",
"Jul",
"Aug",
"Sep",
"Oct",
"Nov",
"Dec"];

function formatRFC7231(date) {
  var _date = toDate(date);
  if (!isValid(_date)) {
    throw new RangeError("Invalid time value");
  }
  var dayName = days[_date.getUTCDay()];
  var dayOfMonth = addLeadingZeros(_date.getUTCDate(), 2);
  var monthName = months[_date.getUTCMonth()];
  var year = _date.getUTCFullYear();
  var hour = addLeadingZeros(_date.getUTCHours(), 2);
  var minute = addLeadingZeros(_date.getUTCMinutes(), 2);
  var second = addLeadingZeros(_date.getUTCSeconds(), 2);
  return "".concat(dayName, ", ").concat(dayOfMonth, " ").concat(monthName, " ").concat(year, " ").concat(hour, ":").concat(minute, ":").concat(second, " GMT");
}

// dist/fp/formatRFC7231.js
var formatRFC72312 = convertToFP(formatRFC7231, 1);
// dist/formatRelative.js
function formatRelative2(date, baseDate, options) {var _ref21, _options$locale1, _ref22, _ref23, _ref24, _options$weekStartsOn4, _options$locale10, _defaultOptions2$loca7;
  var _normalizeDates37 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, date, baseDate),_normalizeDates38 = _slicedToArray(_normalizeDates37, 2),date_ = _normalizeDates38[0],baseDate_ = _normalizeDates38[1];
  var defaultOptions2 = getDefaultOptions();
  var locale = (_ref21 = (_options$locale1 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale1 !== void 0 ? _options$locale1 : defaultOptions2.locale) !== null && _ref21 !== void 0 ? _ref21 : enUS;
  var weekStartsOn = (_ref22 = (_ref23 = (_ref24 = (_options$weekStartsOn4 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn4 !== void 0 ? _options$weekStartsOn4 : options === null || options === void 0 || (_options$locale10 = options.locale) === null || _options$locale10 === void 0 || (_options$locale10 = _options$locale10.options) === null || _options$locale10 === void 0 ? void 0 : _options$locale10.weekStartsOn) !== null && _ref24 !== void 0 ? _ref24 : defaultOptions2.weekStartsOn) !== null && _ref23 !== void 0 ? _ref23 : (_defaultOptions2$loca7 = defaultOptions2.locale) === null || _defaultOptions2$loca7 === void 0 || (_defaultOptions2$loca7 = _defaultOptions2$loca7.options) === null || _defaultOptions2$loca7 === void 0 ? void 0 : _defaultOptions2$loca7.weekStartsOn) !== null && _ref22 !== void 0 ? _ref22 : 0;
  var diff = differenceInCalendarDays(date_, baseDate_);
  if (isNaN(diff)) {
    throw new RangeError("Invalid time value");
  }
  var token;
  if (diff < -6) {
    token = "other";
  } else if (diff < -1) {
    token = "lastWeek";
  } else if (diff < 0) {
    token = "yesterday";
  } else if (diff < 1) {
    token = "today";
  } else if (diff < 2) {
    token = "tomorrow";
  } else if (diff < 7) {
    token = "nextWeek";
  } else {
    token = "other";
  }
  var formatStr = locale.formatRelative(token, date_, baseDate_, {
    locale: locale,
    weekStartsOn: weekStartsOn
  });
  return format(date_, formatStr, { locale: locale, weekStartsOn: weekStartsOn });
}

// dist/fp/formatRelative.js
var formatRelative3 = convertToFP(formatRelative2, 2);
// dist/fp/formatRelativeWithOptions.js
var _formatRelativeWithOptions = convertToFP(formatRelative2, 3);
// dist/fp/formatWithOptions.js
var _formatWithOptions = convertToFP(format, 3);
// dist/fromUnixTime.js
function fromUnixTime(unixTime, options) {
  return toDate(unixTime * 1000, options === null || options === void 0 ? void 0 : options.in);
}

// dist/fp/fromUnixTime.js
var fromUnixTime2 = convertToFP(fromUnixTime, 1);
// dist/fp/fromUnixTimeWithOptions.js
var _fromUnixTimeWithOptions = convertToFP(fromUnixTime, 2);
// dist/getDate.js
function getDate(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDate();
}

// dist/fp/getDate.js
var getDate2 = convertToFP(getDate, 1);
// dist/fp/getDateWithOptions.js
var _getDateWithOptions = convertToFP(getDate, 2);
// dist/getDay.js
function getDay(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay();
}

// dist/fp/getDay.js
var getDay2 = convertToFP(getDay, 1);
// dist/fp/getDayOfYear.js
var getDayOfYear2 = convertToFP(getDayOfYear, 1);
// dist/fp/getDayOfYearWithOptions.js
var _getDayOfYearWithOptions = convertToFP(getDayOfYear, 2);
// dist/fp/getDayWithOptions.js
var _getDayWithOptions = convertToFP(getDay, 2);
// dist/getDaysInMonth.js
function getDaysInMonth(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var monthIndex = _date.getMonth();
  var lastDayOfMonth = constructFrom(_date, 0);
  lastDayOfMonth.setFullYear(year, monthIndex + 1, 0);
  lastDayOfMonth.setHours(0, 0, 0, 0);
  return lastDayOfMonth.getDate();
}

// dist/fp/getDaysInMonth.js
var getDaysInMonth2 = convertToFP(getDaysInMonth, 1);
// dist/fp/getDaysInMonthWithOptions.js
var _getDaysInMonthWithOptions = convertToFP(getDaysInMonth, 2);
// dist/isLeapYear.js
function isLeapYear(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}

// dist/getDaysInYear.js
function getDaysInYear(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (Number.isNaN(+_date))
  return NaN;
  return isLeapYear(_date) ? 366 : 365;
}

// dist/fp/getDaysInYear.js
var getDaysInYear2 = convertToFP(getDaysInYear, 1);
// dist/fp/getDaysInYearWithOptions.js
var _getDaysInYearWithOptions = convertToFP(getDaysInYear, 2);
// dist/getDecade.js
function getDecade(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var decade = Math.floor(year / 10) * 10;
  return decade;
}

// dist/fp/getDecade.js
var getDecade2 = convertToFP(getDecade, 1);
// dist/fp/getDecadeWithOptions.js
var _getDecadeWithOptions = convertToFP(getDecade, 2);
// dist/getHours.js
function getHours(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getHours();
}

// dist/fp/getHours.js
var getHours2 = convertToFP(getHours, 1);
// dist/fp/getHoursWithOptions.js
var _getHoursWithOptions = convertToFP(getHours, 2);
// dist/getISODay.js
function getISODay(date, options) {
  var day = toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay();
  return day === 0 ? 7 : day;
}

// dist/fp/getISODay.js
var getISODay2 = convertToFP(getISODay, 1);
// dist/fp/getISODayWithOptions.js
var _getISODayWithOptions = convertToFP(getISODay, 2);
// dist/fp/getISOWeek.js
var getISOWeek2 = convertToFP(getISOWeek, 1);
// dist/fp/getISOWeekWithOptions.js
var _getISOWeekWithOptions = convertToFP(getISOWeek, 2);
// dist/fp/getISOWeekYear.js
var getISOWeekYear2 = convertToFP(getISOWeekYear, 1);
// dist/fp/getISOWeekYearWithOptions.js
var _getISOWeekYearWithOptions = convertToFP(getISOWeekYear, 2);
// dist/getISOWeeksInYear.js
function getISOWeeksInYear(date, options) {
  var thisYear = startOfISOWeekYear(date, options);
  var nextYear = startOfISOWeekYear(addWeeks(thisYear, 60));
  var diff = +nextYear - +thisYear;
  return Math.round(diff / millisecondsInWeek);
}

// dist/fp/getISOWeeksInYear.js
var getISOWeeksInYear2 = convertToFP(getISOWeeksInYear, 1);
// dist/fp/getISOWeeksInYearWithOptions.js
var _getISOWeeksInYearWithOptions = convertToFP(getISOWeeksInYear, 2);
// dist/getMilliseconds.js
function getMilliseconds(date) {
  return toDate(date).getMilliseconds();
}

// dist/fp/getMilliseconds.js
var getMilliseconds2 = convertToFP(getMilliseconds, 1);
// dist/getMinutes.js
function getMinutes(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getMinutes();
}

// dist/fp/getMinutes.js
var getMinutes2 = convertToFP(getMinutes, 1);
// dist/fp/getMinutesWithOptions.js
var _getMinutesWithOptions = convertToFP(getMinutes, 2);
// dist/getMonth.js
function getMonth(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getMonth();
}

// dist/fp/getMonth.js
var getMonth2 = convertToFP(getMonth, 1);
// dist/fp/getMonthWithOptions.js
var _getMonthWithOptions = convertToFP(getMonth, 2);
// dist/getOverlappingDaysInIntervals.js
function getOverlappingDaysInIntervals(intervalLeft, intervalRight) {
  var _sort5 = [
    +toDate(intervalLeft.start),
    +toDate(intervalLeft.end)].
    sort(function (a, b) {return a - b;}),_sort6 = _slicedToArray(_sort5, 2),leftStart = _sort6[0],leftEnd = _sort6[1];
  var _sort7 = [
    +toDate(intervalRight.start),
    +toDate(intervalRight.end)].
    sort(function (a, b) {return a - b;}),_sort8 = _slicedToArray(_sort7, 2),rightStart = _sort8[0],rightEnd = _sort8[1];
  var isOverlapping = leftStart < rightEnd && rightStart < leftEnd;
  if (!isOverlapping)
  return 0;
  var overlapLeft = rightStart < leftStart ? leftStart : rightStart;
  var left = overlapLeft - getTimezoneOffsetInMilliseconds(overlapLeft);
  var overlapRight = rightEnd > leftEnd ? leftEnd : rightEnd;
  var right = overlapRight - getTimezoneOffsetInMilliseconds(overlapRight);
  return Math.ceil((right - left) / millisecondsInDay);
}

// dist/fp/getOverlappingDaysInIntervals.js
var getOverlappingDaysInIntervals2 = convertToFP(getOverlappingDaysInIntervals, 2);
// dist/fp/getQuarter.js
var getQuarter2 = convertToFP(getQuarter, 1);
// dist/fp/getQuarterWithOptions.js
var _getQuarterWithOptions = convertToFP(getQuarter, 2);
// dist/getSeconds.js
function getSeconds(date) {
  return toDate(date).getSeconds();
}

// dist/fp/getSeconds.js
var getSeconds2 = convertToFP(getSeconds, 1);
// dist/getTime.js
function getTime(date) {
  return +toDate(date);
}

// dist/fp/getTime.js
var getTime2 = convertToFP(getTime, 1);
// dist/getUnixTime.js
function getUnixTime(date) {
  return Math.trunc(+toDate(date) / 1000);
}

// dist/fp/getUnixTime.js
var getUnixTime2 = convertToFP(getUnixTime, 1);
// dist/fp/getWeek.js
var getWeek2 = convertToFP(getWeek, 1);
// dist/getWeekOfMonth.js
function getWeekOfMonth(date, options) {var _ref25, _ref26, _ref27, _options$weekStartsOn5, _options$locale11, _defaultOptions2$loca8;
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = (_ref25 = (_ref26 = (_ref27 = (_options$weekStartsOn5 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn5 !== void 0 ? _options$weekStartsOn5 : options === null || options === void 0 || (_options$locale11 = options.locale) === null || _options$locale11 === void 0 || (_options$locale11 = _options$locale11.options) === null || _options$locale11 === void 0 ? void 0 : _options$locale11.weekStartsOn) !== null && _ref27 !== void 0 ? _ref27 : defaultOptions2.weekStartsOn) !== null && _ref26 !== void 0 ? _ref26 : (_defaultOptions2$loca8 = defaultOptions2.locale) === null || _defaultOptions2$loca8 === void 0 || (_defaultOptions2$loca8 = _defaultOptions2$loca8.options) === null || _defaultOptions2$loca8 === void 0 ? void 0 : _defaultOptions2$loca8.weekStartsOn) !== null && _ref25 !== void 0 ? _ref25 : 0;
  var currentDayOfMonth = getDate(toDate(date, options === null || options === void 0 ? void 0 : options.in));
  if (isNaN(currentDayOfMonth))
  return NaN;
  var startWeekDay = getDay(startOfMonth(date, options));
  var lastDayOfFirstWeek = weekStartsOn - startWeekDay;
  if (lastDayOfFirstWeek <= 0)
  lastDayOfFirstWeek += 7;
  var remainingDaysAfterFirstWeek = currentDayOfMonth - lastDayOfFirstWeek;
  return Math.ceil(remainingDaysAfterFirstWeek / 7) + 1;
}

// dist/fp/getWeekOfMonth.js
var getWeekOfMonth2 = convertToFP(getWeekOfMonth, 1);
// dist/fp/getWeekOfMonthWithOptions.js
var _getWeekOfMonthWithOptions = convertToFP(getWeekOfMonth, 2);
// dist/fp/getWeekWithOptions.js
var _getWeekWithOptions = convertToFP(getWeek, 2);
// dist/fp/getWeekYear.js
var getWeekYear2 = convertToFP(getWeekYear, 1);
// dist/fp/getWeekYearWithOptions.js
var _getWeekYearWithOptions = convertToFP(getWeekYear, 2);
// dist/lastDayOfMonth.js
function lastDayOfMonth(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var month = _date.getMonth();
  _date.setFullYear(_date.getFullYear(), month + 1, 0);
  _date.setHours(0, 0, 0, 0);
  return toDate(_date, options === null || options === void 0 ? void 0 : options.in);
}

// dist/getWeeksInMonth.js
function getWeeksInMonth(date, options) {
  var contextDate = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  return differenceInCalendarWeeks(lastDayOfMonth(contextDate, options), startOfMonth(contextDate, options), options) + 1;
}

// dist/fp/getWeeksInMonth.js
var getWeeksInMonth2 = convertToFP(getWeeksInMonth, 1);
// dist/fp/getWeeksInMonthWithOptions.js
var _getWeeksInMonthWithOptions = convertToFP(getWeeksInMonth, 2);
// dist/getYear.js
function getYear(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getFullYear();
}

// dist/fp/getYear.js
var getYear2 = convertToFP(getYear, 1);
// dist/fp/getYearWithOptions.js
var _getYearWithOptions = convertToFP(getYear, 2);
// dist/hoursToMilliseconds.js
function hoursToMilliseconds(hours) {
  return Math.trunc(hours * millisecondsInHour);
}

// dist/fp/hoursToMilliseconds.js
var hoursToMilliseconds2 = convertToFP(hoursToMilliseconds, 1);
// dist/hoursToMinutes.js
function hoursToMinutes(hours) {
  return Math.trunc(hours * minutesInHour);
}

// dist/fp/hoursToMinutes.js
var hoursToMinutes2 = convertToFP(hoursToMinutes, 1);
// dist/hoursToSeconds.js
function hoursToSeconds(hours) {
  return Math.trunc(hours * secondsInHour);
}

// dist/fp/hoursToSeconds.js
var hoursToSeconds2 = convertToFP(hoursToSeconds, 1);
// dist/interval.js
function interval(start, end, options) {
  var _normalizeDates39 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, start, end),_normalizeDates40 = _slicedToArray(_normalizeDates39, 2),_start = _normalizeDates40[0],_end = _normalizeDates40[1];
  if (isNaN(+_start))
  throw new TypeError("Start date is invalid");
  if (isNaN(+_end))
  throw new TypeError("End date is invalid");
  if (options !== null && options !== void 0 && options.assertPositive && +_start > +_end)
  throw new TypeError("End date must be after start date");
  return { start: _start, end: _end };
}

// dist/fp/interval.js
var interval2 = convertToFP(interval, 2);
// dist/intervalToDuration.js
function intervalToDuration(interval3, options) {
  var _normalizeInterval9 = normalizeInterval(options === null || options === void 0 ? void 0 : options.in, interval3),start = _normalizeInterval9.start,end = _normalizeInterval9.end;
  var duration = {};
  var years = differenceInYears(end, start);
  if (years)
  duration.years = years;
  var remainingMonths = add(start, { years: duration.years });
  var months2 = differenceInMonths(end, remainingMonths);
  if (months2)
  duration.months = months2;
  var remainingDays = add(remainingMonths, { months: duration.months });
  var days2 = differenceInDays(end, remainingDays);
  if (days2)
  duration.days = days2;
  var remainingHours = add(remainingDays, { days: duration.days });
  var hours = differenceInHours(end, remainingHours);
  if (hours)
  duration.hours = hours;
  var remainingMinutes = add(remainingHours, { hours: duration.hours });
  var minutes = differenceInMinutes(end, remainingMinutes);
  if (minutes)
  duration.minutes = minutes;
  var remainingSeconds = add(remainingMinutes, { minutes: duration.minutes });
  var seconds = differenceInSeconds(end, remainingSeconds);
  if (seconds)
  duration.seconds = seconds;
  return duration;
}

// dist/fp/intervalToDuration.js
var intervalToDuration2 = convertToFP(intervalToDuration, 1);
// dist/fp/intervalToDurationWithOptions.js
var _intervalToDurationWithOptions = convertToFP(intervalToDuration, 2);
// dist/fp/intervalWithOptions.js
var _intervalWithOptions = convertToFP(interval, 3);
// dist/intlFormat.js
function intlFormat(date, formatOrLocale, localeOptions) {var _localeOptions;
  var formatOptions;
  if (isFormatOptions(formatOrLocale)) {
    formatOptions = formatOrLocale;
  } else {
    localeOptions = formatOrLocale;
  }
  return new Intl.DateTimeFormat((_localeOptions = localeOptions) === null || _localeOptions === void 0 ? void 0 : _localeOptions.locale, formatOptions).format(toDate(date));
}
function isFormatOptions(opts) {
  return opts !== undefined && !("locale" in opts);
}

// dist/fp/intlFormat.js
var intlFormat2 = convertToFP(intlFormat, 3);
// dist/intlFormatDistance.js
function intlFormatDistance(laterDate, earlierDate, options) {
  var value = 0;
  var unit;
  var _normalizeDates41 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates42 = _slicedToArray(_normalizeDates41, 2),laterDate_ = _normalizeDates42[0],earlierDate_ = _normalizeDates42[1];
  if (!(options !== null && options !== void 0 && options.unit)) {
    var diffInSeconds = differenceInSeconds(laterDate_, earlierDate_);
    if (Math.abs(diffInSeconds) < secondsInMinute) {
      value = differenceInSeconds(laterDate_, earlierDate_);
      unit = "second";
    } else if (Math.abs(diffInSeconds) < secondsInHour) {
      value = differenceInMinutes(laterDate_, earlierDate_);
      unit = "minute";
    } else if (Math.abs(diffInSeconds) < secondsInDay && Math.abs(differenceInCalendarDays(laterDate_, earlierDate_)) < 1) {
      value = differenceInHours(laterDate_, earlierDate_);
      unit = "hour";
    } else if (Math.abs(diffInSeconds) < secondsInWeek && (value = differenceInCalendarDays(laterDate_, earlierDate_)) && Math.abs(value) < 7) {
      unit = "day";
    } else if (Math.abs(diffInSeconds) < secondsInMonth) {
      value = differenceInCalendarWeeks(laterDate_, earlierDate_);
      unit = "week";
    } else if (Math.abs(diffInSeconds) < secondsInQuarter) {
      value = differenceInCalendarMonths(laterDate_, earlierDate_);
      unit = "month";
    } else if (Math.abs(diffInSeconds) < secondsInYear) {
      if (differenceInCalendarQuarters(laterDate_, earlierDate_) < 4) {
        value = differenceInCalendarQuarters(laterDate_, earlierDate_);
        unit = "quarter";
      } else {
        value = differenceInCalendarYears(laterDate_, earlierDate_);
        unit = "year";
      }
    } else {
      value = differenceInCalendarYears(laterDate_, earlierDate_);
      unit = "year";
    }
  } else {
    unit = options === null || options === void 0 ? void 0 : options.unit;
    if (unit === "second") {
      value = differenceInSeconds(laterDate_, earlierDate_);
    } else if (unit === "minute") {
      value = differenceInMinutes(laterDate_, earlierDate_);
    } else if (unit === "hour") {
      value = differenceInHours(laterDate_, earlierDate_);
    } else if (unit === "day") {
      value = differenceInCalendarDays(laterDate_, earlierDate_);
    } else if (unit === "week") {
      value = differenceInCalendarWeeks(laterDate_, earlierDate_);
    } else if (unit === "month") {
      value = differenceInCalendarMonths(laterDate_, earlierDate_);
    } else if (unit === "quarter") {
      value = differenceInCalendarQuarters(laterDate_, earlierDate_);
    } else if (unit === "year") {
      value = differenceInCalendarYears(laterDate_, earlierDate_);
    }
  }
  var rtf = new Intl.RelativeTimeFormat(options === null || options === void 0 ? void 0 : options.locale, _objectSpread({
    numeric: "auto" },
  options)
  );
  return rtf.format(value, unit);
}

// dist/fp/intlFormatDistance.js
var intlFormatDistance2 = convertToFP(intlFormatDistance, 2);
// dist/fp/intlFormatDistanceWithOptions.js
var _intlFormatDistanceWithOptions = convertToFP(intlFormatDistance, 3);
// dist/isAfter.js
function isAfter(date, dateToCompare) {
  return +toDate(date) > +toDate(dateToCompare);
}

// dist/fp/isAfter.js
var isAfter2 = convertToFP(isAfter, 2);
// dist/isBefore.js
function isBefore(date, dateToCompare) {
  return +toDate(date) < +toDate(dateToCompare);
}

// dist/fp/isBefore.js
var isBefore2 = convertToFP(isBefore, 2);
// dist/fp/isDate.js
var isDate2 = convertToFP(isDate, 1);
// dist/isEqual.js
function isEqual(leftDate, rightDate) {
  return +toDate(leftDate) === +toDate(rightDate);
}

// dist/fp/isEqual.js
var isEqual2 = convertToFP(isEqual, 2);
// dist/isExists.js
function isExists(year, month, day) {
  var date = new Date(year, month, day);
  return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day;
}

// dist/fp/isExists.js
var isExists2 = convertToFP(isExists, 3);
// dist/isFirstDayOfMonth.js
function isFirstDayOfMonth(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDate() === 1;
}

// dist/fp/isFirstDayOfMonth.js
var isFirstDayOfMonth2 = convertToFP(isFirstDayOfMonth, 1);
// dist/fp/isFirstDayOfMonthWithOptions.js
var _isFirstDayOfMonthWithOptions = convertToFP(isFirstDayOfMonth, 2);
// dist/isFriday.js
function isFriday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 5;
}

// dist/fp/isFriday.js
var isFriday2 = convertToFP(isFriday, 1);
// dist/fp/isFridayWithOptions.js
var _isFridayWithOptions = convertToFP(isFriday, 2);
// dist/fp/isLastDayOfMonth.js
var isLastDayOfMonth2 = convertToFP(isLastDayOfMonth, 1);
// dist/fp/isLastDayOfMonthWithOptions.js
var _isLastDayOfMonthWithOptions = convertToFP(isLastDayOfMonth, 2);
// dist/fp/isLeapYear.js
var isLeapYear2 = convertToFP(isLeapYear, 1);
// dist/fp/isLeapYearWithOptions.js
var _isLeapYearWithOptions = convertToFP(isLeapYear, 2);
// dist/getDefaultOptions.js
function getDefaultOptions2() {
  return Object.assign({}, getDefaultOptions());
}

// dist/transpose.js
function transpose(date, constructor) {
  var date_ = isConstructor(constructor) ? new constructor(0) : constructFrom(constructor, 0);
  date_.setFullYear(date.getFullYear(), date.getMonth(), date.getDate());
  date_.setHours(date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
  return date_;
}
function isConstructor(constructor) {var _constructor$prototyp;
  return typeof constructor === "function" && ((_constructor$prototyp = constructor.prototype) === null || _constructor$prototyp === void 0 ? void 0 : _constructor$prototyp.constructor) === constructor;
}

// dist/parse/_lib/Setter.js
var TIMEZONE_UNIT_PRIORITY = 10;var

Setter = /*#__PURE__*/function () {function Setter() {_classCallCheck(this, Setter);_defineProperty(this, "subPriority",
    0);}return _createClass(Setter, [{ key: "validate", value:
    function validate(_utcDate, _options) {
      return true;
    } }]);}();var


ValueSetter = /*#__PURE__*/function (_Setter2) {
  function ValueSetter(value, validateValue, setValue, priority, subPriority) {var _this;_classCallCheck(this, ValueSetter);
    _this = _callSuper(this, ValueSetter);
    _this.value = value;
    _this.validateValue = validateValue;
    _this.setValue = setValue;
    _this.priority = priority;
    if (subPriority) {
      _this.subPriority = subPriority;
    }return _this;
  }_inherits(ValueSetter, _Setter2);return _createClass(ValueSetter, [{ key: "validate", value:
    function validate(date, options) {
      return this.validateValue(date, this.value, options);
    } }, { key: "set", value:
    function set(date, flags, options) {
      return this.setValue(date, flags, this.value, options);
    } }]);}(Setter);var


DateTimezoneSetter = /*#__PURE__*/function (_Setter3) {


  function DateTimezoneSetter(context, reference) {var _this2;_classCallCheck(this, DateTimezoneSetter);
    _this2 = _callSuper(this, DateTimezoneSetter);_defineProperty(_this2, "priority", TIMEZONE_UNIT_PRIORITY);_defineProperty(_this2, "subPriority", -1);
    _this2.context = context || function (date) {return constructFrom(reference, date);};return _this2;
  }_inherits(DateTimezoneSetter, _Setter3);return _createClass(DateTimezoneSetter, [{ key: "set", value:
    function set(date, flags) {
      if (flags.timestampIsSet)
      return date;
      return constructFrom(date, transpose(date, this.context));
    } }]);}(Setter);


// dist/parse/_lib/Parser.js
var Parser = /*#__PURE__*/function () {function Parser() {_classCallCheck(this, Parser);}return _createClass(Parser, [{ key: "run", value:
    function run(dateString, token, match2, options) {
      var result = this.parse(dateString, token, match2, options);
      if (!result) {
        return null;
      }
      return {
        setter: new ValueSetter(result.value, this.validate, this.set, this.priority, this.subPriority),
        rest: result.rest
      };
    } }, { key: "validate", value:
    function validate(_utcDate, _value, _options) {
      return true;
    } }]);}();


// dist/parse/_lib/parsers/EraParser.js
var EraParser = /*#__PURE__*/function (_Parser) {function EraParser() {var _this3;_classCallCheck(this, EraParser);for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {args[_key3] = arguments[_key3];}_this3 = _callSuper(this, EraParser, [].concat(args));_defineProperty(_this3, "priority",
    140);_defineProperty(_this3, "incompatibleTokens",



















    ["R", "u", "t", "T"]);return _this3;}_inherits(EraParser, _Parser);return _createClass(EraParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "G":case "GG":case "GGG":return match2.era(dateString, { width: "abbreviated" }) || match2.era(dateString, { width: "narrow" });case "GGGGG":return match2.era(dateString, { width: "narrow" });case "GGGG":default:return match2.era(dateString, { width: "wide" }) || match2.era(dateString, { width: "abbreviated" }) || match2.era(dateString, { width: "narrow" });}} }, { key: "set", value: function set(date, flags, value) {flags.era = value;date.setFullYear(value, 0, 1);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/constants.js
var numericPatterns = {
  month: /^(1[0-2]|0?\d)/,
  date: /^(3[0-1]|[0-2]?\d)/,
  dayOfYear: /^(36[0-6]|3[0-5]\d|[0-2]?\d?\d)/,
  week: /^(5[0-3]|[0-4]?\d)/,
  hour23h: /^(2[0-3]|[0-1]?\d)/,
  hour24h: /^(2[0-4]|[0-1]?\d)/,
  hour11h: /^(1[0-1]|0?\d)/,
  hour12h: /^(1[0-2]|0?\d)/,
  minute: /^[0-5]?\d/,
  second: /^[0-5]?\d/,
  singleDigit: /^\d/,
  twoDigits: /^\d{1,2}/,
  threeDigits: /^\d{1,3}/,
  fourDigits: /^\d{1,4}/,
  anyDigitsSigned: /^-?\d+/,
  singleDigitSigned: /^-?\d/,
  twoDigitsSigned: /^-?\d{1,2}/,
  threeDigitsSigned: /^-?\d{1,3}/,
  fourDigitsSigned: /^-?\d{1,4}/
};
var timezonePatterns = {
  basicOptionalMinutes: /^([+-])(\d{2})(\d{2})?|Z/,
  basic: /^([+-])(\d{2})(\d{2})|Z/,
  basicOptionalSeconds: /^([+-])(\d{2})(\d{2})((\d{2}))?|Z/,
  extended: /^([+-])(\d{2}):(\d{2})|Z/,
  extendedOptionalSeconds: /^([+-])(\d{2}):(\d{2})(:(\d{2}))?|Z/
};

// dist/parse/_lib/utils.js
function mapValue(parseFnResult, mapFn) {
  if (!parseFnResult) {
    return parseFnResult;
  }
  return {
    value: mapFn(parseFnResult.value),
    rest: parseFnResult.rest
  };
}
function parseNumericPattern(pattern, dateString) {
  var matchResult = dateString.match(pattern);
  if (!matchResult) {
    return null;
  }
  return {
    value: parseInt(matchResult[0], 10),
    rest: dateString.slice(matchResult[0].length)
  };
}
function parseTimezonePattern(pattern, dateString) {
  var matchResult = dateString.match(pattern);
  if (!matchResult) {
    return null;
  }
  if (matchResult[0] === "Z") {
    return {
      value: 0,
      rest: dateString.slice(1)
    };
  }
  var sign = matchResult[1] === "+" ? 1 : -1;
  var hours = matchResult[2] ? parseInt(matchResult[2], 10) : 0;
  var minutes = matchResult[3] ? parseInt(matchResult[3], 10) : 0;
  var seconds = matchResult[5] ? parseInt(matchResult[5], 10) : 0;
  return {
    value: sign * (hours * millisecondsInHour + minutes * millisecondsInMinute + seconds * millisecondsInSecond),
    rest: dateString.slice(matchResult[0].length)
  };
}
function parseAnyDigitsSigned(dateString) {
  return parseNumericPattern(numericPatterns.anyDigitsSigned, dateString);
}
function parseNDigits(n, dateString) {
  switch (n) {
    case 1:
      return parseNumericPattern(numericPatterns.singleDigit, dateString);
    case 2:
      return parseNumericPattern(numericPatterns.twoDigits, dateString);
    case 3:
      return parseNumericPattern(numericPatterns.threeDigits, dateString);
    case 4:
      return parseNumericPattern(numericPatterns.fourDigits, dateString);
    default:
      return parseNumericPattern(new RegExp("^\\d{1," + n + "}"), dateString);
  }
}
function parseNDigitsSigned(n, dateString) {
  switch (n) {
    case 1:
      return parseNumericPattern(numericPatterns.singleDigitSigned, dateString);
    case 2:
      return parseNumericPattern(numericPatterns.twoDigitsSigned, dateString);
    case 3:
      return parseNumericPattern(numericPatterns.threeDigitsSigned, dateString);
    case 4:
      return parseNumericPattern(numericPatterns.fourDigitsSigned, dateString);
    default:
      return parseNumericPattern(new RegExp("^-?\\d{1," + n + "}"), dateString);
  }
}
function dayPeriodEnumToHours(dayPeriod) {
  switch (dayPeriod) {
    case "morning":
      return 4;
    case "evening":
      return 17;
    case "pm":
    case "noon":
    case "afternoon":
      return 12;
    case "am":
    case "midnight":
    case "night":
    default:
      return 0;
  }
}
function normalizeTwoDigitYear(twoDigitYear, currentYear) {
  var isCommonEra = currentYear > 0;
  var absCurrentYear = isCommonEra ? currentYear : 1 - currentYear;
  var result;
  if (absCurrentYear <= 50) {
    result = twoDigitYear || 100;
  } else {
    var rangeEnd = absCurrentYear + 50;
    var rangeEndCentury = Math.trunc(rangeEnd / 100) * 100;
    var isPreviousCentury = twoDigitYear >= rangeEnd % 100;
    result = twoDigitYear + rangeEndCentury - (isPreviousCentury ? 100 : 0);
  }
  return isCommonEra ? result : 1 - result;
}
function isLeapYearIndex(year) {
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}

// dist/parse/_lib/parsers/YearParser.js
var YearParser = /*#__PURE__*/function (_Parser2) {function YearParser() {var _this4;_classCallCheck(this, YearParser);for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {args[_key4] = arguments[_key4];}_this4 = _callSuper(this, YearParser, [].concat(args));_defineProperty(_this4, "priority",
    130);_defineProperty(_this4, "incompatibleTokens",
    ["Y", "R", "u", "w", "I", "i", "e", "c", "t", "T"]);return _this4;}_inherits(YearParser, _Parser2);return _createClass(YearParser, [{ key: "parse", value:
    function parse(dateString, token, match2) {
      var valueCallback = function valueCallback(year) {return {
          year: year,
          isTwoDigitYear: token === "yy"
        };};
      switch (token) {
        case "y":
          return mapValue(parseNDigits(4, dateString), valueCallback);
        case "yo":
          return mapValue(match2.ordinalNumber(dateString, {
            unit: "year"
          }), valueCallback);
        default:
          return mapValue(parseNDigits(token.length, dateString), valueCallback);
      }
    } }, { key: "validate", value:
    function validate(_date, value) {
      return value.isTwoDigitYear || value.year > 0;
    } }, { key: "set", value:
    function set(date, flags, value) {
      var currentYear = date.getFullYear();
      if (value.isTwoDigitYear) {
        var normalizedTwoDigitYear = normalizeTwoDigitYear(value.year, currentYear);
        date.setFullYear(normalizedTwoDigitYear, 0, 1);
        date.setHours(0, 0, 0, 0);
        return date;
      }
      var year = !("era" in flags) || flags.era === 1 ? value.year : 1 - value.year;
      date.setFullYear(year, 0, 1);
      date.setHours(0, 0, 0, 0);
      return date;
    } }]);}(Parser);


// dist/parse/_lib/parsers/LocalWeekYearParser.js
var LocalWeekYearParser = /*#__PURE__*/function (_Parser3) {function LocalWeekYearParser() {var _this5;_classCallCheck(this, LocalWeekYearParser);for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {args[_key5] = arguments[_key5];}_this5 = _callSuper(this, LocalWeekYearParser, [].concat(args));_defineProperty(_this5, "priority",
    130);_defineProperty(_this5, "incompatibleTokens",
































    [
    "y",
    "R",
    "u",
    "Q",
    "q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "i",
    "t",
    "T"]);return _this5;}_inherits(LocalWeekYearParser, _Parser3);return _createClass(LocalWeekYearParser, [{ key: "parse", value: function parse(dateString, token, match2) {var valueCallback = function valueCallback(year) {return { year: year, isTwoDigitYear: token === "YY" };};switch (token) {case "Y":return mapValue(parseNDigits(4, dateString), valueCallback);case "Yo":return mapValue(match2.ordinalNumber(dateString, { unit: "year" }), valueCallback);default:return mapValue(parseNDigits(token.length, dateString), valueCallback);}} }, { key: "validate", value: function validate(_date, value) {return value.isTwoDigitYear || value.year > 0;} }, { key: "set", value: function set(date, flags, value, options) {var currentYear = getWeekYear(date, options);if (value.isTwoDigitYear) {var normalizedTwoDigitYear = normalizeTwoDigitYear(value.year, currentYear);date.setFullYear(normalizedTwoDigitYear, 0, options.firstWeekContainsDate);date.setHours(0, 0, 0, 0);return startOfWeek(date, options);}var year = !("era" in flags) || flags.era === 1 ? value.year : 1 - value.year;date.setFullYear(year, 0, options.firstWeekContainsDate);date.setHours(0, 0, 0, 0);return startOfWeek(date, options);} }]);}(Parser);



// dist/parse/_lib/parsers/ISOWeekYearParser.js
var ISOWeekYearParser = /*#__PURE__*/function (_Parser4) {function ISOWeekYearParser() {var _this6;_classCallCheck(this, ISOWeekYearParser);for (var _len6 = arguments.length, args = new Array(_len6), _key6 = 0; _key6 < _len6; _key6++) {args[_key6] = arguments[_key6];}_this6 = _callSuper(this, ISOWeekYearParser, [].concat(args));_defineProperty(_this6, "priority",
    130);_defineProperty(_this6, "incompatibleTokens",












    [
    "G",
    "y",
    "Y",
    "u",
    "Q",
    "q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "e",
    "c",
    "t",
    "T"]);return _this6;}_inherits(ISOWeekYearParser, _Parser4);return _createClass(ISOWeekYearParser, [{ key: "parse", value: function parse(dateString, token) {if (token === "R") {return parseNDigitsSigned(4, dateString);}return parseNDigitsSigned(token.length, dateString);} }, { key: "set", value: function set(date, _flags, value) {var firstWeekOfYear = constructFrom(date, 0);firstWeekOfYear.setFullYear(value, 0, 4);firstWeekOfYear.setHours(0, 0, 0, 0);return startOfISOWeek(firstWeekOfYear);} }]);}(Parser);



// dist/parse/_lib/parsers/ExtendedYearParser.js
var ExtendedYearParser = /*#__PURE__*/function (_Parser5) {function ExtendedYearParser() {var _this7;_classCallCheck(this, ExtendedYearParser);for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {args[_key7] = arguments[_key7];}_this7 = _callSuper(this, ExtendedYearParser, [].concat(args));_defineProperty(_this7, "priority",
    130);_defineProperty(_this7, "incompatibleTokens",











    ["G", "y", "Y", "R", "w", "I", "i", "e", "c", "t", "T"]);return _this7;}_inherits(ExtendedYearParser, _Parser5);return _createClass(ExtendedYearParser, [{ key: "parse", value: function parse(dateString, token) {if (token === "u") {return parseNDigitsSigned(4, dateString);}return parseNDigitsSigned(token.length, dateString);} }, { key: "set", value: function set(date, _flags, value) {date.setFullYear(value, 0, 1);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/QuarterParser.js
var QuarterParser = /*#__PURE__*/function (_Parser6) {function QuarterParser() {var _this8;_classCallCheck(this, QuarterParser);for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {args[_key8] = arguments[_key8];}_this8 = _callSuper(this, QuarterParser, [].concat(args));_defineProperty(_this8, "priority",
    120);_defineProperty(_this8, "incompatibleTokens",










































    [
    "Y",
    "R",
    "q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"]);return _this8;}_inherits(QuarterParser, _Parser6);return _createClass(QuarterParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "Q":case "QQ":return parseNDigits(token.length, dateString);case "Qo":return match2.ordinalNumber(dateString, { unit: "quarter" });case "QQQ":return match2.quarter(dateString, { width: "abbreviated", context: "formatting" }) || match2.quarter(dateString, { width: "narrow", context: "formatting" });case "QQQQQ":return match2.quarter(dateString, { width: "narrow", context: "formatting" });case "QQQQ":default:return match2.quarter(dateString, { width: "wide", context: "formatting" }) || match2.quarter(dateString, { width: "abbreviated", context: "formatting" }) || match2.quarter(dateString, { width: "narrow", context: "formatting" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 4;} }, { key: "set", value: function set(date, _flags, value) {date.setMonth((value - 1) * 3, 1);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/parse/_lib/parsers/StandAloneQuarterParser.js
var StandAloneQuarterParser = /*#__PURE__*/function (_Parser7) {function StandAloneQuarterParser() {var _this9;_classCallCheck(this, StandAloneQuarterParser);for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {args[_key9] = arguments[_key9];}_this9 = _callSuper(this, StandAloneQuarterParser, [].concat(args));_defineProperty(_this9, "priority",
    120);_defineProperty(_this9, "incompatibleTokens",










































    [
    "Y",
    "R",
    "Q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"]);return _this9;}_inherits(StandAloneQuarterParser, _Parser7);return _createClass(StandAloneQuarterParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "q":case "qq":return parseNDigits(token.length, dateString);case "qo":return match2.ordinalNumber(dateString, { unit: "quarter" });case "qqq":return match2.quarter(dateString, { width: "abbreviated", context: "standalone" }) || match2.quarter(dateString, { width: "narrow", context: "standalone" });case "qqqqq":return match2.quarter(dateString, { width: "narrow", context: "standalone" });case "qqqq":default:return match2.quarter(dateString, { width: "wide", context: "standalone" }) || match2.quarter(dateString, { width: "abbreviated", context: "standalone" }) || match2.quarter(dateString, { width: "narrow", context: "standalone" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 4;} }, { key: "set", value: function set(date, _flags, value) {date.setMonth((value - 1) * 3, 1);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/parse/_lib/parsers/MonthParser.js
var MonthParser = /*#__PURE__*/function (_Parser8) {function MonthParser() {var _this0;_classCallCheck(this, MonthParser);for (var _len0 = arguments.length, args = new Array(_len0), _key0 = 0; _key0 < _len0; _key0++) {args[_key0] = arguments[_key0];}_this0 = _callSuper(this, MonthParser, [].concat(args));_defineProperty(_this0, "incompatibleTokens",
    [
    "Y",
    "R",
    "q",
    "Q",
    "L",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"]);_defineProperty(_this0, "priority",

    110);return _this0;}_inherits(MonthParser, _Parser8);return _createClass(MonthParser, [{ key: "parse", value:
    function parse(dateString, token, match2) {
      var valueCallback = function valueCallback(value) {return value - 1;};
      switch (token) {
        case "M":
          return mapValue(parseNumericPattern(numericPatterns.month, dateString), valueCallback);
        case "MM":
          return mapValue(parseNDigits(2, dateString), valueCallback);
        case "Mo":
          return mapValue(match2.ordinalNumber(dateString, {
            unit: "month"
          }), valueCallback);
        case "MMM":
          return match2.month(dateString, {
            width: "abbreviated",
            context: "formatting"
          }) || match2.month(dateString, { width: "narrow", context: "formatting" });
        case "MMMMM":
          return match2.month(dateString, {
            width: "narrow",
            context: "formatting"
          });
        case "MMMM":
        default:
          return match2.month(dateString, { width: "wide", context: "formatting" }) || match2.month(dateString, {
            width: "abbreviated",
            context: "formatting"
          }) || match2.month(dateString, { width: "narrow", context: "formatting" });
      }
    } }, { key: "validate", value:
    function validate(_date, value) {
      return value >= 0 && value <= 11;
    } }, { key: "set", value:
    function set(date, _flags, value) {
      date.setMonth(value, 1);
      date.setHours(0, 0, 0, 0);
      return date;
    } }]);}(Parser);


// dist/parse/_lib/parsers/StandAloneMonthParser.js
var StandAloneMonthParser = /*#__PURE__*/function (_Parser9) {function StandAloneMonthParser() {var _this1;_classCallCheck(this, StandAloneMonthParser);for (var _len1 = arguments.length, args = new Array(_len1), _key1 = 0; _key1 < _len1; _key1++) {args[_key1] = arguments[_key1];}_this1 = _callSuper(this, StandAloneMonthParser, [].concat(args));_defineProperty(_this1, "priority",
    110);_defineProperty(_this1, "incompatibleTokens",





































    [
    "Y",
    "R",
    "q",
    "Q",
    "M",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"]);return _this1;}_inherits(StandAloneMonthParser, _Parser9);return _createClass(StandAloneMonthParser, [{ key: "parse", value: function parse(dateString, token, match2) {var valueCallback = function valueCallback(value) {return value - 1;};switch (token) {case "L":return mapValue(parseNumericPattern(numericPatterns.month, dateString), valueCallback);case "LL":return mapValue(parseNDigits(2, dateString), valueCallback);case "Lo":return mapValue(match2.ordinalNumber(dateString, { unit: "month" }), valueCallback);case "LLL":return match2.month(dateString, { width: "abbreviated", context: "standalone" }) || match2.month(dateString, { width: "narrow", context: "standalone" });case "LLLLL":return match2.month(dateString, { width: "narrow", context: "standalone" });case "LLLL":default:return match2.month(dateString, { width: "wide", context: "standalone" }) || match2.month(dateString, { width: "abbreviated", context: "standalone" }) || match2.month(dateString, { width: "narrow", context: "standalone" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 11;} }, { key: "set", value: function set(date, _flags, value) {date.setMonth(value, 1);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/setWeek.js
function setWeek(date, week, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = getWeek(date_, options) - week;
  date_.setDate(date_.getDate() - diff * 7);
  return toDate(date_, options === null || options === void 0 ? void 0 : options.in);
}

// dist/parse/_lib/parsers/LocalWeekParser.js
var LocalWeekParser = /*#__PURE__*/function (_Parser0) {function LocalWeekParser() {var _this10;_classCallCheck(this, LocalWeekParser);for (var _len10 = arguments.length, args = new Array(_len10), _key10 = 0; _key10 < _len10; _key10++) {args[_key10] = arguments[_key10];}_this10 = _callSuper(this, LocalWeekParser, [].concat(args));_defineProperty(_this10, "priority",
    100);_defineProperty(_this10, "incompatibleTokens",
















    [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "i",
    "t",
    "T"]);return _this10;}_inherits(LocalWeekParser, _Parser0);return _createClass(LocalWeekParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "w":return parseNumericPattern(numericPatterns.week, dateString);case "wo":return match2.ordinalNumber(dateString, { unit: "week" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 53;} }, { key: "set", value: function set(date, _flags, value, options) {return startOfWeek(setWeek(date, value, options), options);} }]);}(Parser);



// dist/setISOWeek.js
function setISOWeek(date, week, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var diff = getISOWeek(_date, options) - week;
  _date.setDate(_date.getDate() - diff * 7);
  return _date;
}

// dist/parse/_lib/parsers/ISOWeekParser.js
var ISOWeekParser = /*#__PURE__*/function (_Parser1) {function ISOWeekParser() {var _this11;_classCallCheck(this, ISOWeekParser);for (var _len11 = arguments.length, args = new Array(_len11), _key11 = 0; _key11 < _len11; _key11++) {args[_key11] = arguments[_key11];}_this11 = _callSuper(this, ISOWeekParser, [].concat(args));_defineProperty(_this11, "priority",
    100);_defineProperty(_this11, "incompatibleTokens",
















    [
    "y",
    "Y",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "e",
    "c",
    "t",
    "T"]);return _this11;}_inherits(ISOWeekParser, _Parser1);return _createClass(ISOWeekParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "I":return parseNumericPattern(numericPatterns.week, dateString);case "Io":return match2.ordinalNumber(dateString, { unit: "week" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 53;} }, { key: "set", value: function set(date, _flags, value) {return startOfISOWeek(setISOWeek(date, value));} }]);}(Parser);



// dist/parse/_lib/parsers/DateParser.js
var DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
var DAYS_IN_MONTH_LEAP_YEAR = [
31,
29,
31,
30,
31,
30,
31,
31,
30,
31,
30,
31];var


DateParser = /*#__PURE__*/function (_Parser10) {function DateParser() {var _this12;_classCallCheck(this, DateParser);for (var _len12 = arguments.length, args = new Array(_len12), _key12 = 0; _key12 < _len12; _key12++) {args[_key12] = arguments[_key12];}_this12 = _callSuper(this, DateParser, [].concat(args));_defineProperty(_this12, "priority",
    90);_defineProperty(_this12, "subPriority",
    1);_defineProperty(_this12, "incompatibleTokens",

























    [
    "Y",
    "R",
    "q",
    "Q",
    "w",
    "I",
    "D",
    "i",
    "e",
    "c",
    "t",
    "T"]);return _this12;}_inherits(DateParser, _Parser10);return _createClass(DateParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "d":return parseNumericPattern(numericPatterns.date, dateString);case "do":return match2.ordinalNumber(dateString, { unit: "date" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(date, value) {var year = date.getFullYear();var isLeapYear3 = isLeapYearIndex(year);var month = date.getMonth();if (isLeapYear3) {return value >= 1 && value <= DAYS_IN_MONTH_LEAP_YEAR[month];} else {return value >= 1 && value <= DAYS_IN_MONTH[month];}} }, { key: "set", value: function set(date, _flags, value) {date.setDate(value);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/parse/_lib/parsers/DayOfYearParser.js
var DayOfYearParser = /*#__PURE__*/function (_Parser11) {function DayOfYearParser() {var _this13;_classCallCheck(this, DayOfYearParser);for (var _len13 = arguments.length, args = new Array(_len13), _key13 = 0; _key13 < _len13; _key13++) {args[_key13] = arguments[_key13];}_this13 = _callSuper(this, DayOfYearParser, [].concat(args));_defineProperty(_this13, "priority",
    90);_defineProperty(_this13, "subpriority",
    1);_defineProperty(_this13, "incompatibleTokens",

























    [
    "Y",
    "R",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "I",
    "d",
    "E",
    "i",
    "e",
    "c",
    "t",
    "T"]);return _this13;}_inherits(DayOfYearParser, _Parser11);return _createClass(DayOfYearParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "D":case "DD":return parseNumericPattern(numericPatterns.dayOfYear, dateString);case "Do":return match2.ordinalNumber(dateString, { unit: "date" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(date, value) {var year = date.getFullYear();var isLeapYear3 = isLeapYearIndex(year);if (isLeapYear3) {return value >= 1 && value <= 366;} else {return value >= 1 && value <= 365;}} }, { key: "set", value: function set(date, _flags, value) {date.setMonth(0, value);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/setDay.js
function setDay(date, day, options) {var _ref28, _ref29, _ref30, _options$weekStartsOn6, _options$locale12, _defaultOptions2$loca9;
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = (_ref28 = (_ref29 = (_ref30 = (_options$weekStartsOn6 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn6 !== void 0 ? _options$weekStartsOn6 : options === null || options === void 0 || (_options$locale12 = options.locale) === null || _options$locale12 === void 0 || (_options$locale12 = _options$locale12.options) === null || _options$locale12 === void 0 ? void 0 : _options$locale12.weekStartsOn) !== null && _ref30 !== void 0 ? _ref30 : defaultOptions2.weekStartsOn) !== null && _ref29 !== void 0 ? _ref29 : (_defaultOptions2$loca9 = defaultOptions2.locale) === null || _defaultOptions2$loca9 === void 0 || (_defaultOptions2$loca9 = _defaultOptions2$loca9.options) === null || _defaultOptions2$loca9 === void 0 ? void 0 : _defaultOptions2$loca9.weekStartsOn) !== null && _ref28 !== void 0 ? _ref28 : 0;
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var currentDay = date_.getDay();
  var remainder = day % 7;
  var dayIndex = (remainder + 7) % 7;
  var delta = 7 - weekStartsOn;
  var diff = day < 0 || day > 6 ? day - (currentDay + delta) % 7 : (dayIndex + delta) % 7 - (currentDay + delta) % 7;
  return addDays(date_, diff, options);
}

// dist/parse/_lib/parsers/DayParser.js
var DayParser = /*#__PURE__*/function (_Parser12) {function DayParser() {var _this14;_classCallCheck(this, DayParser);for (var _len14 = arguments.length, args = new Array(_len14), _key14 = 0; _key14 < _len14; _key14++) {args[_key14] = arguments[_key14];}_this14 = _callSuper(this, DayParser, [].concat(args));_defineProperty(_this14, "priority",
    90);_defineProperty(_this14, "incompatibleTokens",
































    ["D", "i", "e", "c", "t", "T"]);return _this14;}_inherits(DayParser, _Parser12);return _createClass(DayParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "E":case "EE":case "EEE":return match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });case "EEEEE":return match2.day(dateString, { width: "narrow", context: "formatting" });case "EEEEEE":return match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });case "EEEE":default:return match2.day(dateString, { width: "wide", context: "formatting" }) || match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 6;} }, { key: "set", value: function set(date, _flags, value, options) {date = setDay(date, value, options);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/LocalDayParser.js
var LocalDayParser = /*#__PURE__*/function (_Parser13) {function LocalDayParser() {var _this15;_classCallCheck(this, LocalDayParser);for (var _len15 = arguments.length, args = new Array(_len15), _key15 = 0; _key15 < _len15; _key15++) {args[_key15] = arguments[_key15];}_this15 = _callSuper(this, LocalDayParser, [].concat(args));_defineProperty(_this15, "priority",
    90);_defineProperty(_this15, "incompatibleTokens",









































    [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "E",
    "i",
    "c",
    "t",
    "T"]);return _this15;}_inherits(LocalDayParser, _Parser13);return _createClass(LocalDayParser, [{ key: "parse", value: function parse(dateString, token, match2, options) {var valueCallback = function valueCallback(value) {var wholeWeekDays = Math.floor((value - 1) / 7) * 7;return (value + options.weekStartsOn + 6) % 7 + wholeWeekDays;};switch (token) {case "e":case "ee":return mapValue(parseNDigits(token.length, dateString), valueCallback);case "eo":return mapValue(match2.ordinalNumber(dateString, { unit: "day" }), valueCallback);case "eee":return match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });case "eeeee":return match2.day(dateString, { width: "narrow", context: "formatting" });case "eeeeee":return match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });case "eeee":default:return match2.day(dateString, { width: "wide", context: "formatting" }) || match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 6;} }, { key: "set", value: function set(date, _flags, value, options) {date = setDay(date, value, options);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/parse/_lib/parsers/StandAloneLocalDayParser.js
var StandAloneLocalDayParser = /*#__PURE__*/function (_Parser14) {function StandAloneLocalDayParser() {var _this16;_classCallCheck(this, StandAloneLocalDayParser);for (var _len16 = arguments.length, args = new Array(_len16), _key16 = 0; _key16 < _len16; _key16++) {args[_key16] = arguments[_key16];}_this16 = _callSuper(this, StandAloneLocalDayParser, [].concat(args));_defineProperty(_this16, "priority",
    90);_defineProperty(_this16, "incompatibleTokens",









































    [
    "y",
    "R",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "I",
    "d",
    "D",
    "E",
    "i",
    "e",
    "t",
    "T"]);return _this16;}_inherits(StandAloneLocalDayParser, _Parser14);return _createClass(StandAloneLocalDayParser, [{ key: "parse", value: function parse(dateString, token, match2, options) {var valueCallback = function valueCallback(value) {var wholeWeekDays = Math.floor((value - 1) / 7) * 7;return (value + options.weekStartsOn + 6) % 7 + wholeWeekDays;};switch (token) {case "c":case "cc":return mapValue(parseNDigits(token.length, dateString), valueCallback);case "co":return mapValue(match2.ordinalNumber(dateString, { unit: "day" }), valueCallback);case "ccc":return match2.day(dateString, { width: "abbreviated", context: "standalone" }) || match2.day(dateString, { width: "short", context: "standalone" }) || match2.day(dateString, { width: "narrow", context: "standalone" });case "ccccc":return match2.day(dateString, { width: "narrow", context: "standalone" });case "cccccc":return match2.day(dateString, { width: "short", context: "standalone" }) || match2.day(dateString, { width: "narrow", context: "standalone" });case "cccc":default:return match2.day(dateString, { width: "wide", context: "standalone" }) || match2.day(dateString, { width: "abbreviated", context: "standalone" }) || match2.day(dateString, { width: "short", context: "standalone" }) || match2.day(dateString, { width: "narrow", context: "standalone" });}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 6;} }, { key: "set", value: function set(date, _flags, value, options) {date = setDay(date, value, options);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/setISODay.js
function setISODay(date, day, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var currentDay = getISODay(date_, options);
  var diff = day - currentDay;
  return addDays(date_, diff, options);
}

// dist/parse/_lib/parsers/ISODayParser.js
var ISODayParser = /*#__PURE__*/function (_Parser15) {function ISODayParser() {var _this17;_classCallCheck(this, ISODayParser);for (var _len17 = arguments.length, args = new Array(_len17), _key17 = 0; _key17 < _len17; _key17++) {args[_key17] = arguments[_key17];}_this17 = _callSuper(this, ISODayParser, [].concat(args));_defineProperty(_this17, "priority",
    90);_defineProperty(_this17, "incompatibleTokens",






























































    [
    "y",
    "Y",
    "u",
    "q",
    "Q",
    "M",
    "L",
    "w",
    "d",
    "D",
    "E",
    "e",
    "c",
    "t",
    "T"]);return _this17;}_inherits(ISODayParser, _Parser15);return _createClass(ISODayParser, [{ key: "parse", value: function parse(dateString, token, match2) {var valueCallback = function valueCallback(value) {if (value === 0) {return 7;}return value;};switch (token) {case "i":case "ii":return parseNDigits(token.length, dateString);case "io":return match2.ordinalNumber(dateString, { unit: "day" });case "iii":return mapValue(match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" }), valueCallback);case "iiiii":return mapValue(match2.day(dateString, { width: "narrow", context: "formatting" }), valueCallback);case "iiiiii":return mapValue(match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" }), valueCallback);case "iiii":default:return mapValue(match2.day(dateString, { width: "wide", context: "formatting" }) || match2.day(dateString, { width: "abbreviated", context: "formatting" }) || match2.day(dateString, { width: "short", context: "formatting" }) || match2.day(dateString, { width: "narrow", context: "formatting" }), valueCallback);}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 7;} }, { key: "set", value: function set(date, _flags, value) {date = setISODay(date, value);date.setHours(0, 0, 0, 0);return date;} }]);}(Parser);



// dist/parse/_lib/parsers/AMPMParser.js
var AMPMParser = /*#__PURE__*/function (_Parser16) {function AMPMParser() {var _this18;_classCallCheck(this, AMPMParser);for (var _len18 = arguments.length, args = new Array(_len18), _key18 = 0; _key18 < _len18; _key18++) {args[_key18] = arguments[_key18];}_this18 = _callSuper(this, AMPMParser, [].concat(args));_defineProperty(_this18, "priority",
    80);_defineProperty(_this18, "incompatibleTokens",



































    ["b", "B", "H", "k", "t", "T"]);return _this18;}_inherits(AMPMParser, _Parser16);return _createClass(AMPMParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "a":case "aa":case "aaa":return match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "aaaaa":return match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "aaaa":default:return match2.dayPeriod(dateString, { width: "wide", context: "formatting" }) || match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });}} }, { key: "set", value: function set(date, _flags, value) {date.setHours(dayPeriodEnumToHours(value), 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/AMPMMidnightParser.js
var AMPMMidnightParser = /*#__PURE__*/function (_Parser17) {function AMPMMidnightParser() {var _this19;_classCallCheck(this, AMPMMidnightParser);for (var _len19 = arguments.length, args = new Array(_len19), _key19 = 0; _key19 < _len19; _key19++) {args[_key19] = arguments[_key19];}_this19 = _callSuper(this, AMPMMidnightParser, [].concat(args));_defineProperty(_this19, "priority",
    80);_defineProperty(_this19, "incompatibleTokens",



































    ["a", "B", "H", "k", "t", "T"]);return _this19;}_inherits(AMPMMidnightParser, _Parser17);return _createClass(AMPMMidnightParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "b":case "bb":case "bbb":return match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "bbbbb":return match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "bbbb":default:return match2.dayPeriod(dateString, { width: "wide", context: "formatting" }) || match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });}} }, { key: "set", value: function set(date, _flags, value) {date.setHours(dayPeriodEnumToHours(value), 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/DayPeriodParser.js
var DayPeriodParser = /*#__PURE__*/function (_Parser18) {function DayPeriodParser() {var _this20;_classCallCheck(this, DayPeriodParser);for (var _len20 = arguments.length, args = new Array(_len20), _key20 = 0; _key20 < _len20; _key20++) {args[_key20] = arguments[_key20];}_this20 = _callSuper(this, DayPeriodParser, [].concat(args));_defineProperty(_this20, "priority",
    80);_defineProperty(_this20, "incompatibleTokens",



































    ["a", "b", "t", "T"]);return _this20;}_inherits(DayPeriodParser, _Parser18);return _createClass(DayPeriodParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "B":case "BB":case "BBB":return match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "BBBBB":return match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });case "BBBB":default:return match2.dayPeriod(dateString, { width: "wide", context: "formatting" }) || match2.dayPeriod(dateString, { width: "abbreviated", context: "formatting" }) || match2.dayPeriod(dateString, { width: "narrow", context: "formatting" });}} }, { key: "set", value: function set(date, _flags, value) {date.setHours(dayPeriodEnumToHours(value), 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/Hour1to12Parser.js
var Hour1to12Parser = /*#__PURE__*/function (_Parser19) {function Hour1to12Parser() {var _this21;_classCallCheck(this, Hour1to12Parser);for (var _len21 = arguments.length, args = new Array(_len21), _key21 = 0; _key21 < _len21; _key21++) {args[_key21] = arguments[_key21];}_this21 = _callSuper(this, Hour1to12Parser, [].concat(args));_defineProperty(_this21, "priority",
    70);_defineProperty(_this21, "incompatibleTokens",
























    ["H", "K", "k", "t", "T"]);return _this21;}_inherits(Hour1to12Parser, _Parser19);return _createClass(Hour1to12Parser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "h":return parseNumericPattern(numericPatterns.hour12h, dateString);case "ho":return match2.ordinalNumber(dateString, { unit: "hour" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 12;} }, { key: "set", value: function set(date, _flags, value) {var isPM = date.getHours() >= 12;if (isPM && value < 12) {date.setHours(value + 12, 0, 0, 0);} else if (!isPM && value === 12) {date.setHours(0, 0, 0, 0);} else {date.setHours(value, 0, 0, 0);}return date;} }]);}(Parser);


// dist/parse/_lib/parsers/Hour0to23Parser.js
var Hour0to23Parser = /*#__PURE__*/function (_Parser20) {function Hour0to23Parser() {var _this22;_classCallCheck(this, Hour0to23Parser);for (var _len22 = arguments.length, args = new Array(_len22), _key22 = 0; _key22 < _len22; _key22++) {args[_key22] = arguments[_key22];}_this22 = _callSuper(this, Hour0to23Parser, [].concat(args));_defineProperty(_this22, "priority",
    70);_defineProperty(_this22, "incompatibleTokens",

















    ["a", "b", "h", "K", "k", "t", "T"]);return _this22;}_inherits(Hour0to23Parser, _Parser20);return _createClass(Hour0to23Parser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "H":return parseNumericPattern(numericPatterns.hour23h, dateString);case "Ho":return match2.ordinalNumber(dateString, { unit: "hour" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 23;} }, { key: "set", value: function set(date, _flags, value) {date.setHours(value, 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/Hour0To11Parser.js
var Hour0To11Parser = /*#__PURE__*/function (_Parser21) {function Hour0To11Parser() {var _this23;_classCallCheck(this, Hour0To11Parser);for (var _len23 = arguments.length, args = new Array(_len23), _key23 = 0; _key23 < _len23; _key23++) {args[_key23] = arguments[_key23];}_this23 = _callSuper(this, Hour0To11Parser, [].concat(args));_defineProperty(_this23, "priority",
    70);_defineProperty(_this23, "incompatibleTokens",






















    ["h", "H", "k", "t", "T"]);return _this23;}_inherits(Hour0To11Parser, _Parser21);return _createClass(Hour0To11Parser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "K":return parseNumericPattern(numericPatterns.hour11h, dateString);case "Ko":return match2.ordinalNumber(dateString, { unit: "hour" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 11;} }, { key: "set", value: function set(date, _flags, value) {var isPM = date.getHours() >= 12;if (isPM && value < 12) {date.setHours(value + 12, 0, 0, 0);} else {date.setHours(value, 0, 0, 0);}return date;} }]);}(Parser);


// dist/parse/_lib/parsers/Hour1To24Parser.js
var Hour1To24Parser = /*#__PURE__*/function (_Parser22) {function Hour1To24Parser() {var _this24;_classCallCheck(this, Hour1To24Parser);for (var _len24 = arguments.length, args = new Array(_len24), _key24 = 0; _key24 < _len24; _key24++) {args[_key24] = arguments[_key24];}_this24 = _callSuper(this, Hour1To24Parser, [].concat(args));_defineProperty(_this24, "priority",
    70);_defineProperty(_this24, "incompatibleTokens",


















    ["a", "b", "h", "H", "K", "t", "T"]);return _this24;}_inherits(Hour1To24Parser, _Parser22);return _createClass(Hour1To24Parser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "k":return parseNumericPattern(numericPatterns.hour24h, dateString);case "ko":return match2.ordinalNumber(dateString, { unit: "hour" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 1 && value <= 24;} }, { key: "set", value: function set(date, _flags, value) {var hours = value <= 24 ? value % 24 : value;date.setHours(hours, 0, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/MinuteParser.js
var MinuteParser = /*#__PURE__*/function (_Parser23) {function MinuteParser() {var _this25;_classCallCheck(this, MinuteParser);for (var _len25 = arguments.length, args = new Array(_len25), _key25 = 0; _key25 < _len25; _key25++) {args[_key25] = arguments[_key25];}_this25 = _callSuper(this, MinuteParser, [].concat(args));_defineProperty(_this25, "priority",
    60);_defineProperty(_this25, "incompatibleTokens",

















    ["t", "T"]);return _this25;}_inherits(MinuteParser, _Parser23);return _createClass(MinuteParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "m":return parseNumericPattern(numericPatterns.minute, dateString);case "mo":return match2.ordinalNumber(dateString, { unit: "minute" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 59;} }, { key: "set", value: function set(date, _flags, value) {date.setMinutes(value, 0, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/SecondParser.js
var SecondParser = /*#__PURE__*/function (_Parser24) {function SecondParser() {var _this26;_classCallCheck(this, SecondParser);for (var _len26 = arguments.length, args = new Array(_len26), _key26 = 0; _key26 < _len26; _key26++) {args[_key26] = arguments[_key26];}_this26 = _callSuper(this, SecondParser, [].concat(args));_defineProperty(_this26, "priority",
    50);_defineProperty(_this26, "incompatibleTokens",

















    ["t", "T"]);return _this26;}_inherits(SecondParser, _Parser24);return _createClass(SecondParser, [{ key: "parse", value: function parse(dateString, token, match2) {switch (token) {case "s":return parseNumericPattern(numericPatterns.second, dateString);case "so":return match2.ordinalNumber(dateString, { unit: "second" });default:return parseNDigits(token.length, dateString);}} }, { key: "validate", value: function validate(_date, value) {return value >= 0 && value <= 59;} }, { key: "set", value: function set(date, _flags, value) {date.setSeconds(value, 0);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/FractionOfSecondParser.js
var FractionOfSecondParser = /*#__PURE__*/function (_Parser25) {function FractionOfSecondParser() {var _this27;_classCallCheck(this, FractionOfSecondParser);for (var _len27 = arguments.length, args = new Array(_len27), _key27 = 0; _key27 < _len27; _key27++) {args[_key27] = arguments[_key27];}_this27 = _callSuper(this, FractionOfSecondParser, [].concat(args));_defineProperty(_this27, "priority",
    30);_defineProperty(_this27, "incompatibleTokens",








    ["t", "T"]);return _this27;}_inherits(FractionOfSecondParser, _Parser25);return _createClass(FractionOfSecondParser, [{ key: "parse", value: function parse(dateString, token) {var valueCallback = function valueCallback(value) {return Math.trunc(value * Math.pow(10, -token.length + 3));};return mapValue(parseNDigits(token.length, dateString), valueCallback);} }, { key: "set", value: function set(date, _flags, value) {date.setMilliseconds(value);return date;} }]);}(Parser);


// dist/parse/_lib/parsers/ISOTimezoneWithZParser.js
var ISOTimezoneWithZParser = /*#__PURE__*/function (_Parser26) {function ISOTimezoneWithZParser() {var _this28;_classCallCheck(this, ISOTimezoneWithZParser);for (var _len28 = arguments.length, args = new Array(_len28), _key28 = 0; _key28 < _len28; _key28++) {args[_key28] = arguments[_key28];}_this28 = _callSuper(this, ISOTimezoneWithZParser, [].concat(args));_defineProperty(_this28, "priority",
    10);_defineProperty(_this28, "incompatibleTokens",




















    ["t", "T", "x"]);return _this28;}_inherits(ISOTimezoneWithZParser, _Parser26);return _createClass(ISOTimezoneWithZParser, [{ key: "parse", value: function parse(dateString, token) {switch (token) {case "X":return parseTimezonePattern(timezonePatterns.basicOptionalMinutes, dateString);case "XX":return parseTimezonePattern(timezonePatterns.basic, dateString);case "XXXX":return parseTimezonePattern(timezonePatterns.basicOptionalSeconds, dateString);case "XXXXX":return parseTimezonePattern(timezonePatterns.extendedOptionalSeconds, dateString);case "XXX":default:return parseTimezonePattern(timezonePatterns.extended, dateString);}} }, { key: "set", value: function set(date, flags, value) {if (flags.timestampIsSet) return date;return constructFrom(date, date.getTime() - getTimezoneOffsetInMilliseconds(date) - value);} }]);}(Parser);


// dist/parse/_lib/parsers/ISOTimezoneParser.js
var ISOTimezoneParser = /*#__PURE__*/function (_Parser27) {function ISOTimezoneParser() {var _this29;_classCallCheck(this, ISOTimezoneParser);for (var _len29 = arguments.length, args = new Array(_len29), _key29 = 0; _key29 < _len29; _key29++) {args[_key29] = arguments[_key29];}_this29 = _callSuper(this, ISOTimezoneParser, [].concat(args));_defineProperty(_this29, "priority",
    10);_defineProperty(_this29, "incompatibleTokens",




















    ["t", "T", "X"]);return _this29;}_inherits(ISOTimezoneParser, _Parser27);return _createClass(ISOTimezoneParser, [{ key: "parse", value: function parse(dateString, token) {switch (token) {case "x":return parseTimezonePattern(timezonePatterns.basicOptionalMinutes, dateString);case "xx":return parseTimezonePattern(timezonePatterns.basic, dateString);case "xxxx":return parseTimezonePattern(timezonePatterns.basicOptionalSeconds, dateString);case "xxxxx":return parseTimezonePattern(timezonePatterns.extendedOptionalSeconds, dateString);case "xxx":default:return parseTimezonePattern(timezonePatterns.extended, dateString);}} }, { key: "set", value: function set(date, flags, value) {if (flags.timestampIsSet) return date;return constructFrom(date, date.getTime() - getTimezoneOffsetInMilliseconds(date) - value);} }]);}(Parser);


// dist/parse/_lib/parsers/TimestampSecondsParser.js
var TimestampSecondsParser = /*#__PURE__*/function (_Parser28) {function TimestampSecondsParser() {var _this30;_classCallCheck(this, TimestampSecondsParser);for (var _len30 = arguments.length, args = new Array(_len30), _key30 = 0; _key30 < _len30; _key30++) {args[_key30] = arguments[_key30];}_this30 = _callSuper(this, TimestampSecondsParser, [].concat(args));_defineProperty(_this30, "priority",
    40);_defineProperty(_this30, "incompatibleTokens",






    "*");return _this30;}_inherits(TimestampSecondsParser, _Parser28);return _createClass(TimestampSecondsParser, [{ key: "parse", value: function parse(dateString) {return parseAnyDigitsSigned(dateString);} }, { key: "set", value: function set(date, _flags, value) {return [constructFrom(date, value * 1000), { timestampIsSet: true }];} }]);}(Parser);


// dist/parse/_lib/parsers/TimestampMillisecondsParser.js
var TimestampMillisecondsParser = /*#__PURE__*/function (_Parser29) {function TimestampMillisecondsParser() {var _this31;_classCallCheck(this, TimestampMillisecondsParser);for (var _len31 = arguments.length, args = new Array(_len31), _key31 = 0; _key31 < _len31; _key31++) {args[_key31] = arguments[_key31];}_this31 = _callSuper(this, TimestampMillisecondsParser, [].concat(args));_defineProperty(_this31, "priority",
    20);_defineProperty(_this31, "incompatibleTokens",






    "*");return _this31;}_inherits(TimestampMillisecondsParser, _Parser29);return _createClass(TimestampMillisecondsParser, [{ key: "parse", value: function parse(dateString) {return parseAnyDigitsSigned(dateString);} }, { key: "set", value: function set(date, _flags, value) {return [constructFrom(date, value), { timestampIsSet: true }];} }]);}(Parser);


// dist/parse/_lib/parsers.js
var parsers = {
  G: new EraParser(),
  y: new YearParser(),
  Y: new LocalWeekYearParser(),
  R: new ISOWeekYearParser(),
  u: new ExtendedYearParser(),
  Q: new QuarterParser(),
  q: new StandAloneQuarterParser(),
  M: new MonthParser(),
  L: new StandAloneMonthParser(),
  w: new LocalWeekParser(),
  I: new ISOWeekParser(),
  d: new DateParser(),
  D: new DayOfYearParser(),
  E: new DayParser(),
  e: new LocalDayParser(),
  c: new StandAloneLocalDayParser(),
  i: new ISODayParser(),
  a: new AMPMParser(),
  b: new AMPMMidnightParser(),
  B: new DayPeriodParser(),
  h: new Hour1to12Parser(),
  H: new Hour0to23Parser(),
  K: new Hour0To11Parser(),
  k: new Hour1To24Parser(),
  m: new MinuteParser(),
  s: new SecondParser(),
  S: new FractionOfSecondParser(),
  X: new ISOTimezoneWithZParser(),
  x: new ISOTimezoneParser(),
  t: new TimestampSecondsParser(),
  T: new TimestampMillisecondsParser()
};

// dist/parse.js
var formattingTokensRegExp2 = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g;
var longFormattingTokensRegExp2 = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g;
var escapedStringRegExp2 = /^'([^]*?)'?$/;
var doubleQuoteRegExp2 = /''/g;
var notWhitespaceRegExp = /\S/;
var unescapedLatinCharacterRegExp2 = /[a-zA-Z]/;
function parse(dateStr, formatStr, referenceDate, options) {var _ref31, _options$locale13, _ref32, _ref33, _ref34, _options$firstWeekCon4, _options$locale14, _defaultOptions2$loca0, _ref35, _ref36, _ref37, _options$weekStartsOn7, _options$locale15, _defaultOptions2$loca1;
  var invalidDate = function invalidDate() {return constructFrom((options === null || options === void 0 ? void 0 : options.in) || referenceDate, NaN);};
  var defaultOptions2 = getDefaultOptions2();
  var locale = (_ref31 = (_options$locale13 = options === null || options === void 0 ? void 0 : options.locale) !== null && _options$locale13 !== void 0 ? _options$locale13 : defaultOptions2.locale) !== null && _ref31 !== void 0 ? _ref31 : enUS;
  var firstWeekContainsDate = (_ref32 = (_ref33 = (_ref34 = (_options$firstWeekCon4 = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon4 !== void 0 ? _options$firstWeekCon4 : options === null || options === void 0 || (_options$locale14 = options.locale) === null || _options$locale14 === void 0 || (_options$locale14 = _options$locale14.options) === null || _options$locale14 === void 0 ? void 0 : _options$locale14.firstWeekContainsDate) !== null && _ref34 !== void 0 ? _ref34 : defaultOptions2.firstWeekContainsDate) !== null && _ref33 !== void 0 ? _ref33 : (_defaultOptions2$loca0 = defaultOptions2.locale) === null || _defaultOptions2$loca0 === void 0 || (_defaultOptions2$loca0 = _defaultOptions2$loca0.options) === null || _defaultOptions2$loca0 === void 0 ? void 0 : _defaultOptions2$loca0.firstWeekContainsDate) !== null && _ref32 !== void 0 ? _ref32 : 1;
  var weekStartsOn = (_ref35 = (_ref36 = (_ref37 = (_options$weekStartsOn7 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn7 !== void 0 ? _options$weekStartsOn7 : options === null || options === void 0 || (_options$locale15 = options.locale) === null || _options$locale15 === void 0 || (_options$locale15 = _options$locale15.options) === null || _options$locale15 === void 0 ? void 0 : _options$locale15.weekStartsOn) !== null && _ref37 !== void 0 ? _ref37 : defaultOptions2.weekStartsOn) !== null && _ref36 !== void 0 ? _ref36 : (_defaultOptions2$loca1 = defaultOptions2.locale) === null || _defaultOptions2$loca1 === void 0 || (_defaultOptions2$loca1 = _defaultOptions2$loca1.options) === null || _defaultOptions2$loca1 === void 0 ? void 0 : _defaultOptions2$loca1.weekStartsOn) !== null && _ref35 !== void 0 ? _ref35 : 0;
  if (!formatStr)
  return dateStr ? invalidDate() : toDate(referenceDate, options === null || options === void 0 ? void 0 : options.in);
  var subFnOptions = {
    firstWeekContainsDate: firstWeekContainsDate,
    weekStartsOn: weekStartsOn,
    locale: locale
  };
  var setters = [new DateTimezoneSetter(options === null || options === void 0 ? void 0 : options.in, referenceDate)];
  var tokens = formatStr.match(longFormattingTokensRegExp2).map(function (substring) {
    var firstCharacter = substring[0];
    if (firstCharacter in longFormatters) {
      var longFormatter = longFormatters[firstCharacter];
      return longFormatter(substring, locale.formatLong);
    }
    return substring;
  }).join("").match(formattingTokensRegExp2);
  var usedTokens = [];var _iterator = _createForOfIteratorHelper(
      tokens),_step;try {var _loop = function _loop() {var token = _step.value;
        if (!(options !== null && options !== void 0 && options.useAdditionalWeekYearTokens) && isProtectedWeekYearToken(token)) {
          warnOrThrowProtectedError(token, formatStr, dateStr);
        }
        if (!(options !== null && options !== void 0 && options.useAdditionalDayOfYearTokens) && isProtectedDayOfYearToken(token)) {
          warnOrThrowProtectedError(token, formatStr, dateStr);
        }
        var firstCharacter = token[0];
        var parser = parsers[firstCharacter];
        if (parser) {
          var incompatibleTokens = parser.incompatibleTokens;
          if (Array.isArray(incompatibleTokens)) {
            var incompatibleToken = usedTokens.find(function (usedToken) {return incompatibleTokens.includes(usedToken.token) || usedToken.token === firstCharacter;});
            if (incompatibleToken) {
              throw new RangeError("The format string mustn't contain `".concat(incompatibleToken.fullToken, "` and `").concat(token, "` at the same time"));
            }
          } else if (parser.incompatibleTokens === "*" && usedTokens.length > 0) {
            throw new RangeError("The format string mustn't contain `".concat(token, "` and any other token at the same time"));
          }
          usedTokens.push({ token: firstCharacter, fullToken: token });
          var parseResult = parser.run(dateStr, token, locale.match, subFnOptions);
          if (!parseResult) {return { v:
              invalidDate() };
          }
          setters.push(parseResult.setter);
          dateStr = parseResult.rest;
        } else {
          if (firstCharacter.match(unescapedLatinCharacterRegExp2)) {
            throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
          }
          if (token === "''") {
            token = "'";
          } else if (firstCharacter === "'") {
            token = cleanEscapedString2(token);
          }
          if (dateStr.indexOf(token) === 0) {
            dateStr = dateStr.slice(token.length);
          } else {return { v:
              invalidDate() };
          }
        }
      },_ret;for (_iterator.s(); !(_step = _iterator.n()).done;) {_ret = _loop();if (_ret) return _ret.v;}} catch (err) {_iterator.e(err);} finally {_iterator.f();}
  if (dateStr.length > 0 && notWhitespaceRegExp.test(dateStr)) {
    return invalidDate();
  }
  var uniquePrioritySetters = setters.map(function (setter) {return setter.priority;}).sort(function (a, b) {return b - a;}).filter(function (priority, index, array) {return array.indexOf(priority) === index;}).map(function (priority) {return setters.filter(function (setter) {return setter.priority === priority;}).sort(function (a, b) {return b.subPriority - a.subPriority;});}).map(function (setterArray) {return setterArray[0];});
  var date = toDate(referenceDate, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(+date))
  return invalidDate();
  var flags = {};var _iterator2 = _createForOfIteratorHelper(
      uniquePrioritySetters),_step2;try {for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {var setter = _step2.value;
      if (!setter.validate(date, subFnOptions)) {
        return invalidDate();
      }
      var result = setter.set(date, flags, subFnOptions);
      if (Array.isArray(result)) {
        date = result[0];
        Object.assign(flags, result[1]);
      } else {
        date = result;
      }
    }} catch (err) {_iterator2.e(err);} finally {_iterator2.f();}
  return date;
}
function cleanEscapedString2(input) {
  return input.match(escapedStringRegExp2)[1].replace(doubleQuoteRegExp2, "'");
}

// dist/isMatch.js
function isMatch(dateStr, formatStr, options) {
  return isValid(parse(dateStr, formatStr, new Date(), options));
}

// dist/fp/isMatch.js
var isMatch2 = convertToFP(isMatch, 2);
// dist/fp/isMatchWithOptions.js
var _isMatchWithOptions = convertToFP(isMatch, 3);
// dist/isMonday.js
function isMonday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 1;
}

// dist/fp/isMonday.js
var isMonday2 = convertToFP(isMonday, 1);
// dist/fp/isMondayWithOptions.js
var _isMondayWithOptions = convertToFP(isMonday, 2);
// dist/fp/isSameDay.js
var isSameDay2 = convertToFP(isSameDay, 2);
// dist/fp/isSameDayWithOptions.js
var _isSameDayWithOptions = convertToFP(isSameDay, 3);
// dist/startOfHour.js
function startOfHour(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setMinutes(0, 0, 0);
  return _date;
}

// dist/isSameHour.js
function isSameHour(dateLeft, dateRight, options) {
  var _normalizeDates43 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, dateLeft, dateRight),_normalizeDates44 = _slicedToArray(_normalizeDates43, 2),dateLeft_ = _normalizeDates44[0],dateRight_ = _normalizeDates44[1];
  return +startOfHour(dateLeft_) === +startOfHour(dateRight_);
}

// dist/fp/isSameHour.js
var isSameHour2 = convertToFP(isSameHour, 2);
// dist/fp/isSameHourWithOptions.js
var _isSameHourWithOptions = convertToFP(isSameHour, 3);
// dist/isSameWeek.js
function isSameWeek(laterDate, earlierDate, options) {
  var _normalizeDates45 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates46 = _slicedToArray(_normalizeDates45, 2),laterDate_ = _normalizeDates46[0],earlierDate_ = _normalizeDates46[1];
  return +startOfWeek(laterDate_, options) === +startOfWeek(earlierDate_, options);
}

// dist/isSameISOWeek.js
function isSameISOWeek(laterDate, earlierDate, options) {
  return isSameWeek(laterDate, earlierDate, _objectSpread(_objectSpread({}, options), {}, { weekStartsOn: 1 }));
}

// dist/fp/isSameISOWeek.js
var isSameISOWeek2 = convertToFP(isSameISOWeek, 2);
// dist/fp/isSameISOWeekWithOptions.js
var _isSameISOWeekWithOptions = convertToFP(isSameISOWeek, 3);
// dist/isSameISOWeekYear.js
function isSameISOWeekYear(laterDate, earlierDate, options) {
  var _normalizeDates47 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates48 = _slicedToArray(_normalizeDates47, 2),laterDate_ = _normalizeDates48[0],earlierDate_ = _normalizeDates48[1];
  return +startOfISOWeekYear(laterDate_) === +startOfISOWeekYear(earlierDate_);
}

// dist/fp/isSameISOWeekYear.js
var isSameISOWeekYear2 = convertToFP(isSameISOWeekYear, 2);
// dist/fp/isSameISOWeekYearWithOptions.js
var _isSameISOWeekYearWithOptions = convertToFP(isSameISOWeekYear, 3);
// dist/startOfMinute.js
function startOfMinute(date, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  date_.setSeconds(0, 0);
  return date_;
}

// dist/isSameMinute.js
function isSameMinute(laterDate, earlierDate) {
  return +startOfMinute(laterDate) === +startOfMinute(earlierDate);
}

// dist/fp/isSameMinute.js
var isSameMinute2 = convertToFP(isSameMinute, 2);
// dist/isSameMonth.js
function isSameMonth(laterDate, earlierDate, options) {
  var _normalizeDates49 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates50 = _slicedToArray(_normalizeDates49, 2),laterDate_ = _normalizeDates50[0],earlierDate_ = _normalizeDates50[1];
  return laterDate_.getFullYear() === earlierDate_.getFullYear() && laterDate_.getMonth() === earlierDate_.getMonth();
}

// dist/fp/isSameMonth.js
var isSameMonth2 = convertToFP(isSameMonth, 2);
// dist/fp/isSameMonthWithOptions.js
var _isSameMonthWithOptions = convertToFP(isSameMonth, 3);
// dist/isSameQuarter.js
function isSameQuarter(laterDate, earlierDate, options) {
  var _normalizeDates51 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates52 = _slicedToArray(_normalizeDates51, 2),dateLeft_ = _normalizeDates52[0],dateRight_ = _normalizeDates52[1];
  return +startOfQuarter(dateLeft_) === +startOfQuarter(dateRight_);
}

// dist/fp/isSameQuarter.js
var isSameQuarter2 = convertToFP(isSameQuarter, 2);
// dist/fp/isSameQuarterWithOptions.js
var _isSameQuarterWithOptions = convertToFP(isSameQuarter, 3);
// dist/startOfSecond.js
function startOfSecond(date, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  date_.setMilliseconds(0);
  return date_;
}

// dist/isSameSecond.js
function isSameSecond(laterDate, earlierDate) {
  return +startOfSecond(laterDate) === +startOfSecond(earlierDate);
}

// dist/fp/isSameSecond.js
var isSameSecond2 = convertToFP(isSameSecond, 2);
// dist/fp/isSameWeek.js
var isSameWeek2 = convertToFP(isSameWeek, 2);
// dist/fp/isSameWeekWithOptions.js
var _isSameWeekWithOptions = convertToFP(isSameWeek, 3);
// dist/isSameYear.js
function isSameYear(laterDate, earlierDate, options) {
  var _normalizeDates53 = normalizeDates(options === null || options === void 0 ? void 0 : options.in, laterDate, earlierDate),_normalizeDates54 = _slicedToArray(_normalizeDates53, 2),laterDate_ = _normalizeDates54[0],earlierDate_ = _normalizeDates54[1];
  return laterDate_.getFullYear() === earlierDate_.getFullYear();
}

// dist/fp/isSameYear.js
var isSameYear2 = convertToFP(isSameYear, 2);
// dist/fp/isSameYearWithOptions.js
var _isSameYearWithOptions = convertToFP(isSameYear, 3);
// dist/fp/isSaturday.js
var isSaturday2 = convertToFP(isSaturday, 1);
// dist/fp/isSaturdayWithOptions.js
var _isSaturdayWithOptions = convertToFP(isSaturday, 2);
// dist/fp/isSunday.js
var isSunday2 = convertToFP(isSunday, 1);
// dist/fp/isSundayWithOptions.js
var _isSundayWithOptions = convertToFP(isSunday, 2);
// dist/isThursday.js
function isThursday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 4;
}

// dist/fp/isThursday.js
var isThursday2 = convertToFP(isThursday, 1);
// dist/fp/isThursdayWithOptions.js
var _isThursdayWithOptions = convertToFP(isThursday, 2);
// dist/isTuesday.js
function isTuesday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 2;
}

// dist/fp/isTuesday.js
var isTuesday2 = convertToFP(isTuesday, 1);
// dist/fp/isTuesdayWithOptions.js
var _isTuesdayWithOptions = convertToFP(isTuesday, 2);
// dist/fp/isValid.js
var isValid2 = convertToFP(isValid, 1);
// dist/isWednesday.js
function isWednesday(date, options) {
  return toDate(date, options === null || options === void 0 ? void 0 : options.in).getDay() === 3;
}

// dist/fp/isWednesday.js
var isWednesday2 = convertToFP(isWednesday, 1);
// dist/fp/isWednesdayWithOptions.js
var _isWednesdayWithOptions = convertToFP(isWednesday, 2);
// dist/fp/isWeekend.js
var isWeekend2 = convertToFP(isWeekend, 1);
// dist/fp/isWeekendWithOptions.js
var _isWeekendWithOptions = convertToFP(isWeekend, 2);
// dist/isWithinInterval.js
function isWithinInterval(date, interval3, options) {
  var time = +toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var _sort9 = [
    +toDate(interval3.start, options === null || options === void 0 ? void 0 : options.in),
    +toDate(interval3.end, options === null || options === void 0 ? void 0 : options.in)].
    sort(function (a, b) {return a - b;}),_sort0 = _slicedToArray(_sort9, 2),startTime = _sort0[0],endTime = _sort0[1];
  return time >= startTime && time <= endTime;
}

// dist/fp/isWithinInterval.js
var isWithinInterval2 = convertToFP(isWithinInterval, 2);
// dist/fp/isWithinIntervalWithOptions.js
var _isWithinIntervalWithOptions = convertToFP(isWithinInterval, 3);
// dist/lastDayOfDecade.js
function lastDayOfDecade(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var decade = 9 + Math.floor(year / 10) * 10;
  _date.setFullYear(decade + 1, 0, 0);
  _date.setHours(0, 0, 0, 0);
  return toDate(_date, options === null || options === void 0 ? void 0 : options.in);
}

// dist/fp/lastDayOfDecade.js
var lastDayOfDecade2 = convertToFP(lastDayOfDecade, 1);
// dist/fp/lastDayOfDecadeWithOptions.js
var _lastDayOfDecadeWithOptions = convertToFP(lastDayOfDecade, 2);
// dist/lastDayOfWeek.js
function lastDayOfWeek(date, options) {var _ref38, _ref39, _ref40, _options$weekStartsOn8, _options$locale16, _defaultOptions2$loca10;
  var defaultOptions2 = getDefaultOptions();
  var weekStartsOn = (_ref38 = (_ref39 = (_ref40 = (_options$weekStartsOn8 = options === null || options === void 0 ? void 0 : options.weekStartsOn) !== null && _options$weekStartsOn8 !== void 0 ? _options$weekStartsOn8 : options === null || options === void 0 || (_options$locale16 = options.locale) === null || _options$locale16 === void 0 || (_options$locale16 = _options$locale16.options) === null || _options$locale16 === void 0 ? void 0 : _options$locale16.weekStartsOn) !== null && _ref40 !== void 0 ? _ref40 : defaultOptions2.weekStartsOn) !== null && _ref39 !== void 0 ? _ref39 : (_defaultOptions2$loca10 = defaultOptions2.locale) === null || _defaultOptions2$loca10 === void 0 || (_defaultOptions2$loca10 = _defaultOptions2$loca10.options) === null || _defaultOptions2$loca10 === void 0 ? void 0 : _defaultOptions2$loca10.weekStartsOn) !== null && _ref38 !== void 0 ? _ref38 : 0;
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var day = _date.getDay();
  var diff = (day < weekStartsOn ? -7 : 0) + 6 - (day - weekStartsOn);
  _date.setHours(0, 0, 0, 0);
  _date.setDate(_date.getDate() + diff);
  return _date;
}

// dist/lastDayOfISOWeek.js
function lastDayOfISOWeek(date, options) {
  return lastDayOfWeek(date, _objectSpread(_objectSpread({}, options), {}, { weekStartsOn: 1 }));
}

// dist/fp/lastDayOfISOWeek.js
var lastDayOfISOWeek2 = convertToFP(lastDayOfISOWeek, 1);
// dist/fp/lastDayOfISOWeekWithOptions.js
var _lastDayOfISOWeekWithOptions = convertToFP(lastDayOfISOWeek, 2);
// dist/lastDayOfISOWeekYear.js
function lastDayOfISOWeekYear(date, options) {
  var year = getISOWeekYear(date, options);
  var fourthOfJanuary = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  fourthOfJanuary.setFullYear(year + 1, 0, 4);
  fourthOfJanuary.setHours(0, 0, 0, 0);
  var date_ = startOfISOWeek(fourthOfJanuary, options);
  date_.setDate(date_.getDate() - 1);
  return date_;
}

// dist/fp/lastDayOfISOWeekYear.js
var lastDayOfISOWeekYear2 = convertToFP(lastDayOfISOWeekYear, 1);
// dist/fp/lastDayOfISOWeekYearWithOptions.js
var _lastDayOfISOWeekYearWithOptions = convertToFP(lastDayOfISOWeekYear, 2);
// dist/fp/lastDayOfMonth.js
var lastDayOfMonth2 = convertToFP(lastDayOfMonth, 1);
// dist/fp/lastDayOfMonthWithOptions.js
var _lastDayOfMonthWithOptions = convertToFP(lastDayOfMonth, 2);
// dist/lastDayOfQuarter.js
function lastDayOfQuarter(date, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var currentMonth = date_.getMonth();
  var month = currentMonth - currentMonth % 3 + 3;
  date_.setMonth(month, 0);
  date_.setHours(0, 0, 0, 0);
  return date_;
}

// dist/fp/lastDayOfQuarter.js
var lastDayOfQuarter2 = convertToFP(lastDayOfQuarter, 1);
// dist/fp/lastDayOfQuarterWithOptions.js
var _lastDayOfQuarterWithOptions = convertToFP(lastDayOfQuarter, 2);
// dist/fp/lastDayOfWeek.js
var lastDayOfWeek2 = convertToFP(lastDayOfWeek, 1);
// dist/fp/lastDayOfWeekWithOptions.js
var _lastDayOfWeekWithOptions = convertToFP(lastDayOfWeek, 2);
// dist/lastDayOfYear.js
function lastDayOfYear(date, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = date_.getFullYear();
  date_.setFullYear(year + 1, 0, 0);
  date_.setHours(0, 0, 0, 0);
  return date_;
}

// dist/fp/lastDayOfYear.js
var lastDayOfYear2 = convertToFP(lastDayOfYear, 1);
// dist/fp/lastDayOfYearWithOptions.js
var _lastDayOfYearWithOptions = convertToFP(lastDayOfYear, 2);
// dist/lightFormat.js
var formattingTokensRegExp3 = /(\w)\1*|''|'(''|[^'])+('|$)|./g;
var escapedStringRegExp3 = /^'([^]*?)'?$/;
var doubleQuoteRegExp3 = /''/g;
var unescapedLatinCharacterRegExp3 = /[a-zA-Z]/;
function lightFormat(date, formatStr) {
  var date_ = toDate(date);
  if (!isValid(date_)) {
    throw new RangeError("Invalid time value");
  }
  var tokens = formatStr.match(formattingTokensRegExp3);
  if (!tokens)
  return "";
  var result = tokens.map(function (substring) {
    if (substring === "''") {
      return "'";
    }
    var firstCharacter = substring[0];
    if (firstCharacter === "'") {
      return cleanEscapedString3(substring);
    }
    var formatter = lightFormatters[firstCharacter];
    if (formatter) {
      return formatter(date_, substring);
    }
    if (firstCharacter.match(unescapedLatinCharacterRegExp3)) {
      throw new RangeError("Format string contains an unescaped latin alphabet character `" + firstCharacter + "`");
    }
    return substring;
  }).join("");
  return result;
}
function cleanEscapedString3(input) {
  var matches = input.match(escapedStringRegExp3);
  if (!matches)
  return input;
  return matches[1].replace(doubleQuoteRegExp3, "'");
}

// dist/fp/lightFormat.js
var lightFormat2 = convertToFP(lightFormat, 2);
// dist/fp/max.js
var max2 = convertToFP(max, 1);
// dist/fp/maxWithOptions.js
var _maxWithOptions = convertToFP(max, 2);
// dist/milliseconds.js
function milliseconds(_ref41)







{var years = _ref41.years,months2 = _ref41.months,weeks = _ref41.weeks,days2 = _ref41.days,hours = _ref41.hours,minutes = _ref41.minutes,seconds = _ref41.seconds;
  var totalDays = 0;
  if (years)
  totalDays += years * daysInYear;
  if (months2)
  totalDays += months2 * (daysInYear / 12);
  if (weeks)
  totalDays += weeks * 7;
  if (days2)
  totalDays += days2;
  var totalSeconds = totalDays * 24 * 60 * 60;
  if (hours)
  totalSeconds += hours * 60 * 60;
  if (minutes)
  totalSeconds += minutes * 60;
  if (seconds)
  totalSeconds += seconds;
  return Math.trunc(totalSeconds * 1000);
}

// dist/fp/milliseconds.js
var milliseconds2 = convertToFP(milliseconds, 1);
// dist/millisecondsToHours.js
function millisecondsToHours(milliseconds3) {
  var hours = milliseconds3 / millisecondsInHour;
  return Math.trunc(hours);
}

// dist/fp/millisecondsToHours.js
var millisecondsToHours2 = convertToFP(millisecondsToHours, 1);
// dist/millisecondsToMinutes.js
function millisecondsToMinutes(milliseconds3) {
  var minutes = milliseconds3 / millisecondsInMinute;
  return Math.trunc(minutes);
}

// dist/fp/millisecondsToMinutes.js
var millisecondsToMinutes2 = convertToFP(millisecondsToMinutes, 1);
// dist/millisecondsToSeconds.js
function millisecondsToSeconds(milliseconds3) {
  var seconds = milliseconds3 / millisecondsInSecond;
  return Math.trunc(seconds);
}

// dist/fp/millisecondsToSeconds.js
var millisecondsToSeconds2 = convertToFP(millisecondsToSeconds, 1);
// dist/fp/min.js
var min2 = convertToFP(min, 1);
// dist/fp/minWithOptions.js
var _minWithOptions = convertToFP(min, 2);
// dist/minutesToHours.js
function minutesToHours(minutes) {
  var hours = minutes / minutesInHour;
  return Math.trunc(hours);
}

// dist/fp/minutesToHours.js
var minutesToHours2 = convertToFP(minutesToHours, 1);
// dist/minutesToMilliseconds.js
function minutesToMilliseconds(minutes) {
  return Math.trunc(minutes * millisecondsInMinute);
}

// dist/fp/minutesToMilliseconds.js
var minutesToMilliseconds2 = convertToFP(minutesToMilliseconds, 1);
// dist/minutesToSeconds.js
function minutesToSeconds(minutes) {
  return Math.trunc(minutes * secondsInMinute);
}

// dist/fp/minutesToSeconds.js
var minutesToSeconds2 = convertToFP(minutesToSeconds, 1);
// dist/monthsToQuarters.js
function monthsToQuarters(months2) {
  var quarters = months2 / monthsInQuarter;
  return Math.trunc(quarters);
}

// dist/fp/monthsToQuarters.js
var monthsToQuarters2 = convertToFP(monthsToQuarters, 1);
// dist/monthsToYears.js
function monthsToYears(months2) {
  var years = months2 / monthsInYear;
  return Math.trunc(years);
}

// dist/fp/monthsToYears.js
var monthsToYears2 = convertToFP(monthsToYears, 1);
// dist/nextDay.js
function nextDay(date, day, options) {
  var delta = day - getDay(date, options);
  if (delta <= 0)
  delta += 7;
  return addDays(date, delta, options);
}

// dist/fp/nextDay.js
var nextDay2 = convertToFP(nextDay, 2);
// dist/fp/nextDayWithOptions.js
var _nextDayWithOptions = convertToFP(nextDay, 3);
// dist/nextFriday.js
function nextFriday(date, options) {
  return nextDay(date, 5, options);
}

// dist/fp/nextFriday.js
var nextFriday2 = convertToFP(nextFriday, 1);
// dist/fp/nextFridayWithOptions.js
var _nextFridayWithOptions = convertToFP(nextFriday, 2);
// dist/nextMonday.js
function nextMonday(date, options) {
  return nextDay(date, 1, options);
}

// dist/fp/nextMonday.js
var nextMonday2 = convertToFP(nextMonday, 1);
// dist/fp/nextMondayWithOptions.js
var _nextMondayWithOptions = convertToFP(nextMonday, 2);
// dist/nextSaturday.js
function nextSaturday(date, options) {
  return nextDay(date, 6, options);
}

// dist/fp/nextSaturday.js
var nextSaturday2 = convertToFP(nextSaturday, 1);
// dist/fp/nextSaturdayWithOptions.js
var _nextSaturdayWithOptions = convertToFP(nextSaturday, 2);
// dist/nextSunday.js
function nextSunday(date, options) {
  return nextDay(date, 0, options);
}

// dist/fp/nextSunday.js
var nextSunday2 = convertToFP(nextSunday, 1);
// dist/fp/nextSundayWithOptions.js
var _nextSundayWithOptions = convertToFP(nextSunday, 2);
// dist/nextThursday.js
function nextThursday(date, options) {
  return nextDay(date, 4, options);
}

// dist/fp/nextThursday.js
var nextThursday2 = convertToFP(nextThursday, 1);
// dist/fp/nextThursdayWithOptions.js
var _nextThursdayWithOptions = convertToFP(nextThursday, 2);
// dist/nextTuesday.js
function nextTuesday(date, options) {
  return nextDay(date, 2, options);
}

// dist/fp/nextTuesday.js
var nextTuesday2 = convertToFP(nextTuesday, 1);
// dist/fp/nextTuesdayWithOptions.js
var _nextTuesdayWithOptions = convertToFP(nextTuesday, 2);
// dist/nextWednesday.js
function nextWednesday(date, options) {
  return nextDay(date, 3, options);
}

// dist/fp/nextWednesday.js
var nextWednesday2 = convertToFP(nextWednesday, 1);
// dist/fp/nextWednesdayWithOptions.js
var _nextWednesdayWithOptions = convertToFP(nextWednesday, 2);
// dist/fp/parse.js
var parse2 = convertToFP(parse, 3);
// dist/parseISO.js
function parseISO(argument, options) {var _options$additionalDi;
  var invalidDate = function invalidDate() {return constructFrom(options === null || options === void 0 ? void 0 : options.in, NaN);};
  var additionalDigits = (_options$additionalDi = options === null || options === void 0 ? void 0 : options.additionalDigits) !== null && _options$additionalDi !== void 0 ? _options$additionalDi : 2;
  var dateStrings = splitDateString(argument);
  var date;
  if (dateStrings.date) {
    var parseYearResult = parseYear(dateStrings.date, additionalDigits);
    date = parseDate(parseYearResult.restDateString, parseYearResult.year);
  }
  if (!date || isNaN(+date))
  return invalidDate();
  var timestamp = +date;
  var time = 0;
  var offset;
  if (dateStrings.time) {
    time = parseTime(dateStrings.time);
    if (isNaN(time))
    return invalidDate();
  }
  if (dateStrings.timezone) {
    offset = parseTimezone(dateStrings.timezone);
    if (isNaN(offset))
    return invalidDate();
  } else {
    var tmpDate = new Date(timestamp + time);
    var result = toDate(0, options === null || options === void 0 ? void 0 : options.in);
    result.setFullYear(tmpDate.getUTCFullYear(), tmpDate.getUTCMonth(), tmpDate.getUTCDate());
    result.setHours(tmpDate.getUTCHours(), tmpDate.getUTCMinutes(), tmpDate.getUTCSeconds(), tmpDate.getUTCMilliseconds());
    return result;
  }
  return toDate(timestamp + time + offset, options === null || options === void 0 ? void 0 : options.in);
}
var patterns = {
  dateTimeDelimiter: /[T ]/,
  timeZoneDelimiter: /[Z ]/i,
  timezone: /([Z+-].*)$/
};
var dateRegex = /^-?(?:(\d{3})|(\d{2})(?:-?(\d{2}))?|W(\d{2})(?:-?(\d{1}))?|)$/;
var timeRegex = /^(\d{2}(?:[.,]\d*)?)(?::?(\d{2}(?:[.,]\d*)?))?(?::?(\d{2}(?:[.,]\d*)?))?$/;
var timezoneRegex = /^([+-])(\d{2})(?::?(\d{2}))?$/;
function splitDateString(dateString) {
  var dateStrings = {};
  var array = dateString.split(patterns.dateTimeDelimiter);
  var timeString;
  if (array.length > 2) {
    return dateStrings;
  }
  if (/:/.test(array[0])) {
    timeString = array[0];
  } else {
    dateStrings.date = array[0];
    timeString = array[1];
    if (patterns.timeZoneDelimiter.test(dateStrings.date)) {
      dateStrings.date = dateString.split(patterns.timeZoneDelimiter)[0];
      timeString = dateString.substr(dateStrings.date.length, dateString.length);
    }
  }
  if (timeString) {
    var token = patterns.timezone.exec(timeString);
    if (token) {
      dateStrings.time = timeString.replace(token[1], "");
      dateStrings.timezone = token[1];
    } else {
      dateStrings.time = timeString;
    }
  }
  return dateStrings;
}
function parseYear(dateString, additionalDigits) {
  var regex = new RegExp("^(?:(\\d{4}|[+-]\\d{" + (4 + additionalDigits) + "})|(\\d{2}|[+-]\\d{" + (2 + additionalDigits) + "})$)");
  var captures = dateString.match(regex);
  if (!captures)
  return { year: NaN, restDateString: "" };
  var year = captures[1] ? parseInt(captures[1]) : null;
  var century = captures[2] ? parseInt(captures[2]) : null;
  return {
    year: century === null ? year : century * 100,
    restDateString: dateString.slice((captures[1] || captures[2]).length)
  };
}
function parseDate(dateString, year) {
  if (year === null)
  return new Date(NaN);
  var captures = dateString.match(dateRegex);
  if (!captures)
  return new Date(NaN);
  var isWeekDate = !!captures[4];
  var dayOfYear = parseDateUnit(captures[1]);
  var month = parseDateUnit(captures[2]) - 1;
  var day = parseDateUnit(captures[3]);
  var week = parseDateUnit(captures[4]);
  var dayOfWeek = parseDateUnit(captures[5]) - 1;
  if (isWeekDate) {
    if (!validateWeekDate(year, week, dayOfWeek)) {
      return new Date(NaN);
    }
    return dayOfISOWeekYear(year, week, dayOfWeek);
  } else {
    var date = new Date(0);
    if (!validateDate(year, month, day) || !validateDayOfYearDate(year, dayOfYear)) {
      return new Date(NaN);
    }
    date.setUTCFullYear(year, month, Math.max(dayOfYear, day));
    return date;
  }
}
function parseDateUnit(value) {
  return value ? parseInt(value) : 1;
}
function parseTime(timeString) {
  var captures = timeString.match(timeRegex);
  if (!captures)
  return NaN;
  var hours = parseTimeUnit(captures[1]);
  var minutes = parseTimeUnit(captures[2]);
  var seconds = parseTimeUnit(captures[3]);
  if (!validateTime(hours, minutes, seconds)) {
    return NaN;
  }
  return hours * millisecondsInHour + minutes * millisecondsInMinute + seconds * 1000;
}
function parseTimeUnit(value) {
  return value && parseFloat(value.replace(",", ".")) || 0;
}
function parseTimezone(timezoneString) {
  if (timezoneString === "Z")
  return 0;
  var captures = timezoneString.match(timezoneRegex);
  if (!captures)
  return 0;
  var sign = captures[1] === "+" ? -1 : 1;
  var hours = parseInt(captures[2]);
  var minutes = captures[3] && parseInt(captures[3]) || 0;
  if (!validateTimezone(hours, minutes)) {
    return NaN;
  }
  return sign * (hours * millisecondsInHour + minutes * millisecondsInMinute);
}
function dayOfISOWeekYear(isoWeekYear, week, day) {
  var date = new Date(0);
  date.setUTCFullYear(isoWeekYear, 0, 4);
  var fourthOfJanuaryDay = date.getUTCDay() || 7;
  var diff = (week - 1) * 7 + day + 1 - fourthOfJanuaryDay;
  date.setUTCDate(date.getUTCDate() + diff);
  return date;
}
var daysInMonths = [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
function isLeapYearIndex2(year) {
  return year % 400 === 0 || year % 4 === 0 && year % 100 !== 0;
}
function validateDate(year, month, date) {
  return month >= 0 && month <= 11 && date >= 1 && date <= (daysInMonths[month] || (isLeapYearIndex2(year) ? 29 : 28));
}
function validateDayOfYearDate(year, dayOfYear) {
  return dayOfYear >= 1 && dayOfYear <= (isLeapYearIndex2(year) ? 366 : 365);
}
function validateWeekDate(_year, week, day) {
  return week >= 1 && week <= 53 && day >= 0 && day <= 6;
}
function validateTime(hours, minutes, seconds) {
  if (hours === 24) {
    return minutes === 0 && seconds === 0;
  }
  return seconds >= 0 && seconds < 60 && minutes >= 0 && minutes < 60 && hours >= 0 && hours < 25;
}
function validateTimezone(_hours, minutes) {
  return minutes >= 0 && minutes <= 59;
}

// dist/fp/parseISO.js
var parseISO2 = convertToFP(parseISO, 1);
// dist/fp/parseISOWithOptions.js
var _parseISOWithOptions = convertToFP(parseISO, 2);
// dist/parseJSON.js
function parseJSON(dateStr, options) {
  var parts = dateStr.match(/(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2}):(\d{2})(?:\.(\d{0,7}))?(?:Z|(.)(\d{2}):?(\d{2})?)?/);
  if (!parts)
  return toDate(NaN, options === null || options === void 0 ? void 0 : options.in);
  return toDate(Date.UTC(+parts[1], +parts[2] - 1, +parts[3], +parts[4] - (+parts[9] || 0) * (parts[8] == "-" ? -1 : 1), +parts[5] - (+parts[10] || 0) * (parts[8] == "-" ? -1 : 1), +parts[6], +((parts[7] || "0") + "00").substring(0, 3)), options === null || options === void 0 ? void 0 : options.in);
}

// dist/fp/parseJSON.js
var parseJSON2 = convertToFP(parseJSON, 1);
// dist/fp/parseJSONWithOptions.js
var _parseJSONWithOptions = convertToFP(parseJSON, 2);
// dist/fp/parseWithOptions.js
var _parseWithOptions = convertToFP(parse, 4);
// dist/subDays.js
function subDays(date, amount, options) {
  return addDays(date, -amount, options);
}

// dist/previousDay.js
function previousDay(date, day, options) {
  var delta = getDay(date, options) - day;
  if (delta <= 0)
  delta += 7;
  return subDays(date, delta, options);
}

// dist/fp/previousDay.js
var previousDay2 = convertToFP(previousDay, 2);
// dist/fp/previousDayWithOptions.js
var _previousDayWithOptions = convertToFP(previousDay, 3);
// dist/previousFriday.js
function previousFriday(date, options) {
  return previousDay(date, 5, options);
}

// dist/fp/previousFriday.js
var previousFriday2 = convertToFP(previousFriday, 1);
// dist/fp/previousFridayWithOptions.js
var _previousFridayWithOptions = convertToFP(previousFriday, 2);
// dist/previousMonday.js
function previousMonday(date, options) {
  return previousDay(date, 1, options);
}

// dist/fp/previousMonday.js
var previousMonday2 = convertToFP(previousMonday, 1);
// dist/fp/previousMondayWithOptions.js
var _previousMondayWithOptions = convertToFP(previousMonday, 2);
// dist/previousSaturday.js
function previousSaturday(date, options) {
  return previousDay(date, 6, options);
}

// dist/fp/previousSaturday.js
var previousSaturday2 = convertToFP(previousSaturday, 1);
// dist/fp/previousSaturdayWithOptions.js
var _previousSaturdayWithOptions = convertToFP(previousSaturday, 2);
// dist/previousSunday.js
function previousSunday(date, options) {
  return previousDay(date, 0, options);
}

// dist/fp/previousSunday.js
var previousSunday2 = convertToFP(previousSunday, 1);
// dist/fp/previousSundayWithOptions.js
var _previousSundayWithOptions = convertToFP(previousSunday, 2);
// dist/previousThursday.js
function previousThursday(date, options) {
  return previousDay(date, 4, options);
}

// dist/fp/previousThursday.js
var previousThursday2 = convertToFP(previousThursday, 1);
// dist/fp/previousThursdayWithOptions.js
var _previousThursdayWithOptions = convertToFP(previousThursday, 2);
// dist/previousTuesday.js
function previousTuesday(date, options) {
  return previousDay(date, 2, options);
}

// dist/fp/previousTuesday.js
var previousTuesday2 = convertToFP(previousTuesday, 1);
// dist/fp/previousTuesdayWithOptions.js
var _previousTuesdayWithOptions = convertToFP(previousTuesday, 2);
// dist/previousWednesday.js
function previousWednesday(date, options) {
  return previousDay(date, 3, options);
}

// dist/fp/previousWednesday.js
var previousWednesday2 = convertToFP(previousWednesday, 1);
// dist/fp/previousWednesdayWithOptions.js
var _previousWednesdayWithOptions = convertToFP(previousWednesday, 2);
// dist/quartersToMonths.js
function quartersToMonths(quarters) {
  return Math.trunc(quarters * monthsInQuarter);
}

// dist/fp/quartersToMonths.js
var quartersToMonths2 = convertToFP(quartersToMonths, 1);
// dist/quartersToYears.js
function quartersToYears(quarters) {
  var years = quarters / quartersInYear;
  return Math.trunc(years);
}

// dist/fp/quartersToYears.js
var quartersToYears2 = convertToFP(quartersToYears, 1);
// dist/roundToNearestHours.js
function roundToNearestHours(date, options) {var _options$nearestTo, _options$roundingMeth2;
  var nearestTo = (_options$nearestTo = options === null || options === void 0 ? void 0 : options.nearestTo) !== null && _options$nearestTo !== void 0 ? _options$nearestTo : 1;
  if (nearestTo < 1 || nearestTo > 12)
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var fractionalMinutes = date_.getMinutes() / 60;
  var fractionalSeconds = date_.getSeconds() / 60 / 60;
  var fractionalMilliseconds = date_.getMilliseconds() / 1000 / 60 / 60;
  var hours = date_.getHours() + fractionalMinutes + fractionalSeconds + fractionalMilliseconds;
  var method = (_options$roundingMeth2 = options === null || options === void 0 ? void 0 : options.roundingMethod) !== null && _options$roundingMeth2 !== void 0 ? _options$roundingMeth2 : "round";
  var roundingMethod = getRoundingMethod(method);
  var roundedHours = roundingMethod(hours / nearestTo) * nearestTo;
  date_.setHours(roundedHours, 0, 0, 0);
  return date_;
}

// dist/fp/roundToNearestHours.js
var roundToNearestHours2 = convertToFP(roundToNearestHours, 1);
// dist/fp/roundToNearestHoursWithOptions.js
var _roundToNearestHoursWithOptions = convertToFP(roundToNearestHours, 2);
// dist/roundToNearestMinutes.js
function roundToNearestMinutes(date, options) {var _options$nearestTo2, _options$roundingMeth3;
  var nearestTo = (_options$nearestTo2 = options === null || options === void 0 ? void 0 : options.nearestTo) !== null && _options$nearestTo2 !== void 0 ? _options$nearestTo2 : 1;
  if (nearestTo < 1 || nearestTo > 30)
  return constructFrom(date, NaN);
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var fractionalSeconds = date_.getSeconds() / 60;
  var fractionalMilliseconds = date_.getMilliseconds() / 1000 / 60;
  var minutes = date_.getMinutes() + fractionalSeconds + fractionalMilliseconds;
  var method = (_options$roundingMeth3 = options === null || options === void 0 ? void 0 : options.roundingMethod) !== null && _options$roundingMeth3 !== void 0 ? _options$roundingMeth3 : "round";
  var roundingMethod = getRoundingMethod(method);
  var roundedMinutes = roundingMethod(minutes / nearestTo) * nearestTo;
  date_.setMinutes(roundedMinutes, 0, 0);
  return date_;
}

// dist/fp/roundToNearestMinutes.js
var roundToNearestMinutes2 = convertToFP(roundToNearestMinutes, 1);
// dist/fp/roundToNearestMinutesWithOptions.js
var _roundToNearestMinutesWithOptions = convertToFP(roundToNearestMinutes, 2);
// dist/secondsToHours.js
function secondsToHours(seconds) {
  var hours = seconds / secondsInHour;
  return Math.trunc(hours);
}

// dist/fp/secondsToHours.js
var secondsToHours2 = convertToFP(secondsToHours, 1);
// dist/secondsToMilliseconds.js
function secondsToMilliseconds(seconds) {
  return seconds * millisecondsInSecond;
}

// dist/fp/secondsToMilliseconds.js
var secondsToMilliseconds2 = convertToFP(secondsToMilliseconds, 1);
// dist/secondsToMinutes.js
function secondsToMinutes(seconds) {
  var minutes = seconds / secondsInMinute;
  return Math.trunc(minutes);
}

// dist/fp/secondsToMinutes.js
var secondsToMinutes2 = convertToFP(secondsToMinutes, 1);
// dist/setMonth.js
function setMonth(date, month, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var day = _date.getDate();
  var midMonth = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  midMonth.setFullYear(year, month, 15);
  midMonth.setHours(0, 0, 0, 0);
  var daysInMonth = getDaysInMonth(midMonth);
  _date.setMonth(month, Math.min(day, daysInMonth));
  return _date;
}

// dist/set.js
function set(date, values, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(+_date))
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
  if (values.year != null)
  _date.setFullYear(values.year);
  if (values.month != null)
  _date = setMonth(_date, values.month);
  if (values.date != null)
  _date.setDate(values.date);
  if (values.hours != null)
  _date.setHours(values.hours);
  if (values.minutes != null)
  _date.setMinutes(values.minutes);
  if (values.seconds != null)
  _date.setSeconds(values.seconds);
  if (values.milliseconds != null)
  _date.setMilliseconds(values.milliseconds);
  return _date;
}

// dist/fp/set.js
var set2 = convertToFP(set, 2);
// dist/setDate.js
function setDate(date, dayOfMonth, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setDate(dayOfMonth);
  return _date;
}

// dist/fp/setDate.js
var setDate2 = convertToFP(setDate, 2);
// dist/fp/setDateWithOptions.js
var _setDateWithOptions = convertToFP(setDate, 3);
// dist/fp/setDay.js
var setDay2 = convertToFP(setDay, 2);
// dist/setDayOfYear.js
function setDayOfYear(date, dayOfYear, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  date_.setMonth(0);
  date_.setDate(dayOfYear);
  return date_;
}

// dist/fp/setDayOfYear.js
var setDayOfYear2 = convertToFP(setDayOfYear, 2);
// dist/fp/setDayOfYearWithOptions.js
var _setDayOfYearWithOptions = convertToFP(setDayOfYear, 3);
// dist/fp/setDayWithOptions.js
var _setDayWithOptions = convertToFP(setDay, 3);
// dist/setHours.js
function setHours(date, hours, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setHours(hours);
  return _date;
}

// dist/fp/setHours.js
var setHours2 = convertToFP(setHours, 2);
// dist/fp/setHoursWithOptions.js
var _setHoursWithOptions = convertToFP(setHours, 3);
// dist/fp/setISODay.js
var setISODay2 = convertToFP(setISODay, 2);
// dist/fp/setISODayWithOptions.js
var _setISODayWithOptions = convertToFP(setISODay, 3);
// dist/fp/setISOWeek.js
var setISOWeek2 = convertToFP(setISOWeek, 2);
// dist/fp/setISOWeekWithOptions.js
var _setISOWeekWithOptions = convertToFP(setISOWeek, 3);
// dist/fp/setISOWeekYear.js
var setISOWeekYear2 = convertToFP(setISOWeekYear, 2);
// dist/fp/setISOWeekYearWithOptions.js
var _setISOWeekYearWithOptions = convertToFP(setISOWeekYear, 3);
// dist/setMilliseconds.js
function setMilliseconds(date, milliseconds3, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setMilliseconds(milliseconds3);
  return _date;
}

// dist/fp/setMilliseconds.js
var setMilliseconds2 = convertToFP(setMilliseconds, 2);
// dist/fp/setMillisecondsWithOptions.js
var _setMillisecondsWithOptions = convertToFP(setMilliseconds, 3);
// dist/setMinutes.js
function setMinutes(date, minutes, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  date_.setMinutes(minutes);
  return date_;
}

// dist/fp/setMinutes.js
var setMinutes2 = convertToFP(setMinutes, 2);
// dist/fp/setMinutesWithOptions.js
var _setMinutesWithOptions = convertToFP(setMinutes, 3);
// dist/fp/setMonth.js
var setMonth2 = convertToFP(setMonth, 2);
// dist/fp/setMonthWithOptions.js
var _setMonthWithOptions = convertToFP(setMonth, 3);
// dist/setQuarter.js
function setQuarter(date, quarter, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var oldQuarter = Math.trunc(date_.getMonth() / 3) + 1;
  var diff = quarter - oldQuarter;
  return setMonth(date_, date_.getMonth() + diff * 3);
}

// dist/fp/setQuarter.js
var setQuarter2 = convertToFP(setQuarter, 2);
// dist/fp/setQuarterWithOptions.js
var _setQuarterWithOptions = convertToFP(setQuarter, 3);
// dist/setSeconds.js
function setSeconds(date, seconds, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  _date.setSeconds(seconds);
  return _date;
}

// dist/fp/setSeconds.js
var setSeconds2 = convertToFP(setSeconds, 2);
// dist/fp/setSecondsWithOptions.js
var _setSecondsWithOptions = convertToFP(setSeconds, 3);
// dist/fp/setWeek.js
var setWeek2 = convertToFP(setWeek, 2);
// dist/fp/setWeekWithOptions.js
var _setWeekWithOptions = convertToFP(setWeek, 3);
// dist/setWeekYear.js
function setWeekYear(date, weekYear, options) {var _ref42, _ref43, _ref44, _options$firstWeekCon5, _options$locale17, _defaultOptions2$loca11;
  var defaultOptions2 = getDefaultOptions();
  var firstWeekContainsDate = (_ref42 = (_ref43 = (_ref44 = (_options$firstWeekCon5 = options === null || options === void 0 ? void 0 : options.firstWeekContainsDate) !== null && _options$firstWeekCon5 !== void 0 ? _options$firstWeekCon5 : options === null || options === void 0 || (_options$locale17 = options.locale) === null || _options$locale17 === void 0 || (_options$locale17 = _options$locale17.options) === null || _options$locale17 === void 0 ? void 0 : _options$locale17.firstWeekContainsDate) !== null && _ref44 !== void 0 ? _ref44 : defaultOptions2.firstWeekContainsDate) !== null && _ref43 !== void 0 ? _ref43 : (_defaultOptions2$loca11 = defaultOptions2.locale) === null || _defaultOptions2$loca11 === void 0 || (_defaultOptions2$loca11 = _defaultOptions2$loca11.options) === null || _defaultOptions2$loca11 === void 0 ? void 0 : _defaultOptions2$loca11.firstWeekContainsDate) !== null && _ref42 !== void 0 ? _ref42 : 1;
  var diff = differenceInCalendarDays(toDate(date, options === null || options === void 0 ? void 0 : options.in), startOfWeekYear(date, options), options);
  var firstWeek = constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, 0);
  firstWeek.setFullYear(weekYear, 0, firstWeekContainsDate);
  firstWeek.setHours(0, 0, 0, 0);
  var date_ = startOfWeekYear(firstWeek, options);
  date_.setDate(date_.getDate() + diff);
  return date_;
}

// dist/fp/setWeekYear.js
var setWeekYear2 = convertToFP(setWeekYear, 2);
// dist/fp/setWeekYearWithOptions.js
var _setWeekYearWithOptions = convertToFP(setWeekYear, 3);
// dist/fp/setWithOptions.js
var _setWithOptions = convertToFP(set, 3);
// dist/setYear.js
function setYear(date, year, options) {
  var date_ = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  if (isNaN(+date_))
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, NaN);
  date_.setFullYear(year);
  return date_;
}

// dist/fp/setYear.js
var setYear2 = convertToFP(setYear, 2);
// dist/fp/setYearWithOptions.js
var _setYearWithOptions = convertToFP(setYear, 3);
// dist/fp/startOfDay.js
var startOfDay2 = convertToFP(startOfDay, 1);
// dist/fp/startOfDayWithOptions.js
var _startOfDayWithOptions = convertToFP(startOfDay, 2);
// dist/startOfDecade.js
function startOfDecade(date, options) {
  var _date = toDate(date, options === null || options === void 0 ? void 0 : options.in);
  var year = _date.getFullYear();
  var decade = Math.floor(year / 10) * 10;
  _date.setFullYear(decade, 0, 1);
  _date.setHours(0, 0, 0, 0);
  return _date;
}

// dist/fp/startOfDecade.js
var startOfDecade2 = convertToFP(startOfDecade, 1);
// dist/fp/startOfDecadeWithOptions.js
var _startOfDecadeWithOptions = convertToFP(startOfDecade, 2);
// dist/fp/startOfHour.js
var startOfHour2 = convertToFP(startOfHour, 1);
// dist/fp/startOfHourWithOptions.js
var _startOfHourWithOptions = convertToFP(startOfHour, 2);
// dist/fp/startOfISOWeek.js
var startOfISOWeek2 = convertToFP(startOfISOWeek, 1);
// dist/fp/startOfISOWeekWithOptions.js
var _startOfISOWeekWithOptions = convertToFP(startOfISOWeek, 2);
// dist/fp/startOfISOWeekYear.js
var startOfISOWeekYear2 = convertToFP(startOfISOWeekYear, 1);
// dist/fp/startOfISOWeekYearWithOptions.js
var _startOfISOWeekYearWithOptions = convertToFP(startOfISOWeekYear, 2);
// dist/fp/startOfMinute.js
var startOfMinute2 = convertToFP(startOfMinute, 1);
// dist/fp/startOfMinuteWithOptions.js
var _startOfMinuteWithOptions = convertToFP(startOfMinute, 2);
// dist/fp/startOfMonth.js
var startOfMonth2 = convertToFP(startOfMonth, 1);
// dist/fp/startOfMonthWithOptions.js
var _startOfMonthWithOptions = convertToFP(startOfMonth, 2);
// dist/fp/startOfQuarter.js
var startOfQuarter2 = convertToFP(startOfQuarter, 1);
// dist/fp/startOfQuarterWithOptions.js
var _startOfQuarterWithOptions = convertToFP(startOfQuarter, 2);
// dist/fp/startOfSecond.js
var startOfSecond2 = convertToFP(startOfSecond, 1);
// dist/fp/startOfSecondWithOptions.js
var _startOfSecondWithOptions = convertToFP(startOfSecond, 2);
// dist/fp/startOfWeek.js
var startOfWeek2 = convertToFP(startOfWeek, 1);
// dist/fp/startOfWeekWithOptions.js
var _startOfWeekWithOptions = convertToFP(startOfWeek, 2);
// dist/fp/startOfWeekYear.js
var startOfWeekYear2 = convertToFP(startOfWeekYear, 1);
// dist/fp/startOfWeekYearWithOptions.js
var _startOfWeekYearWithOptions = convertToFP(startOfWeekYear, 2);
// dist/fp/startOfYear.js
var startOfYear2 = convertToFP(startOfYear, 1);
// dist/fp/startOfYearWithOptions.js
var _startOfYearWithOptions = convertToFP(startOfYear, 2);
// dist/subMonths.js
function subMonths(date, amount, options) {
  return addMonths(date, -amount, options);
}

// dist/sub.js
function sub(date, duration, options) {
  var _duration$years3 =







    duration.years,years = _duration$years3 === void 0 ? 0 : _duration$years3,_duration$months3 = duration.months,months2 = _duration$months3 === void 0 ? 0 : _duration$months3,_duration$weeks2 = duration.weeks,weeks = _duration$weeks2 === void 0 ? 0 : _duration$weeks2,_duration$days3 = duration.days,days2 = _duration$days3 === void 0 ? 0 : _duration$days3,_duration$hours3 = duration.hours,hours = _duration$hours3 === void 0 ? 0 : _duration$hours3,_duration$minutes3 = duration.minutes,minutes = _duration$minutes3 === void 0 ? 0 : _duration$minutes3,_duration$seconds3 = duration.seconds,seconds = _duration$seconds3 === void 0 ? 0 : _duration$seconds3;
  var withoutMonths = subMonths(date, months2 + years * 12, options);
  var withoutDays = subDays(withoutMonths, days2 + weeks * 7, options);
  var minutesToSub = minutes + hours * 60;
  var secondsToSub = seconds + minutesToSub * 60;
  var msToSub = secondsToSub * 1000;
  return constructFrom((options === null || options === void 0 ? void 0 : options.in) || date, +withoutDays - msToSub);
}

// dist/fp/sub.js
var sub2 = convertToFP(sub, 2);
// dist/subBusinessDays.js
function subBusinessDays(date, amount, options) {
  return addBusinessDays(date, -amount, options);
}

// dist/fp/subBusinessDays.js
var subBusinessDays2 = convertToFP(subBusinessDays, 2);
// dist/fp/subBusinessDaysWithOptions.js
var _subBusinessDaysWithOptions = convertToFP(subBusinessDays, 3);
// dist/fp/subDays.js
var subDays2 = convertToFP(subDays, 2);
// dist/fp/subDaysWithOptions.js
var _subDaysWithOptions = convertToFP(subDays, 3);
// dist/subHours.js
function subHours(date, amount, options) {
  return addHours(date, -amount, options);
}

// dist/fp/subHours.js
var subHours2 = convertToFP(subHours, 2);
// dist/fp/subHoursWithOptions.js
var _subHoursWithOptions = convertToFP(subHours, 3);
// dist/fp/subISOWeekYears.js
var subISOWeekYears2 = convertToFP(subISOWeekYears, 2);
// dist/fp/subISOWeekYearsWithOptions.js
var _subISOWeekYearsWithOptions = convertToFP(subISOWeekYears, 3);
// dist/subMilliseconds.js
function subMilliseconds(date, amount, options) {
  return addMilliseconds(date, -amount, options);
}

// dist/fp/subMilliseconds.js
var subMilliseconds2 = convertToFP(subMilliseconds, 2);
// dist/fp/subMillisecondsWithOptions.js
var _subMillisecondsWithOptions = convertToFP(subMilliseconds, 3);
// dist/subMinutes.js
function subMinutes(date, amount, options) {
  return addMinutes(date, -amount, options);
}

// dist/fp/subMinutes.js
var subMinutes2 = convertToFP(subMinutes, 2);
// dist/fp/subMinutesWithOptions.js
var _subMinutesWithOptions = convertToFP(subMinutes, 3);
// dist/fp/subMonths.js
var subMonths2 = convertToFP(subMonths, 2);
// dist/fp/subMonthsWithOptions.js
var _subMonthsWithOptions = convertToFP(subMonths, 3);
// dist/subQuarters.js
function subQuarters(date, amount, options) {
  return addQuarters(date, -amount, options);
}

// dist/fp/subQuarters.js
var subQuarters2 = convertToFP(subQuarters, 2);
// dist/fp/subQuartersWithOptions.js
var _subQuartersWithOptions = convertToFP(subQuarters, 3);
// dist/subSeconds.js
function subSeconds(date, amount, options) {
  return addSeconds(date, -amount, options);
}

// dist/fp/subSeconds.js
var subSeconds2 = convertToFP(subSeconds, 2);
// dist/fp/subSecondsWithOptions.js
var _subSecondsWithOptions = convertToFP(subSeconds, 3);
// dist/subWeeks.js
function subWeeks(date, amount, options) {
  return addWeeks(date, -amount, options);
}

// dist/fp/subWeeks.js
var subWeeks2 = convertToFP(subWeeks, 2);
// dist/fp/subWeeksWithOptions.js
var _subWeeksWithOptions = convertToFP(subWeeks, 3);
// dist/fp/subWithOptions.js
var _subWithOptions = convertToFP(sub, 3);
// dist/subYears.js
function subYears(date, amount, options) {
  return addYears(date, -amount, options);
}

// dist/fp/subYears.js
var subYears2 = convertToFP(subYears, 2);
// dist/fp/subYearsWithOptions.js
var _subYearsWithOptions = convertToFP(subYears, 3);
// dist/fp/toDate.js
var toDate2 = convertToFP(toDate, 2);
// dist/fp/transpose.js
var transpose2 = convertToFP(transpose, 2);
// dist/weeksToDays.js
function weeksToDays(weeks) {
  return Math.trunc(weeks * daysInWeek);
}

// dist/fp/weeksToDays.js
var weeksToDays2 = convertToFP(weeksToDays, 1);
// dist/yearsToDays.js
function yearsToDays(years) {
  return Math.trunc(years * daysInYear);
}

// dist/fp/yearsToDays.js
var yearsToDays2 = convertToFP(yearsToDays, 1);
// dist/yearsToMonths.js
function yearsToMonths(years) {
  return Math.trunc(years * monthsInYear);
}

// dist/fp/yearsToMonths.js
var yearsToMonths2 = convertToFP(yearsToMonths, 1);
// dist/yearsToQuarters.js
function yearsToQuarters(years) {
  return Math.trunc(years * quartersInYear);
}

// dist/fp/yearsToQuarters.js
var yearsToQuarters2 = convertToFP(yearsToQuarters, 1);
// dist/fp/cdn.js
window.dateFns = _objectSpread(_objectSpread({},
window.dateFns), {}, {
  fp: exports_fp });


//# debugId=69F0AA2BDF27F80864756E2164756E21

//# sourceMappingURL=cdn.js.map
})();