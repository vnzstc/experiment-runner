declare namespace _default {
    export const array: any;
    const _function: any;
    export { _function as function };
    export const map: any;
    export const object: any;
    export const set: any;
    export const string: any;
}
export default _default;
