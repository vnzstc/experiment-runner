export default copyPrototypeMethods;
/**
 * Copies prototype methods into a new object that has no prototype
 * @param      {object}  prototype  The prototype to copy from
 * @returns    {object}  A new object that has the same methods of the prototype
 */
declare function copyPrototypeMethods(prototype: object): object;
