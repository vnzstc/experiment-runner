export default typeOf;
/**
 * Returns the lower-case result of running type from type-detect on the value
 * @param  {*} value
 * @returns {string}
 */
declare function typeOf(value: any): string;
