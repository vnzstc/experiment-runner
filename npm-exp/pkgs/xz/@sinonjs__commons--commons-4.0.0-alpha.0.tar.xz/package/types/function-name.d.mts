export default functionName;
/**
 * Returns a display name for a function
 * @param  {Function} func
 * @returns {string}
 */
declare function functionName(func: Function): string;
