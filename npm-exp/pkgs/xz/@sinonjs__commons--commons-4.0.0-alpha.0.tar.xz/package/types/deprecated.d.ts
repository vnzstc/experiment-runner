/**
 * Returns a function that will invoke the supplied function and print a
 * deprecation warning to the console each time it is called.
 * @param  {Function} func
 * @param  {string} msg
 * @returns {Function}
 */
export function wrap(func: Function, msg: string): Function;
/**
 * Returns a string which can be supplied to `wrap()` to notify the user that a
 * particular part of the sinon API has been deprecated.
 * @param  {string} packageName
 * @param  {string} funcName
 * @returns {string}
 */
export function defaultMsg(packageName: string, funcName: string): string;
/**
 * Prints a warning on the console, when it exists
 * @param  {string} msg
 * @returns {undefined}
 */
export function printWarning(msg: string): undefined;
declare namespace _default {
    export { defaultMsg };
    export { printWarning };
    export { wrap };
}
export default _default;
