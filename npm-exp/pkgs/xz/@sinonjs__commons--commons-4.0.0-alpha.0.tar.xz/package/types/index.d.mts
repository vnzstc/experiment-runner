declare namespace _default {
    export { global };
    export { calledInOrder };
    export { className };
    export { deprecated };
    export { every };
    export { functionName };
    export { orderByFirstCall };
    export { prototypes };
    export { typeOf };
    export { valueToString };
}
export default _default;
import global from "./global.mjs";
import calledInOrder from "./called-in-order.mjs";
import className from "./class-name.mjs";
import * as deprecated from "./deprecated.js";
import every from "./every.mjs";
import functionName from "./function-name.mjs";
import orderByFirstCall from "./order-by-first-call.mjs";
import prototypes from "./prototypes.mjs";
import typeOf from "./type-of.mjs";
import valueToString from "./value-to-string.mjs";
