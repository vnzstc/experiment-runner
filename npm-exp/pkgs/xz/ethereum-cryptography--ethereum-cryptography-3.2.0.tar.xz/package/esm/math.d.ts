import { pow, invert } from "@noble/curves/abstract/modular";
export declare const modPow: typeof pow;
export declare const modInvert: typeof invert;
