import { abool as assertBool } from "@noble/curves/abstract/utils";
import { abytes as assertBytes } from "@noble/hashes/_assert";
export { bytesToHex, concatBytes, createView, bytesToHex as toHex, utf8ToBytes } from "@noble/hashes/utils";
export { assertBool, assertBytes };
export declare function bytesToUtf8(data: Uint8Array): string;
export declare function hexToBytes(data: string): Uint8Array;
export declare function equalsBytes(a: Uint8Array, b: Uint8Array): boolean;
export declare function wrapHash(hash: (msg: Uint8Array) => Uint8Array): (msg: Uint8Array) => Uint8Array;
