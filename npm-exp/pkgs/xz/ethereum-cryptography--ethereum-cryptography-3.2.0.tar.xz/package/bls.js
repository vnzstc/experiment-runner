"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bls12_381 = void 0;
var bls12_381_1 = require("@noble/curves/bls12-381");
Object.defineProperty(exports, "bls12_381", { enumerable: true, get: function () { return bls12_381_1.bls12_381; } });
