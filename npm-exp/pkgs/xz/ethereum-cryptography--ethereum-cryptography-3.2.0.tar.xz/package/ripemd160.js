"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ripemd160 = void 0;
const legacy_1 = require("@noble/hashes/legacy");
const utils_js_1 = require("./utils.js");
exports.ripemd160 = (0, utils_js_1.wrapHash)(legacy_1.ripemd160);
