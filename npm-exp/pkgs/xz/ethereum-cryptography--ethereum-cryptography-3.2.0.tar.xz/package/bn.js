"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bn254 = void 0;
var bn254_1 = require("@noble/curves/bn254");
Object.defineProperty(exports, "bn254", { enumerable: true, get: function () { return bn254_1.bn254; } });
