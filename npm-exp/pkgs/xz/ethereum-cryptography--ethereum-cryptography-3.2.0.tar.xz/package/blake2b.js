"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blake2b = void 0;
const blake2_1 = require("@noble/hashes/blake2");
const utils_js_1 = require("./utils.js");
const blake2b = (msg, outputLength = 64) => {
    (0, utils_js_1.assertBytes)(msg);
    if (outputLength <= 0 || outputLength > 64) {
        throw Error("Invalid outputLength");
    }
    return (0, blake2_1.blake2b)(msg, { dkLen: outputLength });
};
exports.blake2b = blake2b;
