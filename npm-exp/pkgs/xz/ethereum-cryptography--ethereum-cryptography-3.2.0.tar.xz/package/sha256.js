"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sha256 = void 0;
const sha2_1 = require("@noble/hashes/sha2");
const utils_js_1 = require("./utils.js");
exports.sha256 = (0, utils_js_1.wrapHash)(sha2_1.sha256);
