"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.modInvert = exports.modPow = void 0;
const modular_1 = require("@noble/curves/abstract/modular");
exports.modPow = modular_1.pow;
exports.modInvert = modular_1.invert;
