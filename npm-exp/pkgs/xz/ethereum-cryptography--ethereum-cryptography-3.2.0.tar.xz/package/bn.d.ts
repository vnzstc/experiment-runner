export { bn254 } from '@noble/curves/bn254';
